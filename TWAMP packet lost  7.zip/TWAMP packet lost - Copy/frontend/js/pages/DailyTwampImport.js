import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';

export default function DailyTwampImport() {
  const [tables, setTables] = useState([]);
  const [loadingTables, setLoadingTables] = useState(true);
  const [selectedTable, setSelectedTable] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [totalRows, setTotalRows] = useState(0);
  const [loadingData, setLoadingData] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [expandedRowId, setExpandedRowId] = useState(null);

  const fileInputRef = useRef(null);
  const pageSize = 10;

  const loadTables = async () => {
    setLoadingTables(true);
    setError('');
    try {
      const list = await api.getDailyTwampTables();
      setTables(list || []);
    } catch (err) {
      setError('Could not load tables from backend.');
    } finally {
      setLoadingTables(false);
    }
  };

  const loadTableData = async (tableName, page = 1, searchQuery = '') => {
    setLoadingData(true);
    setExpandedRowId(null);
    try {
      const res = await api.getDailyTwampData(tableName, searchQuery, (page - 1) * pageSize, pageSize);
      setTableData(res.rows || []);
      setTotalRows(res.total || 0);
    } catch (err) {
      setError(`Failed to load table data: ${err.message}`);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    loadTables();
  }, []);

  useEffect(() => {
    if (selectedTable) {
      loadTableData(selectedTable.table_name, currentPage, search);
    }
  }, [selectedTable, currentPage, search]);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (selectedTable) {
      setCurrentPage(1);
      loadTableData(selectedTable.table_name, 1, search);
    }
  };

  const handleClearSearch = () => {
    setSearch('');
    if (selectedTable) {
      setCurrentPage(1);
      loadTableData(selectedTable.table_name, 1, '');
    }
  };

  const handleUploadFile = async (file) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.xlsx') && !file.name.toLowerCase().endsWith('.xls')) {
      setError('Only Excel files (.xlsx / .xls) are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadDailyTwamp(formData);
      setMessage(res.message || 'File uploaded successfully.');
      loadTables();
    } catch (err) {
      setError(err.message || 'Failed to upload file.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleDeleteTable = async (tableName, e) => {
    e.stopPropagation();
    if (!confirm(`Delete table ${tableName}? This action cannot be undone.`)) return;
    try {
      await api.deleteDailyTwampTable(tableName);
      setTables(tables.filter((t) => t.table_name !== tableName));
      if (selectedTable && selectedTable.table_name === tableName) {
        setSelectedTable(null);
        setTableData([]);
      }
      setMessage('Table deleted successfully.');
    } catch (err) {
      alert(`Failed to delete table: ${err.message}`);
    }
  };

  const handleViewTable = (table) => {
    setSelectedTable(table);
    setCurrentPage(1);
    setSearch('');
  };

  const handleBackToList = () => {
    setSelectedTable(null);
    setTableData([]);
    setTotalRows(0);
    setSearch('');
  };

  const toggleRowExpansion = (rowId) => {
    setExpandedRowId(expandedRowId === rowId ? null : rowId);
  };

  const renderRowDetails = (row, idx) => {
    const hourlyKeys = Object.keys(row).filter(
      k => k.includes('_percent') || k.includes('_count')
    );
    return html`
      <tr style=${{ backgroundColor: 'rgba(0,98,255,0.05)' }}>
        <td colSpan="7" style=${{ padding: '20px', borderTop: '1px solid var(--theme-border)' }}>
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '12px' }}>
            ${hourlyKeys.map((key, i) => html`
              <div key=${i} style=${{
                padding: '10px',
                borderRadius: '6px',
                backgroundColor: 'var(--theme-badge-bg)',
                border: '1px solid var(--theme-border)',
                fontSize: '12px',
              }}>
                <div style=${{ fontWeight: '600', color: 'var(--theme-text)', marginBottom: '4px' }}>${key}</div>
                <div style=${{ color: 'var(--theme-text-muted)' }}>${row[key] || '—'}</div>
              </div>
            `)}
          </div>
        </td>
      </tr>
    `;
  };

  const totalPages = Math.ceil(totalRows / pageSize);

  return html`
    <div>
      <!-- List View -->
      ${!selectedTable && html`
        <div style=${{ marginBottom: '30px' }}>
          <h2 style=${{ margin: '0 0 12px', fontSize: '22px', fontWeight: '800', color: 'var(--theme-text)' }}>
            Daily TWAMP Import
          </h2>
          <p style=${{ margin: '0 0 24px', fontSize: '14px', color: 'var(--theme-text-muted)' }}>
            Upload Excel sheets containing daily TWAMP data. A table named <strong>twamp_YYYY_MM_DD</strong> is created automatically for each sheet.
          </p>

          <!-- Upload Zone -->
          <div
            onDragEnter=${handleDrag}
            onDragOver=${handleDrag}
            onDragLeave=${handleDrag}
            onDrop=${handleDrop}
            onClick=${() => !uploading && fileInputRef.current && fileInputRef.current.click()}
            style=${{
              border: `2px dashed ${dragActive ? '#0062ff' : 'var(--theme-border-strong)'}`,
              borderRadius: '12px',
              padding: '48px 24px',
              textAlign: 'center',
              cursor: uploading ? 'not-allowed' : 'pointer',
              backgroundColor: dragActive ? 'rgba(0,98,255,0.06)' : 'var(--theme-panel-bg)',
              transition: 'border-color 0.2s, background-color 0.2s',
              marginBottom: '20px',
            }}
          >
            <input
              ref=${fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              style=${{ display: 'none' }}
              onChange=${(e) => e.target.files[0] && handleUploadFile(e.target.files[0])}
            />

            <div style=${{ fontSize: uploading ? '32px' : '40px', marginBottom: '12px' }}>
              ${uploading ? '⏳' : '📤'}
            </div>
            <p style=${{ margin: '0 0 6px', fontWeight: '700', fontSize: uploading ? '14px' : '16px', color: 'var(--theme-text)' }}>
              ${uploading ? 'Importing...' : 'Drop Excel file here or click to browse'}
            </p>
            <p style=${{ margin: 0, fontSize: '13px', color: 'var(--theme-text-muted)' }}>
              ${uploading ? 'Processing sheet and writing to database.' : '.xlsx / .xls files supported'}
            </p>
          </div>

          <!-- Messages -->
          ${message && html`
            <div style=${{ backgroundColor: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.4)', borderRadius: '8px', padding: '14px 18px', marginBottom: '20px', color: '#34d399', fontSize: '14px' }}>
              ✅ ${message}
            </div>
          `}
          ${error && html`
            <div style=${{ backgroundColor: 'rgba(220,38,38,0.12)', border: '1px solid rgba(220,38,38,0.4)', borderRadius: '8px', padding: '14px 18px', marginBottom: '20px', color: '#f87171', fontSize: '14px' }}>
              ⚠️ ${error}
            </div>
          `}

          <!-- Tables List -->
          <div style=${{ backgroundColor: 'var(--theme-panel-bg)', border: '1px solid var(--theme-border)', borderRadius: '12px', padding: '24px', overflow: 'auto' }}>
            <h3 style=${{ margin: '0 0 16px', fontSize: '16px', fontWeight: '700', color: 'var(--theme-text)' }}>
              Imported Tables (${tables.length})
            </h3>

            ${loadingTables ? html`
              <div style=${{ textAlign: 'center', padding: '40px', color: 'var(--theme-text-muted)' }}>
                <div style=${{ fontSize: '20px', marginBottom: '12px' }}>⏳</div>
                <p>Loading tables...</p>
              </div>
            ` : tables.length === 0 ? html`
              <div style=${{ textAlign: 'center', padding: '40px', color: 'var(--theme-text-muted)' }}>
                <div style=${{ fontSize: '32px', marginBottom: '12px' }}>📭</div>
                <p>No tables imported yet.</p>
              </div>
            ` : html`
              <div style=${{ overflowX: 'auto' }}>
                <table style=${{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style=${{ borderBottom: '2px solid var(--theme-border)', backgroundColor: 'var(--theme-badge-bg)' }}>
                      <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Table Name</th>
                      <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Report Date</th>
                      <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Rows</th>
                      <th style=${{ padding: '12px', textAlign: 'center', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)', width: '140px' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${tables.map((table) => html`
                      <tr key=${table.table_name} onClick=${() => handleViewTable(table)} style=${{ cursor: 'pointer', borderBottom: '1px solid var(--theme-border)', transition: 'background-color 0.2s' }} onMouseEnter=${(e) => e.currentTarget.style.backgroundColor = 'rgba(0,98,255,0.05)'} onMouseLeave=${(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
                        <td style=${{ padding: '12px', fontFamily: 'monospace', fontSize: '13px', color: '#0062ff', fontWeight: '600' }}>${table.table_name}</td>
                        <td style=${{ padding: '12px', color: 'var(--theme-text)' }}>📅 ${table.report_date}</td>
                        <td style=${{ padding: '12px', color: 'var(--theme-text)' }}>${table.row_count.toLocaleString()} rows</td>
                        <td style=${{ padding: '12px', textAlign: 'center' }} onClick=${(e) => e.stopPropagation()}>
                          <div style=${{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                            <button onClick=${() => handleViewTable(table)} style=${{ padding: '6px 12px', fontSize: '12px', backgroundColor: '#0062ff', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>👁️ View</button>
                            <button onClick=${(e) => handleDeleteTable(table.table_name, e)} style=${{ padding: '6px 12px', fontSize: '12px', backgroundColor: 'rgba(220,38,38,0.2)', color: '#f87171', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>🗑️</button>
                          </div>
                        </td>
                      </tr>
                    `)}
                  </tbody>
                </table>
              </div>
            `}
          </div>
        </div>
      `}

      <!-- Detail View -->
      ${selectedTable && html`
        <div style=${{ marginBottom: '30px' }}>
          <button onClick=${handleBackToList} style=${{ marginBottom: '16px', padding: '8px 16px', backgroundColor: 'var(--theme-badge-bg)', border: '1px solid var(--theme-border)', borderRadius: '6px', cursor: 'pointer', color: 'var(--theme-text)', fontSize: '14px' }}>
            ⬅️ Back to Tables
          </button>
          <h2 style=${{ margin: '0 0 8px', fontSize: '22px', fontWeight: '800', color: 'var(--theme-text)' }}>
            ${selectedTable.table_name}
          </h2>
          <p style=${{ margin: '0 0 24px', fontSize: '14px', color: 'var(--theme-text-muted)' }}>
            📅 ${selectedTable.report_date} — <strong>${totalRows}</strong> rows
          </p>

          <!-- Search -->
          <form onSubmit=${handleSearchSubmit} style=${{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
            <input
              type="text"
              placeholder="Search in all columns..."
              value=${search}
              onChange=${handleSearchChange}
              style=${{ flex: 1, padding: '8px 12px', backgroundColor: 'var(--theme-input-bg)', border: '1px solid var(--theme-border)', borderRadius: '6px', color: 'var(--theme-input-color)', fontSize: '14px' }}
            />
            <button type="submit" style=${{ padding: '8px 16px', backgroundColor: '#0062ff', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '600', fontSize: '14px' }}>Search</button>
            ${search && html`
              <button type="button" onClick=${handleClearSearch} style=${{ padding: '8px 16px', backgroundColor: 'var(--theme-badge-bg)', border: '1px solid var(--theme-border)', borderRadius: '6px', cursor: 'pointer', color: 'var(--theme-text)', fontSize: '14px' }}>Clear</button>
            `}
          </form>

          <!-- Data Table -->
          <div style=${{ backgroundColor: 'var(--theme-panel-bg)', border: '1px solid var(--theme-border)', borderRadius: '12px', overflow: 'auto', marginBottom: '20px' }}>
            ${loadingData ? html`
              <div style=${{ textAlign: 'center', padding: '40px', color: 'var(--theme-text-muted)' }}>
                <div style=${{ fontSize: '20px', marginBottom: '12px' }}>⏳</div>
                <p>Loading data...</p>
              </div>
            ` : tableData.length === 0 ? html`
              <div style=${{ textAlign: 'center', padding: '40px', color: 'var(--theme-text-muted)' }}>
                <p>No rows to display.</p>
              </div>
            ` : html`
              <table style=${{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style=${{ borderBottom: '2px solid var(--theme-border)', backgroundColor: 'var(--theme-badge-bg)' }}>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)', width: '40px' }}>ID</th>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>POP Name</th>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Host ID</th>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Connection Type</th>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>Max PL %</th>
                    <th style=${{ padding: '12px', textAlign: 'left', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)' }}>PL 05-90 Count</th>
                    <th style=${{ padding: '12px', textAlign: 'center', fontSize: '13px', fontWeight: '700', color: 'var(--theme-text)', width: '50px' }}>Details</th>
                  </tr>
                </thead>
                <tbody>
                  ${tableData.map((row, idx) => html`
                    <React.Fragment key=${idx}>
                      <tr onClick=${(e) => !e.target.closest('button') && toggleRowExpansion(idx)} style=${{ borderBottom: '1px solid var(--theme-border)', cursor: 'pointer', transition: 'background-color 0.2s' }} onMouseEnter=${(e) => e.currentTarget.style.backgroundColor = 'rgba(0,98,255,0.03)'} onMouseLeave=${(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
                        <td style=${{ padding: '12px', fontSize: '12px', color: 'var(--theme-text-muted)' }}>${idx + 1}</td>
                        <td style=${{ padding: '12px', fontSize: '13px', color: 'var(--theme-text)' }}>${row.pop_name || '—'}</td>
                        <td style=${{ padding: '12px', fontSize: '13px', color: 'var(--theme-text)' }}>${row.host_id || '—'}</td>
                        <td style=${{ padding: '12px', fontSize: '13px', color: 'var(--theme-text)' }}>${row.connection_type || '—'}</td>
                        <td style=${{ padding: '12px', fontSize: '13px', color: 'var(--theme-text)', fontWeight: '600' }}>${row.max_packet_loss_hour_percent || '—'}</td>
                        <td style=${{ padding: '12px', fontSize: '13px', color: 'var(--theme-text)' }}>${row.packet_loss_05_90_percent_count || '—'}</td>
                        <td style=${{ padding: '12px', textAlign: 'center' }}>
                          <button onClick=${() => toggleRowExpansion(idx)} style=${{ padding: '4px 8px', fontSize: '12px', backgroundColor: 'var(--theme-badge-bg)', border: '1px solid var(--theme-border)', borderRadius: '4px', cursor: 'pointer', color: 'var(--theme-text)' }}>
                            ${expandedRowId === idx ? '▼' : '▶'}
                          </button>
                        </td>
                      </tr>
                      ${expandedRowId === idx && renderRowDetails(row, idx)}
                    </React.Fragment>
                  `)}
                </tbody>
              </table>
            `}
          </div>

          <!-- Pagination -->
          ${tableData.length > 0 && html`
            <div style=${{ display: 'flex', justifyContent: 'center', gap: '8px', alignItems: 'center' }}>
              <button disabled=${currentPage === 1} onClick=${() => setCurrentPage(currentPage - 1)} style=${{ padding: '8px 12px', backgroundColor: currentPage === 1 ? 'var(--theme-badge-bg)' : '#0062ff', color: currentPage === 1 ? 'var(--theme-text-muted)' : '#fff', border: 'none', borderRadius: '6px', cursor: currentPage === 1 ? 'not-allowed' : 'pointer' }}>← Previous</button>
              <span style=${{ color: 'var(--theme-text)', fontSize: '14px', fontWeight: '600' }}>Page ${currentPage} of ${totalPages}</span>
              <button disabled=${currentPage === totalPages} onClick=${() => setCurrentPage(currentPage + 1)} style=${{ padding: '8px 12px', backgroundColor: currentPage === totalPages ? 'var(--theme-badge-bg)' : '#0062ff', color: currentPage === totalPages ? 'var(--theme-text-muted)' : '#fff', border: 'none', borderRadius: '6px', cursor: currentPage === totalPages ? 'not-allowed' : 'pointer' }}>Next →</button>
            </div>
          `}
        </div>
      `}
    </div>
  `;
}
