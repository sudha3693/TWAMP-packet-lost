"""
Service for importing the daily TWAMP Excel sheet into a per-day table.

Sheet layout expected:
  - Rows 1-3, 5-6 : metadata / ignored
  - Row 4          : contains the report date (cell A4 or B4)
  - Row 7          : column headers (columns A through BB, i.e. up to 54 cols)
                     Blank headers are replaced by the predefined short names below.
  - Row 8+         : data rows

The resulting SQLite table is named  twamp_YYYY_MM_DD  based on the parsed date.
"""

import re
from datetime import date, datetime
from typing import List, Optional

from openpyxl.worksheet.worksheet import Worksheet
from sqlalchemy import text
from sqlalchemy.engine import Engine


# ---------------------------------------------------------------------------
# Ordered fallback short names for columns A7 → BB7 (0-based index)
# If a cell in row 7 is blank, the short name at the matching position is used.
# ---------------------------------------------------------------------------
COLUMN_SHORT_NAMES: List[str] = [
    "pop_name",                         # A  (0)
    "host_id",                          # B  (1)
    "connection_type",                  # C  (2)
    "max_packet_loss_hour_percent",     # D  (3)
    "packet_loss_05_90_percent_count",  # E  (4)
]
for _h in range(24):
    COLUMN_SHORT_NAMES.append(f"rt_packet_loss_{_h:02d}_percent")  # F, H, J, ...
    COLUMN_SHORT_NAMES.append(f"packet_loss_{_h:02d}_count")       # G, I, K, ...


def _normalize_col_name(value: str) -> str:
    """Convert a raw header string to a safe SQL column identifier."""
    value = value.strip().lower()
    value = re.sub(r"[^0-9a-z]+", "_", value)
    value = re.sub(r"_+", "_", value)
    return value.strip("_") or "col"


def _parse_date_from_row4(sheet: Worksheet) -> date:
    """
    Extract the report date from row 4.
    Tries cells A4 through D4 in order; accepts datetime objects, date objects,
    and common string formats.
    """
    row4 = next(
        sheet.iter_rows(min_row=4, max_row=4, values_only=True),
        None,
    )
    if not row4:
        raise ValueError("Row 4 is empty; cannot read the report date.")

    for cell_val in list(row4)[:4]:
        if cell_val is None:
            continue
        if isinstance(cell_val, datetime):
            return cell_val.date()
        if isinstance(cell_val, date):
            return cell_val
        val_str = str(cell_val).strip()
        if not val_str:
            continue
        for fmt in (
            "%d-%b-%y", "%d-%b-%Y",
            "%Y-%m-%d",
            "%d/%m/%Y", "%d/%m/%y",
            "%d %b %Y", "%d %b %y",
            "%d-%m-%Y", "%d-%m-%y",
        ):
            try:
                return datetime.strptime(val_str, fmt).date()
            except ValueError:
                continue

    raise ValueError(
        "Could not parse a date from row 4 (cells A4–D4). "
        "Expected formats: '20-Jul-26', '2026-07-20', '20/07/2026', etc."
    )


def _get_header_columns(sheet: Worksheet) -> List[str]:
    """
    Read row 7 for column headers.
    Blank cells are replaced by the positional short name from COLUMN_SHORT_NAMES.
    Duplicate names are de-duplicated by appending an index suffix.
    """
    row7 = next(
        sheet.iter_rows(min_row=7, max_row=7, values_only=True),
        None,
    )
    if not row7:
        raise ValueError("Row 7 is empty; cannot read column headers.")

    columns: List[str] = []
    seen: dict = {}

    for idx, cell_val in enumerate(row7):
        raw = str(cell_val).strip() if cell_val is not None else ""
        if raw:
            col_name = _normalize_col_name(raw)
        elif idx < len(COLUMN_SHORT_NAMES):
            col_name = COLUMN_SHORT_NAMES[idx]
        else:
            col_name = f"col_{idx + 1}"

        # De-duplicate
        if col_name in seen:
            seen[col_name] += 1
            col_name = f"{col_name}_{seen[col_name]}"
        else:
            seen[col_name] = 0

        columns.append(col_name)

    return columns


def _ensure_daily_table(engine: Engine, table_name: str, columns: List[str]) -> None:
    """Create the daily table if it does not already exist."""
    col_defs = ", ".join(f'"{col}" TEXT' for col in columns)
    ddl = (
        f'CREATE TABLE IF NOT EXISTS "{table_name}" '
        f'(id INTEGER PRIMARY KEY AUTOINCREMENT, {col_defs})'
    )
    with engine.begin() as conn:
        conn.execute(text(ddl))


def import_daily_twamp_sheet(engine: Engine, sheet: Worksheet) -> dict:
    """
    Parse and import one daily TWAMP worksheet.

    Args:
        engine:  SQLAlchemy engine (used directly for DDL + DML).
        sheet:   openpyxl Worksheet (opened in data_only / read_only mode).

    Returns:
        dict with keys: table_name, report_date, row_count, columns.
    """
    report_date = _parse_date_from_row4(sheet)
    table_name = f"twamp_{report_date.strftime('%Y_%m_%d')}"
    columns = _get_header_columns(sheet)

    # Collect data rows (row 8 onwards)
    data_rows: List[dict] = []
    for row_values in sheet.iter_rows(min_row=8, values_only=True):
        if not row_values or all(
            cell is None or str(cell).strip() == "" for cell in row_values
        ):
            continue
        row_dict: dict = {}
        for idx, col_name in enumerate(columns):
            val = row_values[idx] if idx < len(row_values) else None
            if val is not None:
                row_dict[col_name] = str(val).strip() if isinstance(val, str) else str(val)
            else:
                row_dict[col_name] = None
        data_rows.append(row_dict)

    if not data_rows:
        raise ValueError("No data rows found below row 7 in the sheet.")

    # Ensure the per-day table exists
    _ensure_daily_table(engine, table_name, columns)

    # Insert rows
    quoted_cols = ", ".join(f'"{c}"' for c in columns)
    placeholders = ", ".join(f":p{i}" for i in range(len(columns)))
    insert_sql = (
        f'INSERT INTO "{table_name}" ({quoted_cols}) VALUES ({placeholders})'
    )

    with engine.begin() as conn:
        for row in data_rows:
            params = {f"p{i}": row.get(col) for i, col in enumerate(columns)}
            conn.execute(text(insert_sql), params)

    return {
        "table_name": table_name,
        "report_date": report_date.isoformat(),
        "row_count": len(data_rows),
        "columns": columns,
    }


def list_daily_tables(engine: Engine) -> list:
    """
    List all daily TWAMP tables created in the database.
    Returns a list of dicts with table_name, report_date (extracted from name), and row_count.
    """
    with engine.connect() as conn:
        # Query the database schema to find all tables matching twamp_YYYY_MM_DD
        result = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'twamp_%' ORDER BY name DESC")
        )
        tables = [row[0] for row in result]

    daily_tables = []
    for table_name in tables:
        # Parse the date from the table name (twamp_YYYY_MM_DD)
        parts = table_name.split("_")
        if len(parts) == 4 and parts[0] == "twamp":
            try:
                year, month, day = int(parts[1]), int(parts[2]), int(parts[3])
                report_date = date(year, month, day)
                
                # Count rows in the table
                with engine.connect() as conn:
                    count_result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
                    row_count = count_result.scalar() or 0

                daily_tables.append({
                    "table_name": table_name,
                    "report_date": report_date.isoformat(),
                    "row_count": row_count,
                })
            except (ValueError, IndexError):
                continue

    return daily_tables


def get_daily_table_data(
    engine: Engine,
    table_name: str,
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
) -> dict:
    """
    Retrieve data from a specific daily TWAMP table.
    Supports search across all text columns.
    """
    # Validate table name format (security)
    if not table_name.startswith("twamp_") or not all(c.isalnum() or c == "_" for c in table_name):
        raise ValueError("Invalid table name.")

    with engine.connect() as conn:
        # Get total row count
        count_result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
        total = count_result.scalar() or 0

        # Build search query if provided
        where_clause = ""
        params = {}
        if search:
            search_param = f"%{search}%"
            # Get column names first
            cols_result = conn.execute(
                text(f'PRAGMA table_info("{table_name}")')
            )
            cols = [row[1] for row in cols_result]  # row[1] is column name
            # Build OR condition for all text columns
            conditions = " OR ".join([f'"{col}" LIKE :search' for col in cols if col != "id"])
            where_clause = f"WHERE {conditions}"
            params["search"] = search_param

        # Fetch paginated data
        offset_val = skip * limit
        params["offset"] = offset_val
        params["limit"] = limit

        query = f'SELECT * FROM "{table_name}" {where_clause} LIMIT :limit OFFSET :offset'
        rows_result = conn.execute(text(query), params)

        rows = []
        for row in rows_result:
            row_dict = dict(row._mapping)
            rows.append(row_dict)

        # If search was applied, count filtered rows
        if search:
            filtered_result = conn.execute(
                text(f'SELECT COUNT(*) FROM "{table_name}" {where_clause}'),
                params,
            )
            total = filtered_result.scalar() or 0

    return {
        "rows": rows,
        "total": total,
        "skip": skip,
        "limit": limit,
    }


def delete_daily_table(engine: Engine, table_name: str) -> None:
    """
    Delete a daily TWAMP table from the database.
    """
    # Validate table name format (security)
    if not table_name.startswith("twamp_") or not all(c.isalnum() or c == "_" for c in table_name):
        raise ValueError("Invalid table name.")

    with engine.begin() as conn:
        conn.execute(text(f'DROP TABLE IF EXISTS "{table_name}"'))
