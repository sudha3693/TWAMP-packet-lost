import re
import csv
import io
from datetime import datetime
from typing import Dict, List, Optional
from openpyxl.worksheet.worksheet import Worksheet
from sqlalchemy.orm import Session
from src.crud import packet_loss as packet_loss_crud


EXFO_REQUIRED_COLUMNS = {
    "shortname": "short_name",
    "popname": "pop_name",
    "connectiontype": "connection_type",
    # "Packet Loss >=0.50 & <0.90 percent Count" normalizes to the first key,
    # "Packet Loss >=0.5 & <90 percent Count" normalizes to the second key.
    "packetloss05090percentcount": "packet_loss_05_90_percent_count",
    "packetloss0590percentcount": "packet_loss_05_90_percent_count",
    "packetlossageing": "packet_loss_ageing",
    # "No of hrs Session having PL >=0.50 & <0.90 count" normalizes to the first key,
    # "No of hrs Session having PL >=0.5 & <90 count" normalizes to the second key.
    "noofhrssessionhavingpl050090count": "no_of_hrs_session_having_pl_05_90_count",
    "noofhrssessionhavingpl0590count": "no_of_hrs_session_having_pl_05_90_count",
    "sitename": "site_name",
    "siteid": "site_id",
    "sitetype": "site_type",
    "twamptechnology": "twamp_technology",
}

# Hourly columns (optional — not every report includes all 24 hours)
EXFO_OPTIONAL_COLUMNS: dict = {}
for hour in range(24):
    EXFO_OPTIONAL_COLUMNS[f"rtpacketloss{hour:02d}percent"] = f"rt_packet_loss_{hour:02d}_percent"
    EXFO_OPTIONAL_COLUMNS[f"packetloss{hour:02d}count"] = f"packet_loss_{hour:02d}_count"

# Combined lookup for header normalization (required takes precedence)
EXFO_ALL_COLUMNS = {**EXFO_OPTIONAL_COLUMNS, **EXFO_REQUIRED_COLUMNS}

# Columns that MUST be present for a valid report
EXFO_MUST_HAVE = set(EXFO_REQUIRED_COLUMNS.values())


def normalize_header_value(value: Optional[str]) -> str:
    if value is None:
        return ""
    # .strip() removes leading/trailing spaces; re.sub removes all non-alphanumeric
    return re.sub(r"[^0-9a-z]+", "", str(value).strip().lower())


def parse_report_metadata(raw_metadata: Optional[str]) -> Dict[str, str]:
    if not raw_metadata or not str(raw_metadata).strip():
        raise ValueError("Metadata cell A1 is empty or missing.")

    raw_text = str(raw_metadata)
    report_date = None
    circle = None

    for raw_line in raw_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        date_match = re.match(r"^day\s*: ?(.+)$", line, re.I)
        circle_match = re.match(r"^circles?\s*: ?(.+)$", line, re.I)
        if date_match:
            report_date = date_match.group(1).strip()
        elif circle_match:
            circle = circle_match.group(1).strip()

    if not report_date or not circle:
        raise ValueError("Merged header A1 must contain both Day and Circles metadata.")

    try:
        parsed_date = datetime.strptime(report_date, "%d %b %y").date()
    except ValueError as exc:
        raise ValueError(f"Report date in A1 is not in expected format: {report_date}") from exc

    return {"report_date": parsed_date, "circle": circle}


def find_header_row(sheet: Worksheet) -> int:
    # Scanning first 50 rows using iter_rows is fast and prevents full sheet scans on non-matching files (like 5G mapping sheets).
    for row_idx, row in enumerate(sheet.iter_rows(max_row=50, values_only=True), start=1):
        row_values = [normalize_header_value(cell) for cell in row]
        if "shortname" in row_values:
            return row_idx
    raise ValueError("Could not find the data header row. Ensure the sheet contains a 'Short name' header.")


def build_header_map(sheet: Worksheet, header_row: int) -> Dict[str, int]:
    header_map: Dict[str, int] = {}
    found_columns = set()

    # Retrieve the specific header row values in a single call
    header_row_values = next(sheet.iter_rows(min_row=header_row, max_row=header_row, values_only=True))
    for col_index, raw_value in enumerate(header_row_values):
        normalized = normalize_header_value(raw_value)
        if normalized in EXFO_ALL_COLUMNS:
            field_name = EXFO_ALL_COLUMNS[normalized]
            header_map[field_name] = col_index
            found_columns.add(field_name)

    # Only raise for truly required columns
    missing_columns = [name for name in EXFO_MUST_HAVE if name not in found_columns]
    if missing_columns:
        raise ValueError(
            "Missing required packet loss report columns: "
            + ", ".join(sorted(missing_columns))
        )

    return header_map


def build_packet_loss_rows(sheet: Worksheet, header_row: int, header_map: Dict[str, int]) -> List[dict]:
    data_rows: List[dict] = []
    
    # Restrict iteration only up to the maximum column index we actually map
    max_col = max(header_map.values()) + 1 if header_map else None
    header_items = list(header_map.items())

    for row_values in sheet.iter_rows(min_row=header_row + 1, max_col=max_col, values_only=True):
        if not row_values or all(cell is None or str(cell).strip() == "" for cell in row_values):
            continue

        row_len = len(row_values)
        row_values_dict = {}
        for field_name, col_idx in header_items:
            if col_idx < row_len:
                raw_value = row_values[col_idx]
                if raw_value is not None:
                    if isinstance(raw_value, str):
                        row_values_dict[field_name] = raw_value.strip()
                    else:
                        row_values_dict[field_name] = str(raw_value).strip()
                else:
                    row_values_dict[field_name] = None
            else:
                row_values_dict[field_name] = None

        data_rows.append(row_values_dict)

    if not data_rows:
        raise ValueError("No data rows found below the packet loss header row.")

    return data_rows


def is_exfo_packet_loss_report(sheet: Worksheet) -> bool:
    try:
        _ = find_header_row(sheet)
        return True
    except ValueError:
        return False


def import_exfo_packet_loss_report(db: Session, sheet: Worksheet) -> Dict[str, int]:
    # In read-only mode, accessing sheet["A1"] directly can be unsupported or trigger slow loads.
    # We safely extract cell A1 value using iter_rows.
    a1_value = None
    first_row = next(sheet.iter_rows(min_row=1, max_row=1, min_col=1, max_col=1, values_only=True), None)
    if first_row:
        a1_value = first_row[0]

    metadata = parse_report_metadata(a1_value)
    report_date = metadata["report_date"]
    circle = metadata["circle"]

    existing = packet_loss_crud.get_report_metadata_by_date_and_circle(db, report_date, circle)
    if existing is not None:
        raise ValueError(f"Report already imported for date {report_date} and circle {circle}.")

    header_row = find_header_row(sheet)
    header_map = build_header_map(sheet, header_row)
    packet_loss_rows = build_packet_loss_rows(sheet, header_row, header_map)

    from datetime import datetime
    now = datetime.utcnow()

    report_metadata = packet_loss_crud.create_report_metadata(
        db=db,
        report_date=report_date,
        circle=circle,
        uploaded_at=now,
    )

    db_rows = packet_loss_crud.create_packet_loss_data_batch(db=db, report_id=report_metadata.id, rows=packet_loss_rows)
    return {
        "report_id": report_metadata.id,
        "report_date": report_date,
        "circle": circle,
        "row_count": len(db_rows),
    }


def convert_sheet_to_csv_bytes(sheet: Worksheet) -> bytes:
    """Convert the active worksheet to UTF-8 CSV bytes."""
    stream = io.StringIO()
    writer = csv.writer(stream)
    for row in sheet.iter_rows(values_only=True):
        writer.writerow(["" if value is None else value for value in row])
    return stream.getvalue().encode("utf-8")


def _find_header_row_from_csv_rows(rows: List[List[str]]) -> int:
    max_scan = min(len(rows), 50)
    for idx in range(max_scan):
        if "shortname" in [normalize_header_value(cell) for cell in rows[idx]]:
            return idx
    raise ValueError("Could not find the data header row. Ensure the file contains a 'Short name' header.")


def _build_header_map_from_csv_row(header_row_values: List[str]) -> Dict[str, int]:
    header_map: Dict[str, int] = {}
    found_columns = set()

    for col_index, raw_value in enumerate(header_row_values):
        normalized = normalize_header_value(raw_value)
        if normalized in EXFO_ALL_COLUMNS:
            field_name = EXFO_ALL_COLUMNS[normalized]
            header_map[field_name] = col_index
            found_columns.add(field_name)

    # Only raise for truly required columns; hourly columns are optional
    missing_columns = [name for name in EXFO_MUST_HAVE if name not in found_columns]
    if missing_columns:
        raise ValueError(
            "Missing required packet loss report columns: "
            + ", ".join(sorted(missing_columns))
        )

    return header_map


def _build_packet_loss_rows_from_csv_rows(rows: List[List[str]], header_row_index: int, header_map: Dict[str, int]) -> List[dict]:
    data_rows: List[dict] = []
    header_items = list(header_map.items())

    for row_values in rows[header_row_index + 1:]:
        if not row_values or all(str(cell).strip() == "" for cell in row_values):
            continue

        row_len = len(row_values)
        row_values_dict = {}
        for field_name, col_idx in header_items:
            if col_idx < row_len:
                raw_value = row_values[col_idx]
                row_values_dict[field_name] = str(raw_value).strip() if raw_value is not None else None
            else:
                row_values_dict[field_name] = None

        data_rows.append(row_values_dict)

    if not data_rows:
        raise ValueError("No data rows found below the packet loss header row.")

    return data_rows


def import_exfo_packet_loss_report_csv(db: Session, csv_bytes: bytes) -> Dict[str, int]:
    """Import EXFO packet-loss report from CSV bytes."""
    text = csv_bytes.decode("utf-8-sig", errors="replace")
    csv_rows = list(csv.reader(io.StringIO(text)))
    if not csv_rows:
        raise ValueError("CSV file is empty.")

    a1_value = csv_rows[0][0] if csv_rows and csv_rows[0] else ""
    metadata = parse_report_metadata(a1_value)
    report_date = metadata["report_date"]
    circle = metadata["circle"]

    existing = packet_loss_crud.get_report_metadata_by_date_and_circle(db, report_date, circle)
    if existing is not None:
        raise ValueError(f"Report already imported for date {report_date} and circle {circle}.")

    header_row_index = _find_header_row_from_csv_rows(csv_rows)
    header_map = _build_header_map_from_csv_row(csv_rows[header_row_index])
    packet_loss_rows = _build_packet_loss_rows_from_csv_rows(csv_rows, header_row_index, header_map)

    now = datetime.utcnow()
    report_metadata = packet_loss_crud.create_report_metadata(
        db=db,
        report_date=report_date,
        circle=circle,
        uploaded_at=now,
    )

    db_rows = packet_loss_crud.create_packet_loss_data_batch(db=db, report_id=report_metadata.id, rows=packet_loss_rows)
    return {
        "report_id": report_metadata.id,
        "report_date": report_date,
        "circle": circle,
        "row_count": len(db_rows),
    }
