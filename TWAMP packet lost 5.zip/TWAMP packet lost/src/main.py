from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import threading
from src.config import settings
from src.database import engine, Base, SessionLocal
from src.services import dashboard as dashboard_service

# Import models to ensure they are registered on the Base metadata before calling create_all
from src.models import item as item_model
from src.models import five_g_data as five_g_data_model
from src.models import packet_loss as packet_loss_model
from src.routers import item as item_router
from src.routers import five_g_data as five_g_data_router
from src.routers import packet_loss as packet_loss_router
from src.routers import dashboard as dashboard_router

# Create database tables on startup. 
# Note: For production use cases, it's recommended to manage migrations with Alembic.
Base.metadata.create_all(bind=engine)

# Add column migration for packet_loss_data if it doesn't exist
from sqlalchemy import inspect, text
inspector = inspect(engine)
try:
    columns = [col['name'] for col in inspector.get_columns('packet_loss_data')]
    if columns and 'site_id' not in columns:
        with engine.begin() as conn:
            conn.execute(text("ALTER TABLE packet_loss_data ADD COLUMN site_id VARCHAR(100)"))

    if columns and 'technology_class' not in columns:
        with engine.begin() as conn:
            conn.execute(text("ALTER TABLE packet_loss_data ADD COLUMN technology_class VARCHAR(20)"))

    if columns and 'pl_count_num' not in columns:
        with engine.begin() as conn:
            conn.execute(text("ALTER TABLE packet_loss_data ADD COLUMN pl_count_num FLOAT"))

    with engine.begin() as conn:
        conn.execute(text("""
            UPDATE packet_loss_data
            SET technology_class = CASE
                WHEN lower(trim(COALESCE(twamp_technology, ''))) LIKE '%voice%' AND lower(trim(COALESCE(twamp_technology, ''))) LIKE '%4g%' THEN 'VOICE'
                WHEN lower(trim(COALESCE(twamp_technology, ''))) LIKE '%5g%' THEN '5G'
                WHEN lower(trim(COALESCE(twamp_technology, ''))) LIKE '%4g%' THEN '4G'
                ELSE 'OTHER'
            END
            WHERE technology_class IS NULL OR trim(technology_class) = ''
        """))

        conn.execute(text("""
            UPDATE packet_loss_data
            SET pl_count_num = COALESCE(
                CAST(NULLIF(TRIM(REPLACE(packet_loss_05_90_percent_count, ',', '')), '') AS FLOAT),
                0.0
            )
            WHERE pl_count_num IS NULL
        """))

        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_packet_loss_report_tech_pl ON packet_loss_data (report_id, technology_class, pl_count_num)"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_packet_loss_report_pl ON packet_loss_data (report_id, pl_count_num)"))
except Exception as e:
    print(f"Migration error: {e}")

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="FastAPI Backend Template with SQLite & SQLAlchemy",
    version="1.0.0",
)

# Configure CORS (Cross-Origin Resource Sharing)
# Adjust these origins in a production environment as necessary.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register endpoints routers
app.include_router(item_router.router, prefix="/api/v1/items", tags=["items"])
app.include_router(five_g_data_router.router, prefix="/api/v1/five-g-data", tags=["five_g_data"])
app.include_router(packet_loss_router.router, prefix="/api/v1/packet-loss", tags=["packet_loss"])
app.include_router(dashboard_router.router, prefix="/api/dashboard", tags=["dashboard"])
app.include_router(dashboard_router.router, prefix="/api/v1/dashboard", tags=["dashboard"])


def _prewarm_dashboard_cache() -> None:
    """Warm common dashboard responses so first user load is fast."""
    db = SessionLocal()
    try:
        dashboard_service.get_dashboard_summary(db, filters={})
        dashboard_service.get_dashboard_trend_7days(db, filters={})
        dashboard_service.get_dashboard_trend_wow(db, filters={})
        dashboard_service.get_dashboard_backhaul(db, filters={})
        dashboard_service.get_dashboard_top_sites(db, filters={"page": 1, "page_size": "25"})
    except Exception as exc:
        print(f"Dashboard prewarm skipped: {exc}")
    finally:
        db.close()


@app.on_event("startup")
async def startup_prewarm_dashboard_cache() -> None:
    # Run prewarm in background so server startup stays responsive.
    threading.Thread(target=_prewarm_dashboard_cache, daemon=True).start()



@app.get("/health", tags=["health"])
async def health_check():
    """
    Health check endpoint to verify that the API is online.
    """
    return {
        "status": "online",
        "project_name": settings.PROJECT_NAME,
        "docs_url": "/docs"
    }


# Serve React Frontend Static Files
# We mount this at the end so it doesn't conflict with API routes or /docs
from fastapi.staticfiles import StaticFiles
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"

if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")

