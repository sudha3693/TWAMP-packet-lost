import math
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional
import time
from functools import wraps
import json
import threading

from sqlalchemy import Float, and_, cast, case, func, literal, or_
from sqlalchemy.orm import Session, joinedload

from src.models.packet_loss import PacketLossData, ReportMetadata
from src.services.packet_loss_filters import apply_packet_loss_filters

# Simple in-memory TTL cache
_CACHE = {}
_IN_FLIGHT = {}
_CACHE_LOCK = threading.Lock()
CACHE_TTL = 300  # 5 minutes

def ttl_cache(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Only cache if first argument is a Session (skip it for cache key)
        key_args = args[1:] if args and hasattr(args[0], 'query') else args

        # Build a deterministic cache key and avoid hash collisions.
        try:
            key_payload = {
                "func": func.__name__,
                "args": key_args,
                "kwargs": kwargs,
            }
            key_str = json.dumps(key_payload, sort_keys=True, default=str)
        except Exception:
            return func(*args, **kwargs)

        now = time.time()

        is_leader = False
        wait_event = None
        with _CACHE_LOCK:
            if key_str in _CACHE:
                result, timestamp = _CACHE[key_str]
                if now - timestamp < CACHE_TTL:
                    return result

            wait_event = _IN_FLIGHT.get(key_str)
            if wait_event is None:
                wait_event = threading.Event()
                _IN_FLIGHT[key_str] = wait_event
                is_leader = True

        if not is_leader:
            wait_event.wait(timeout=180)
            now = time.time()
            with _CACHE_LOCK:
                if key_str in _CACHE:
                    result, timestamp = _CACHE[key_str]
                    if now - timestamp < CACHE_TTL:
                        return result
            return func(*args, **kwargs)

        try:
            result = func(*args, **kwargs)
            with _CACHE_LOCK:
                _CACHE[key_str] = (result, time.time())
            return result
        finally:
            with _CACHE_LOCK:
                in_flight_event = _IN_FLIGHT.pop(key_str, None)
            if in_flight_event is not None:
                in_flight_event.set()
    return wrapper

def clear_dashboard_cache():
    """Clear the dashboard in-memory cache to force a refresh on the next request."""
    with _CACHE_LOCK:
        _CACHE.clear()


def _normalize_text(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _classify_technology(value: Optional[str]) -> str:
    if not value:
        return "Other"
    normalized = str(value).strip().lower()
    # Check voice first to prevent classifying "4G_Voice" as "4G"
    if "voice" in normalized:
        return "Voice"
    if "5g" in normalized:
        return "5G"
    if "4g" in normalized:
        return "4G"
    return "Other"


def _parse_numeric(value: Any) -> float:
    if not value:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(value) else 0.0
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else 0.0
    except ValueError:
        try:
            parsed = float(str(value).replace(",", "").strip())
            return parsed if math.isfinite(parsed) else 0.0
        except (TypeError, ValueError):
            return 0.0
    except TypeError:
        return 0.0


def _parse_iso_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(str(value).strip())
    except (TypeError, ValueError):
        return None


def _normalize_top_site_technology(value: Optional[str]) -> Optional[str]:
    normalized = _normalize_text(value)
    if not normalized:
        return None

    lower_value = normalized.lower()
    if "voice" in lower_value and "4g" in lower_value:
        return "4G_Voice"
    if "5g" in lower_value:
        return "5G_Data"
    if "4g" in lower_value:
        return "4G_Data"
    return normalized


def _numeric_sql_expression(column):
    return func.coalesce(
        cast(func.nullif(func.trim(func.replace(column, ",", "")), ""), Float),
        0.0,
    )


def _pl_count_sql_expression():
    return func.coalesce(
        PacketLossData.pl_count_num,
        _numeric_sql_expression(PacketLossData.packet_loss_05_90_percent_count),
    )


def _technology_class_sql_expression():
    tech_class_clean = func.nullif(func.trim(PacketLossData.technology_class), "")
    tech_lower = func.lower(func.trim(PacketLossData.twamp_technology))
    return func.coalesce(
        tech_class_clean,
        case(
            (and_(tech_lower.like("%voice%"), tech_lower.like("%4g%")), "VOICE"),
            (tech_lower.like("%5g%"), "5G"),
            (tech_lower.like("%4g%"), "4G"),
            else_="OTHER",
        ),
    )


def _packet_loss_minutes_expression():
    total_expression = None
    for hour in range(24):
        column = getattr(PacketLossData, f"rt_packet_loss_{hour:02d}_percent")
        hour_expression = _numeric_sql_expression(column)
        total_expression = hour_expression if total_expression is None else total_expression + hour_expression
    return total_expression if total_expression is not None else literal(0.0)


def _normalize_circle(value: Optional[str]) -> Optional[str]:
    normalized = _normalize_text(value)
    if not normalized:
        return None
    mapping = {
        "all": None,
        "bihar": "BIH",
        "jharkhand": "JHK",
        "bih": "BIH",
        "bhk": "BIH",
        "jhk": "JHK",
        "bihar circle": "BIH",
        "jharkhand circle": "JHK",
    }
    return mapping.get(normalized.lower(), normalized)


def _collect_qualifying_sites(rows: List[Dict[str, Any]]) -> Dict[str, set]:
    """Return qualifying site keys for each tech class using the 3-days-in-window rule."""
    thresholds = {"VOICE": 14, "4G": 60, "5G": 60}
    qualifying: Dict[str, set] = {"VOICE": set(), "4G": set(), "5G": set()}
    daily_hits: Dict[tuple, set] = {}

    for row in rows:
        tech_class = str(row.get("technology_class") or "").upper()
        threshold = thresholds.get(tech_class)
        if threshold is None:
            continue

        site_key = row.get("site_key") or row.get("site_name") or row.get("site_id")
        if not site_key:
            continue

        pl_value = row.get("pl_count_num")
        if pl_value is None:
            pl_value = row.get("pl_count")
        if pl_value is None:
            pl_value = row.get("packet_loss_05_90_percent_count")
        try:
            pl_num = float(pl_value)
        except (TypeError, ValueError):
            pl_num = 0.0

        if pl_num < threshold:
            continue

        report_date = row.get("report_date")
        if report_date is None:
            continue

        key = (site_key, tech_class)
        daily_hits.setdefault(key, set()).add(report_date)

    for (site_key, tech_class), report_dates in daily_hits.items():
        if len(report_dates) >= 3:
            qualifying[tech_class].add(site_key)

    return qualifying


def _get_qualifying_site_keys(
    db: Session,
    filters: Optional[Dict[str, Any]] = None
) -> Dict[str, set]:
    """Returns a dict mapping tech class ('VOICE', '4G', '5G') to a set of site keys
    that appeared in >= 3 distinct report dates within the filter window.
    Uses pure SQL GROUP BY + HAVING - no Python-level row loops."""
    filter_values = filters or {}

    tech_class_expr = PacketLossData.technology_class
    pl_count_expr = PacketLossData.pl_count_num
    site_name_norm = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr = func.coalesce(site_name_norm, site_id_norm)

    # Base query filtered by PL thresholds per technology class
    base_q = (
        db.query(
            site_key_expr.label("site_key"),
            tech_class_expr.label("tech_class"),
            func.count(func.distinct(ReportMetadata.report_date)).label("distinct_days"),
        )
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(
            or_(
                and_(tech_class_expr == "VOICE", pl_count_expr >= 14),
                and_(tech_class_expr == "4G",    pl_count_expr >= 60),
                and_(tech_class_expr == "5G",    pl_count_expr >= 60),
            )
        )
        .filter(site_key_expr.isnot(None))
    )

    # Apply date / circle / extra filters
    circle = _normalize_circle(filter_values.get("circle"))
    if circle:
        if circle == "BIH":
            base_q = base_q.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif circle == "JHK":
            base_q = base_q.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            base_q = base_q.filter(ReportMetadata.circle == circle)

    if filter_values.get("start_date"):
        base_q = base_q.filter(ReportMetadata.report_date >= date.fromisoformat(filter_values["start_date"]))
    if filter_values.get("end_date"):
        base_q = base_q.filter(ReportMetadata.report_date <= date.fromisoformat(filter_values["end_date"]))

    base_q = apply_packet_loss_filters(
        base_q,
        search=filter_values.get("search"),
        site_id=filter_values.get("site_id"),
        pop_name=filter_values.get("pop_name"),
        connection_type=filter_values.get("connection_type"),
        technology=None,
        pl_count=filter_values.get("pl_count"),
    )

    # CRITICAL FIX: Always group by circle to ensure we only count sites that meet
    # the 3-day threshold WITHIN a single circle, not across multiple circles.
    # This makes the circle breakdown sum consistent with the overall summary.
    rows = (
        base_q
        .group_by(site_key_expr, tech_class_expr, ReportMetadata.circle)
        .having(func.count(func.distinct(ReportMetadata.report_date)) >= 3)
        .all()
    )

    # Collect qualifying sites from all circles
    # A site is qualifying if it meets the threshold in ANY circle
    qualifying: Dict[str, set] = {"VOICE": set(), "4G": set(), "5G": set()}
    for site_key, tech_class, _ in rows:
        if tech_class in qualifying:
            qualifying[tech_class].add(site_key)

    return qualifying


def _build_history_query(
    db: Session,
    *,
    circle: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    technology: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
):
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
    )

    normalized_circle = _normalize_circle(circle)
    if normalized_circle:
        if normalized_circle == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == normalized_circle)

    if start_date:
        query = query.filter(ReportMetadata.report_date >= date.fromisoformat(start_date))
    if end_date:
        query = query.filter(ReportMetadata.report_date <= date.fromisoformat(end_date))

    query = apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=technology,
        pl_count=pl_count,
    )

    if technology:
        normalized_technology = _normalize_text(technology)
        if normalized_technology:
            query = query.filter(
                func.lower(func.trim(PacketLossData.twamp_technology)).like(
                    f"%{normalized_technology.lower()}%"
                )
            )

    return query


def _serialize_history_rows(rows: List[PacketLossData]) -> List[Dict[str, Any]]:
    serialized = []
    for row in rows:
        serialized.append(
            {
                "id": row.id,
                "report_id": row.report_id,
                "report_date": row.report.report_date.isoformat() if row.report else None,
                "circle": row.report.circle if row.report else None,
                "site_id": row.site_id,
                "site_name": row.site_name,
                "pop": row.pop_name,
                "technology": row.twamp_technology,
                "connection_type": row.connection_type,
                "pl_count": row.packet_loss_05_90_percent_count,
                "aging": row.packet_loss_ageing,
                "pl_hours": row.no_of_hrs_session_having_pl_05_90_count,
            }
        )
    return serialized


def _calculate_period_stats(
    db: Session,
    start: date,
    end: date,
    circle: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
) -> Dict[str, Any]:
    """Calculate per-period stats using pure SQL aggregation.

    Voice / 4G / 5G counts = distinct qualifying sites (>= 3 days above threshold).
    Average PL = mean of pl_count_num across all rows with qualifying tech/threshold.
    This approach never pulls rows into Python memory.
    """
    filters: Dict[str, Any] = {
        "circle": circle,
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "pop_name": pop_name,
        "connection_type": connection_type,
        "site_id": site_id,
        "pl_count": pl_count,
        "search": search,
    }

    # ── 1. Count of distinct qualifying sites per tech (fast SQL GROUP BY / HAVING) ──
    qualifying = _get_qualifying_site_keys(db, filters)
    voice_count   = len(qualifying["VOICE"])
    four_g_count  = len(qualifying["4G"])
    five_g_count  = len(qualifying["5G"])

    # ── 2. Average PL per tech (single aggregate query, no row download) ──
    tech_class_expr = PacketLossData.technology_class
    pl_count_num    = PacketLossData.pl_count_num

    normalized_circle = _normalize_circle(circle)
    avg_base = (
        db.query(
            tech_class_expr.label("tech_class"),
            func.avg(pl_count_num).label("avg_pl"),
        )
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(
            ReportMetadata.report_date >= start,
            ReportMetadata.report_date <= end,
            or_(
                and_(tech_class_expr == "VOICE", pl_count_num >= 14),
                and_(tech_class_expr == "4G",    pl_count_num >= 60),
                and_(tech_class_expr == "5G",    pl_count_num >= 60),
            )
        )
    )

    if normalized_circle:
        if normalized_circle == "BIH":
            avg_base = avg_base.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            avg_base = avg_base.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            avg_base = avg_base.filter(ReportMetadata.circle == normalized_circle)

    avg_base = apply_packet_loss_filters(
        avg_base,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=None,
        pl_count=pl_count,
    )

    avg_rows = avg_base.group_by(tech_class_expr).all()
    avg_map  = {row.tech_class: float(row.avg_pl or 0.0) for row in avg_rows}

    # ── 3. total_records / total_reports (cheap counts) ──
    count_base = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(
            ReportMetadata.report_date >= start,
            ReportMetadata.report_date <= end,
        )
    )
    if normalized_circle:
        if normalized_circle == "BIH":
            count_base = count_base.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            count_base = count_base.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            count_base = count_base.filter(ReportMetadata.circle == normalized_circle)
    count_base = apply_packet_loss_filters(
        count_base,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=None,
        pl_count=pl_count,
    )
    total_records = count_base.count()

    total_reports_q = (
        db.query(ReportMetadata)
        .filter(
            ReportMetadata.report_date >= start,
            ReportMetadata.report_date <= end,
        )
    )
    if normalized_circle:
        total_reports_q = total_reports_q.filter(ReportMetadata.circle == normalized_circle)
    total_reports = total_reports_q.count()

    return {
        "total_records": total_records,
        "total_reports": total_reports,
        "voice_count":  voice_count,
        "four_g_count": four_g_count,
        "five_g_count": five_g_count,
        "voice_avg":    avg_map.get("VOICE", 0.0),
        "four_g_avg":   avg_map.get("4G",    0.0),
        "five_g_avg":   avg_map.get("5G",    0.0),
    }


@ttl_cache
def get_dashboard_summary(db: Session, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    started_at = time.perf_counter()
    db_time = 0.0
    filter_values = filters or {}

    period_filter_kwargs = {
        "circle": filter_values.get("circle"),
        "pop_name": filter_values.get("pop_name"),
        "connection_type": filter_values.get("connection_type"),
        "site_id": filter_values.get("site_id"),
        "pl_count": filter_values.get("pl_count"),
        "search": filter_values.get("search"),
    }

    t_db = time.perf_counter()
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    db_time += time.perf_counter() - t_db

    # Always anchor to the latest available data date
    latest_date = latest_report.report_date if latest_report else datetime.utcnow().date()

    end_dt = None
    user_supplied_dates = bool(filter_values.get("end_date") or filter_values.get("start_date"))
    if filter_values.get("end_date"):
        end_dt = date.fromisoformat(filter_values["end_date"])
    else:
        end_dt = latest_date
        
    start_dt = None
    if filter_values.get("start_date"):
        start_dt = date.fromisoformat(filter_values["start_date"])
    else:
        start_dt = end_dt - timedelta(days=6)
        
    num_days = (end_dt - start_dt).days + 1
    prev_start_dt = start_dt - timedelta(days=num_days)
    prev_end_dt = start_dt - timedelta(days=1)

    current_stats = _calculate_period_stats(
        db,
        start_dt,
        end_dt,
        **period_filter_kwargs,
    )

    # If user chose dates that have no data, fall back to the window around the latest report
    if current_stats["total_records"] == 0 and user_supplied_dates:
        end_dt = latest_date
        start_dt = end_dt - timedelta(days=6)
        prev_start_dt = start_dt - timedelta(days=num_days)
        prev_end_dt = start_dt - timedelta(days=1)
        current_stats = _calculate_period_stats(
            db,
            start_dt,
            end_dt,
            **period_filter_kwargs,
        )
    
    prev_stats = _calculate_period_stats(
        db,
        prev_start_dt,
        prev_end_dt,
        **period_filter_kwargs,
    )

    def pct_change(curr, prev):
        if prev == 0:
            return 0.0
        return round(((curr - prev) / prev) * 100, 1)

    result = {
        "latest_upload_date": latest_report.report_date.isoformat() if latest_report else None,
        "data_start_date": start_dt.isoformat(),
        "data_end_date": end_dt.isoformat(),
        "total_reports": current_stats["total_reports"],
        "total_records": current_stats["total_records"],
        
        "voice_count": round(current_stats["voice_count"], 2),
        "voice_count_change": pct_change(current_stats["voice_count"], prev_stats["voice_count"]),
        
        "five_g_count": round(current_stats["five_g_count"], 2),
        "five_g_count_change": pct_change(current_stats["five_g_count"], prev_stats["five_g_count"]),
        
        "four_g_count": round(current_stats["four_g_count"], 2),
        "four_g_count_change": pct_change(current_stats["four_g_count"], prev_stats["four_g_count"]),
        
        "voice_avg_pl": round(current_stats["voice_avg"], 2),
        "voice_avg_pl_change": pct_change(current_stats["voice_avg"], prev_stats["voice_avg"]),
        
        "five_g_avg_pl": round(current_stats["five_g_avg"], 2),
        "five_g_avg_pl_change": pct_change(current_stats["five_g_avg"], prev_stats["five_g_avg"]),
        
        "four_g_avg_pl": round(current_stats["four_g_avg"], 2),
        "four_g_avg_pl_change": pct_change(current_stats["four_g_avg"], prev_stats["four_g_avg"]),
    }

    return result


@ttl_cache
def get_dashboard_trend_7days(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    end_dt = date.fromisoformat(filters["end_date"]) if filters and filters.get("end_date") else (latest_report.report_date if latest_report else datetime.utcnow().date())
    start_dt = date.fromisoformat(filters["start_date"]) if filters and filters.get("start_date") else (end_dt - timedelta(days=6))

    window_filters = dict(filters or {})
    window_filters["start_date"] = start_dt.isoformat()
    window_filters["end_date"] = end_dt.isoformat()

    # Step 1: Get qualifying sites using pure SQL GROUP BY / HAVING (fast)
    qualifying = _get_qualifying_site_keys(db, window_filters)
    qvoice = list(qualifying["VOICE"])
    q4g    = list(qualifying["4G"])
    q5g    = list(qualifying["5G"])

    tech_class_expr = PacketLossData.technology_class
    site_name_norm  = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm    = func.nullif(func.trim(PacketLossData.site_id), "")
    # Prefer site_id for dedup because site_name can vary across voice/data rows
    # for the same physical site and inflate week-wise unique counts.
    site_key_expr   = func.upper(func.coalesce(site_id_norm, site_name_norm))

    # Step 2: DB-level count of distinct qualifying sites per day per tech class.
    # A site only contributes to a day if it exceeded the threshold on that day.
    def _count_per_day(site_keys: list, tech_class: str, threshold: float):
        if not site_keys:
            return []
        return (
            db.query(
                ReportMetadata.report_date.label("r_date"),
                func.count(func.distinct(site_key_expr)).label("cnt"),
            )
            .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
            .filter(
                tech_class_expr == tech_class,
                site_key_expr.in_(site_keys),
                PacketLossData.pl_count_num >= threshold,
                ReportMetadata.report_date >= start_dt,
                ReportMetadata.report_date <= end_dt,
            )
            .group_by(ReportMetadata.report_date)
            .all()
        )

    voice_rows  = _count_per_day(qvoice, "VOICE", 14)
    four_g_rows = _count_per_day(q4g,   "4G",    60)
    five_g_rows = _count_per_day(q5g,   "5G",    60)

    # Build daily map
    daily_map: Dict = {}
    current = start_dt
    while current <= end_dt:
        daily_map[current] = {"4G_Data": 0, "5G_Data": 0, "4G_Voice": 0}
        current += timedelta(days=1)

    for r_date, cnt in voice_rows:
        if r_date in daily_map:
            daily_map[r_date]["4G_Voice"] = cnt
    for r_date, cnt in four_g_rows:
        if r_date in daily_map:
            daily_map[r_date]["4G_Data"] = cnt
    for r_date, cnt in five_g_rows:
        if r_date in daily_map:
            daily_map[r_date]["5G_Data"] = cnt

    result = []
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for r_date, counts in sorted(daily_map.items()):
        result.append({
            "date": r_date.isoformat(),
            "day": day_names[r_date.weekday()],
            "four_g_data": counts["4G_Data"],
            "five_g_data": counts["5G_Data"],
            "four_g_voice": counts["4G_Voice"],
        })
    return result


@ttl_cache
def get_dashboard_trend_wow(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    filter_values = filters or {}
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    end_dt = (
        date.fromisoformat(filter_values["end_date"])
        if filter_values.get("end_date")
        else (latest_report.report_date if latest_report else datetime.utcnow().date())
    )
    start_dt = (
        date.fromisoformat(filter_values["start_date"])
        if filter_values.get("start_date")
        else end_dt - timedelta(weeks=10)
    )

    # Guard against reversed input dates.
    if start_dt > end_dt:
        start_dt, end_dt = end_dt, start_dt

    # Build the ordered list of Monday-aligned week-start dates for the result
    week_starts: List[date] = []
    start_week = start_dt - timedelta(days=start_dt.weekday())
    end_week = end_dt - timedelta(days=end_dt.weekday())
    curr = start_week
    while curr <= end_week:
        week_starts.append(curr)
        curr += timedelta(days=7)

    tech_class_expr = PacketLossData.technology_class
    pl_count_num    = PacketLossData.pl_count_num
    site_name_norm  = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm    = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr   = func.coalesce(site_name_norm, site_id_norm)

    # SQLite: date('report_date', 'weekday 0', '-6 days') → Monday of the week
    week_start_expr = func.date(
        ReportMetadata.report_date, "weekday 0", "-6 days"
    )

    # Single query: for each (site, tech_class, week), count distinct days with PL >= threshold
    # Then HAVING >= 3 keeps only qualifying (site, tech, week) combos
    inner_q = (
        db.query(
            site_key_expr.label("site_key"),
            tech_class_expr.label("tech_class"),
            week_start_expr.label("week_monday"),
            func.count(func.distinct(ReportMetadata.report_date)).label("distinct_days"),
        )
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(
            ReportMetadata.report_date >= start_dt,
            ReportMetadata.report_date <= end_dt,
            site_key_expr.isnot(None),
            or_(
                and_(tech_class_expr == "VOICE", pl_count_num >= 14),
                and_(tech_class_expr == "4G",    pl_count_num >= 60),
                and_(tech_class_expr == "5G",    pl_count_num >= 60),
            ),
        )
    )

    # Apply circle / extra filters
    circle = _normalize_circle(filter_values.get("circle"))
    if circle:
        if circle == "BIH":
            inner_q = inner_q.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif circle == "JHK":
            inner_q = inner_q.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            inner_q = inner_q.filter(ReportMetadata.circle == circle)

    inner_q = apply_packet_loss_filters(
        inner_q,
        search=filter_values.get("search"),
        site_id=filter_values.get("site_id"),
        pop_name=filter_values.get("pop_name"),
        connection_type=filter_values.get("connection_type"),
        technology=None,
        pl_count=filter_values.get("pl_count"),
    )

    # Group and keep only qualifying (site, tech, week) rows
    qualifying_rows = (
        inner_q
        .group_by(site_key_expr, tech_class_expr, week_start_expr)
        .having(func.count(func.distinct(ReportMetadata.report_date)) >= 3)
        .all()
    )

    # Aggregate in Python — only a few hundred rows at most
    weekly_map: Dict = {ws: {"4G": set(), "5G": set()} for ws in week_starts}
    for site_key, tech_class, week_monday_str, _ in qualifying_rows:
        try:
            ws = date.fromisoformat(str(week_monday_str))
        except (ValueError, TypeError):
            continue
        if ws not in weekly_map:
            continue
        if tech_class in ("VOICE", "4G"):
            weekly_map[ws]["4G"].add(site_key)
        elif tech_class == "5G":
            weekly_map[ws]["5G"].add(site_key)

    result = []
    for ws in week_starts:
        week_visible_start = max(ws, start_dt)
        week_visible_end = min(ws + timedelta(days=6), end_dt)
        result.append({
            "week_label": f"{week_visible_start.strftime('%d %b')} - {week_visible_end.strftime('%d %b')}",
            "week_start": ws.isoformat(),
            "four_g":     len(weekly_map[ws]["4G"]),
            "five_g":     len(weekly_map[ws]["5G"]),
        })

    return result


@ttl_cache
def get_dashboard_backhaul(db: Session, filters: Optional[Dict[str, Any]] = None) -> Dict[str, List[Dict[str, Any]]]:
    qualifying = _get_qualifying_site_keys(db, filters)

    query = _build_history_query(
        db,
        circle=filters.get("circle") if filters else None,
        start_date=filters.get("start_date") if filters else None,
        end_date=filters.get("end_date") if filters else None,
        technology=filters.get("technology") if filters else None,
        pop_name=filters.get("pop_name") if filters else None,
        connection_type=filters.get("connection_type") if filters else None,
        site_id=filters.get("site_id") if filters else None,
        pl_count=filters.get("pl_count") if filters else None,
        search=filters.get("search") if filters else None,
    )

    tech_class_expr = PacketLossData.technology_class
    pl_count_expr = PacketLossData.pl_count_num
    site_name_norm = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr = func.coalesce(site_name_norm, site_id_norm)

    conn_trimmed = func.trim(PacketLossData.connection_type)
    conn_group = case(
        (conn_trimmed.in_(["MW", "UBR", "FTTH", "Fiber"]), conn_trimmed),
        else_="MW",
    )

    q5g_list = list(qualifying["5G"])
    q4g_list = list(qualifying["4G"])
    qvoice_list = list(qualifying["VOICE"])
    q4g_and_voice_list = list(set(q4g_list + qvoice_list))  # Combine 4G and Voice

    # 5G backhaul counts only 5G records
    cond_5g = and_(tech_class_expr == "5G", pl_count_expr >= 60, site_key_expr.in_(q5g_list)) if q5g_list else False
    # 4G backhaul counts both 4G data and Voice traffic (combined)
    cond_4g = and_(
        tech_class_expr.in_(["4G", "VOICE"]),
        pl_count_expr >= 60,
        site_key_expr.in_(q4g_and_voice_list)
    ) if q4g_and_voice_list else False

    rows = query.with_entities(
        conn_group.label("conn_group"),
        func.count(func.distinct(case((cond_5g, site_key_expr), else_=None))).label("five_g_count"),
        func.count(func.distinct(case((cond_4g, site_key_expr), else_=None))).label("four_g_count"),
    ).group_by(conn_group).all()

    five_g_sum = {"MW": 0, "UBR": 0, "FTTH": 0, "Fiber": 0}
    four_g_sum = {"MW": 0, "UBR": 0, "Fiber": 0, "FTTH": 0}

    for row in rows:
        conn = row.conn_group if row.conn_group in five_g_sum else "MW"
        five_g_sum[conn] += int(row.five_g_count or 0)
        four_g_sum[conn] += int(row.four_g_count or 0)
                
    result = {
        "five_g": [{"name": name, "value": val} for name, val in sorted(five_g_sum.items(), key=lambda x: x[1], reverse=True)],
        "four_g": [{"name": name, "value": val} for name, val in sorted(four_g_sum.items(), key=lambda x: x[1], reverse=True)]
    }
    return result


def get_dashboard_technology(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    qualifying = _get_qualifying_site_keys(db, filters)

    tech_class_expr = PacketLossData.technology_class
    site_name_norm  = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm    = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr   = func.coalesce(site_name_norm, site_id_norm)

    q5g    = list(qualifying["5G"])
    q4g    = list(qualifying["4G"])
    qvoice = list(qualifying["VOICE"])

    mapping = {"VOICE": "Voice", "5G": "5G", "4G": "4G"}
    summary: Dict[str, float] = {}

    for tech_class, site_keys, threshold in [
        ("VOICE", qvoice, 14),
        ("4G",    q4g,    60),
        ("5G",    q5g,    60),
    ]:
        if not site_keys:
            continue
        row = (
            db.query(func.sum(PacketLossData.pl_count_num).label("total_pl"))
            .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
            .filter(
                tech_class_expr == tech_class,
                PacketLossData.pl_count_num >= threshold,
                site_key_expr.in_(site_keys),
            )
            .scalar()
        )
        name = mapping.get(tech_class, "Other")
        summary[name] = float(row or 0.0)

    return [{"name": name, "value": round(value, 2)} for name, value in sorted(summary.items())]


@ttl_cache
def get_dashboard_top_sites(
    db: Session,
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    started_at = time.perf_counter()
    db_time = 0.0
    filter_values = filters or {}

    total_pl_minutes_expr = _packet_loss_minutes_expression()
    pl_count_expr = _pl_count_sql_expression()
    site_id_trimmed = func.nullif(func.trim(PacketLossData.site_id), "")
    site_name_trimmed = func.nullif(func.trim(PacketLossData.site_name), "")
    technology_trimmed = func.nullif(func.trim(PacketLossData.twamp_technology), "")
    backhaul_trimmed = func.nullif(func.trim(PacketLossData.connection_type), "")
    site_id_display_expr = func.coalesce(site_id_trimmed, site_name_trimmed, literal("N/A"))
    site_key_expr = func.coalesce(site_name_trimmed, site_id_trimmed)
    site_id_found_expr = and_(PacketLossData.site_id.isnot(None), func.trim(PacketLossData.site_id) != "")
    technology_class_expr = _technology_class_sql_expression()
    technology_lower = func.lower(func.trim(PacketLossData.twamp_technology))
    allowed_technology_expr = technology_class_expr.in_(["VOICE", "5G", "4G"])

    query = db.query(
        PacketLossData.id.label("record_id"),
        ReportMetadata.report_date.label("report_date"),
        PacketLossData.site_id.label("site_id"),
        PacketLossData.site_name.label("site_name"),
        PacketLossData.twamp_technology.label("technology"),
        PacketLossData.connection_type.label("backhaul"),
        PacketLossData.pop_name.label("pop_name"),
        PacketLossData.packet_loss_05_90_percent_count.label("pl_count"),
        total_pl_minutes_expr.label("total_pl_minutes"),
        site_id_display_expr.label("site_id_display"),
        site_id_found_expr.label("site_id_found"),
    ).join(
        ReportMetadata,
        PacketLossData.report_id == ReportMetadata.id,
    )

    circle_value = _normalize_circle(filter_values.get("circle"))
    if circle_value:
        if circle_value == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif circle_value == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == circle_value)

    report_date_value = _parse_iso_date(filter_values.get("report_date"))
    if report_date_value:
        query = query.filter(ReportMetadata.report_date == report_date_value)
    else:
        start_date_value = _parse_iso_date(filter_values.get("start_date"))
        end_date_value = _parse_iso_date(filter_values.get("end_date"))
        if start_date_value:
            query = query.filter(ReportMetadata.report_date >= start_date_value)
        if end_date_value:
            query = query.filter(ReportMetadata.report_date <= end_date_value)

    site_query = _normalize_text(filter_values.get("site_query") or filter_values.get("search"))
    if site_query:
        search_term = f"%{site_query.lower()}%"
        query = query.filter(
            func.lower(func.trim(PacketLossData.site_id)).like(search_term)
            | func.lower(func.trim(PacketLossData.site_name)).like(search_term)
            | func.lower(func.trim(PacketLossData.pop_name)).like(search_term)
        )

    backhaul_value = _normalize_text(filter_values.get("backhaul"))
    if backhaul_value:
        query = query.filter(func.lower(func.trim(PacketLossData.connection_type)).like(f"%{backhaul_value.lower()}%"))

    technology_filter = _normalize_top_site_technology(filter_values.get("technology"))
    if technology_filter == "4G_Voice":
        query = query.filter(technology_class_expr == "VOICE")
    elif technology_filter == "5G_Data":
        query = query.filter(technology_class_expr == "5G")
    elif technology_filter == "4G_Data":
        query = query.filter(technology_class_expr == "4G")
    elif technology_filter:
        query = query.filter(func.lower(func.trim(PacketLossData.twamp_technology)).like(f"%{technology_filter.lower()}%"))

    site_id_status = _normalize_text(filter_values.get("site_id_status"))
    if site_id_status == "Found":
        query = query.filter(site_id_found_expr)
    elif site_id_status == "Not Found":
        query = query.filter(~site_id_found_expr)

    query = query.filter(allowed_technology_expr)

    qualifying = _get_qualifying_site_keys(db, filters)
    qvoice_list = list(qualifying["VOICE"])
    q4g_list = list(qualifying["4G"])
    q5g_list = list(qualifying["5G"])

    conditions = []
    if qvoice_list:
        conditions.append(and_(technology_class_expr == "VOICE", pl_count_expr >= 14, site_key_expr.in_(qvoice_list)))
    if q4g_list:
        conditions.append(and_(technology_class_expr == "4G", pl_count_expr >= 60, site_key_expr.in_(q4g_list)))
    if q5g_list:
        conditions.append(and_(technology_class_expr == "5G", pl_count_expr >= 60, site_key_expr.in_(q5g_list)))

    if conditions:
        query = query.filter(or_(*conditions))
    else:
        query = query.filter(False)

    sort_by = _normalize_text(filter_values.get("sort_by")) or "pl_count"
    sort_dir = (_normalize_text(filter_values.get("sort_dir")) or "desc").lower()
    sort_options = {
        "total_pl_minutes": total_pl_minutes_expr,
        "pl_count": pl_count_expr,
        "site_id": site_id_display_expr,
        "technology": technology_trimmed,
        "report_date": ReportMetadata.report_date,
    }
    sort_expression = sort_options.get(sort_by, pl_count_expr)
    sort_is_desc = sort_dir != "asc"

    t_db = time.perf_counter()
    # Count distinct (site_key, technology_class) pairs instead of raw records
    site_key_expr_count = func.coalesce(
        func.nullif(func.trim(PacketLossData.site_name), ""),
        func.nullif(func.trim(PacketLossData.site_id), "")
    )
    distinct_sites_query = (
        db.query(func.count(func.distinct(
            func.concat(site_key_expr_count, "_", technology_class_expr)
        )))
        .select_from(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
    )
    
    # Apply same filters as main query
    distinct_sites_query = distinct_sites_query.filter(allowed_technology_expr)
    
    if circle_value:
        if circle_value == "BIH":
            distinct_sites_query = distinct_sites_query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif circle_value == "JHK":
            distinct_sites_query = distinct_sites_query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            distinct_sites_query = distinct_sites_query.filter(ReportMetadata.circle == circle_value)
    
    if report_date_value:
        distinct_sites_query = distinct_sites_query.filter(ReportMetadata.report_date == report_date_value)
    else:
        if start_date_value:
            distinct_sites_query = distinct_sites_query.filter(ReportMetadata.report_date >= start_date_value)
        if end_date_value:
            distinct_sites_query = distinct_sites_query.filter(ReportMetadata.report_date <= end_date_value)
    
    if site_query:
        search_term = f"%{site_query.lower()}%"
        distinct_sites_query = distinct_sites_query.filter(
            func.lower(func.trim(PacketLossData.site_id)).like(search_term)
            | func.lower(func.trim(PacketLossData.site_name)).like(search_term)
            | func.lower(func.trim(PacketLossData.pop_name)).like(search_term)
        )
    
    if backhaul_value:
        distinct_sites_query = distinct_sites_query.filter(func.lower(func.trim(PacketLossData.connection_type)).like(f"%{backhaul_value.lower()}%"))
    
    if technology_filter == "4G_Voice":
        distinct_sites_query = distinct_sites_query.filter(technology_class_expr == "VOICE")
    elif technology_filter == "5G_Data":
        distinct_sites_query = distinct_sites_query.filter(technology_class_expr == "5G")
    elif technology_filter == "4G_Data":
        distinct_sites_query = distinct_sites_query.filter(technology_class_expr == "4G")
    elif technology_filter:
        distinct_sites_query = distinct_sites_query.filter(func.lower(func.trim(PacketLossData.twamp_technology)).like(f"%{technology_filter.lower()}%"))
    
    if site_id_status == "Found":
        distinct_sites_query = distinct_sites_query.filter(site_id_found_expr)
    elif site_id_status == "Not Found":
        distinct_sites_query = distinct_sites_query.filter(~site_id_found_expr)
    
    if conditions:
        distinct_sites_query = distinct_sites_query.filter(or_(*conditions))
    else:
        distinct_sites_query = distinct_sites_query.filter(False)
    
    total_records = distinct_sites_query.scalar() or 0
    db_time += time.perf_counter() - t_db

    page_raw = filter_values.get("page", 1)
    try:
        page = max(int(page_raw), 1)
    except (TypeError, ValueError):
        page = 1

    page_size_raw = filter_values.get("page_size", 25)
    is_all_rows = isinstance(page_size_raw, str) and page_size_raw.strip().lower() == "all"
    if is_all_rows:
        effective_page_size = None
    else:
        try:
            effective_page_size = max(int(page_size_raw), 1)
        except (TypeError, ValueError):
            effective_page_size = 25

    if total_records == 0:
        total_pages = 0
        page = 1
    elif effective_page_size is None:
        total_pages = 1
        page = 1
    else:
        total_pages = math.ceil(total_records / effective_page_size)
        page = min(page, total_pages)

    if sort_is_desc:
        order_by_clause = [sort_expression.desc(), ReportMetadata.report_date.desc(), PacketLossData.id.desc()]
    else:
        order_by_clause = [sort_expression.asc(), ReportMetadata.report_date.asc(), PacketLossData.id.asc()]

    t_db = time.perf_counter()
    paged_query = query.order_by(*order_by_clause)
    if effective_page_size is not None:
        paged_query = paged_query.offset((page - 1) * effective_page_size).limit(effective_page_size)
    rows = paged_query.all()
    db_time += time.perf_counter() - t_db

    t_processing = time.perf_counter()
    result_rows: List[Dict[str, Any]] = []
    page_offset = (page - 1) * effective_page_size if effective_page_size is not None else 0
    for idx, row in enumerate(rows):
        site_name = _normalize_text(row.site_name)
        site_id_raw = _normalize_text(row.site_id)
        site_id_display = _normalize_text(row.site_id_display) or site_name or "N/A"
        technology_value = _normalize_top_site_technology(row.technology) or site_name or "N/A"
        result_rows.append(
            {
                "rank": page_offset + idx + 1,
                "site_id": site_id_display,
                "site_id_raw": site_id_raw,
                "site_name": site_name or "N/A",
                "pop_name": _normalize_text(row.pop_name) or "N/A",
                "technology": technology_value,
                "backhaul": _normalize_text(row.backhaul) or "N/A",
                "total_pl_minutes": round(_parse_numeric(row.total_pl_minutes), 2),
                "pl_count": round(_parse_numeric(row.pl_count), 2),
                "report_date": row.report_date.isoformat() if row.report_date else None,
                "site_id_status": "Found" if row.site_id_found else "Not Found",
            }
        )
    processing_time = time.perf_counter() - t_processing

    # Count unique sites by technology
    voice_count = len(qvoice_list) if qvoice_list else 0
    four_g_count = len(q4g_list) if q4g_list else 0
    five_g_count = len(q5g_list) if q5g_list else 0
    total_sites = voice_count + four_g_count + five_g_count

    _log = {
        "summary": {
            "total_sites": total_sites,
            "voice_count": voice_count,
            "four_g_count": four_g_count,
            "five_g_count": five_g_count,
        },
        "total_records": total_records,
        "page": page,
        "page_size": "All" if effective_page_size is None else effective_page_size,
        "total_pages": total_pages,
        "rows": result_rows,
    }
    return _log


@ttl_cache
def get_dashboard_circle_breakdown(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Per-circle stats: total PL events, records, sites affected, breakdown by tech.
    Uses SQL GROUP BY + HAVING to apply the 3-day rule entirely in the database."""
    circles = [("BIH", ["BIH", "BHK", "bih", "BIHAR", "bihar"]), ("JHK", ["JHK", "jhk"])]
    result = []

    tech_class_expr = PacketLossData.technology_class
    pl_count_num    = PacketLossData.pl_count_num
    site_name_norm  = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm    = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr   = func.coalesce(site_name_norm, site_id_norm)

    is_voice_expr    = tech_class_expr == "VOICE"
    is_5g_expr       = tech_class_expr == "5G"
    is_4g_data_expr  = tech_class_expr == "4G"

    for label, codes in circles:
        circle_filters = dict(filters or {})
        circle_filters["circle"] = label
        qualifying = _get_qualifying_site_keys(db, circle_filters)

        voice_pl  = len(qualifying["VOICE"])
        four_g_pl = len(qualifying["4G"])
        five_g_pl = len(qualifying["5G"])
        all_qual_sites = qualifying["VOICE"] | qualifying["4G"] | qualifying["5G"]
        sites_affected = len(all_qual_sites)

        # Sum PL hours for all qualifying sites in this circle
        hrs_q = (
            db.query(func.sum(_numeric_sql_expression(PacketLossData.no_of_hrs_session_having_pl_05_90_count)))
            .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
            .filter(ReportMetadata.circle.in_(codes))
        )
        if filters:
            if filters.get("start_date"):
                hrs_q = hrs_q.filter(ReportMetadata.report_date >= date.fromisoformat(filters["start_date"]))
            if filters.get("end_date"):
                hrs_q = hrs_q.filter(ReportMetadata.report_date <= date.fromisoformat(filters["end_date"]))
        if all_qual_sites:
            hrs_q = hrs_q.filter(site_key_expr.in_(list(all_qual_sites)))
        total_hrs = float(hrs_q.scalar() or 0.0)

        circle_label = "Bihar Circle" if label == "BIH" else "Jharkhand Circle"
        result.append({
            "circle": circle_label,
            "circle_code": label,
            "total_pl_count": voice_pl + four_g_pl + five_g_pl,
            "total_pl_hours": round(total_hrs, 2),
            "four_g_pl":      four_g_pl,
            "five_g_pl":      five_g_pl,
            "voice_pl":       voice_pl,
            "sites_affected": sites_affected,
        })
    return result


def get_dashboard_history(
    db: Session,
    *,
    circle: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    technology: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
    skip: int = 0,
    limit: int = 20,
) -> Dict[str, Any]:
    filters = {
        "circle": circle,
        "start_date": start_date,
        "end_date": end_date,
        "technology": technology,
        "pop_name": pop_name,
        "connection_type": connection_type,
        "site_id": site_id,
        "pl_count": pl_count,
        "search": search,
    }
    qualifying = _get_qualifying_site_keys(db, filters)

    query = _build_history_query(
        db,
        circle=circle,
        start_date=start_date,
        end_date=end_date,
        technology=technology,
        pop_name=pop_name,
        connection_type=connection_type,
        site_id=site_id,
        pl_count=pl_count,
        search=search,
    )

    site_name_norm = func.nullif(func.trim(PacketLossData.site_name), "")
    site_id_norm = func.nullif(func.trim(PacketLossData.site_id), "")
    site_key_expr = func.coalesce(site_name_norm, site_id_norm)
    technology_class_expr = _technology_class_sql_expression()

    qvoice_list = list(qualifying["VOICE"])
    q4g_list = list(qualifying["4G"])
    q5g_list = list(qualifying["5G"])

    conditions = []
    if qvoice_list:
        conditions.append(and_(technology_class_expr == "VOICE", site_key_expr.in_(qvoice_list)))
    if q4g_list:
        conditions.append(and_(technology_class_expr == "4G", site_key_expr.in_(q4g_list)))
    if q5g_list:
        conditions.append(and_(technology_class_expr == "5G", site_key_expr.in_(q5g_list)))

    if conditions:
        query = query.filter(or_(*conditions))
    else:
        query = query.filter(False)

    total = query.count()
    rows = (
        query.options(joinedload(PacketLossData.report))
        .order_by(ReportMetadata.report_date.desc(), PacketLossData.created_at.desc(), PacketLossData.id.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return {
        "total": total,
        "rows": _serialize_history_rows(rows),
    }

