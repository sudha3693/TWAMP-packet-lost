from datetime import date

from src.services.dashboard import _collect_qualifying_sites


def test_collect_qualifying_sites_requires_three_distinct_days():
    rows = [
        {"report_date": date(2024, 1, 1), "site_key": "site-a", "technology_class": "VOICE", "pl_count_num": 14},
        {"report_date": date(2024, 1, 2), "site_key": "site-a", "technology_class": "VOICE", "pl_count_num": 14},
        {"report_date": date(2024, 1, 3), "site_key": "site-a", "technology_class": "VOICE", "pl_count_num": 14},
        {"report_date": date(2024, 1, 1), "site_key": "site-b", "technology_class": "VOICE", "pl_count_num": 14},
        {"report_date": date(2024, 1, 2), "site_key": "site-b", "technology_class": "VOICE", "pl_count_num": 13},
        {"report_date": date(2024, 1, 3), "site_key": "site-b", "technology_class": "VOICE", "pl_count_num": 13},
        {"report_date": date(2024, 1, 1), "site_key": "site-c", "technology_class": "4G", "pl_count_num": 60},
        {"report_date": date(2024, 1, 2), "site_key": "site-c", "technology_class": "4G", "pl_count_num": 60},
        {"report_date": date(2024, 1, 4), "site_key": "site-c", "technology_class": "4G", "pl_count_num": 60},
        {"report_date": date(2024, 1, 1), "site_key": "site-d", "technology_class": "5G", "pl_count_num": 60},
        {"report_date": date(2024, 1, 2), "site_key": "site-d", "technology_class": "5G", "pl_count_num": 60},
        {"report_date": date(2024, 1, 3), "site_key": "site-d", "technology_class": "5G", "pl_count_num": 60},
    ]

    qualifying = _collect_qualifying_sites(rows)

    assert qualifying["VOICE"] == {"site-a"}
    assert qualifying["4G"] == {"site-c"}
    assert qualifying["5G"] == {"site-d"}
