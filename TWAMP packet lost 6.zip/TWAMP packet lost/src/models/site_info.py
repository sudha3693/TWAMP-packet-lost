from sqlalchemy import Column, String
from src.database import Base

class SiteInfo(Base):
    __tablename__ = "site_info"

    site_id = Column(String, primary_key=True, index=True)
    cluster = Column(String, nullable=False)
    district = Column(String, nullable=False)

    def __repr__(self):
        return f"<SiteInfo site_id={self.site_id!r} cluster={self.cluster!r} district={self.district!r}>"
