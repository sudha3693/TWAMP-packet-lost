import io
import time
import csv
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
import openpyxl

from src.database import get_db
from src.models.site_info import SiteInfo
from src.services.dashboard import clear_dashboard_cache

router = APIRouter()

def normalize_header(headers: List[str]) -> Dict[str, str]:
    header_map = {}
    for h in headers:
        if not h:
            continue
        norm = str(h).strip().lower().replace("_", "").replace(" ", "")
        if norm in ("siteid", "site_id"):
            header_map["site_id"] = h
        elif norm == "cluster":
            header_map["cluster"] = h
        elif norm == "district":
            header_map["district"] = h
    return header_map

def parse_csv_data(contents: bytes) -> List[Dict[str, str]]:
    try:
        decoded = contents.decode("utf-8-sig")
    except UnicodeDecodeError:
        try:
            decoded = contents.decode("latin-1")
        except Exception as e:
            raise ValueError(f"Failed to decode file encoding: {str(e)}")

    reader = csv.reader(io.StringIO(decoded))
    try:
        headers = next(reader)
    except StopIteration:
        raise ValueError("The uploaded file is empty.")

    header_map = normalize_header(headers)
    missing = [col for col in ["site_id", "cluster", "district"] if col not in header_map]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}. Detected headers: {headers}")

    site_id_col = header_map["site_id"]
    cluster_col = header_map["cluster"]
    district_col = header_map["district"]

    site_id_idx = headers.index(site_id_col)
    cluster_idx = headers.index(cluster_col)
    district_idx = headers.index(district_col)

    rows_data = []
    for row_num, row in enumerate(reader, start=2):
        if not row or all(not str(val).strip() for val in row):
            continue
        
        if len(row) <= max(site_id_idx, cluster_idx, district_idx):
            raise ValueError(f"Row {row_num} has fewer columns than required.")

        site_id = str(row[site_id_idx]).strip()
        cluster = str(row[cluster_idx]).strip()
        district = str(row[district_idx]).strip()

        if not site_id:
            raise ValueError(f"Row {row_num} has empty 'Site ID'.")
        if not cluster:
            raise ValueError(f"Row {row_num} has empty 'Cluster'.")
        if not district:
            raise ValueError(f"Row {row_num} has empty 'District'.")

        rows_data.append({
            "site_id": site_id,
            "cluster": cluster,
            "district": district
        })
    return rows_data

def parse_xlsx_data(contents: bytes) -> List[Dict[str, str]]:
    try:
        wb = openpyxl.load_workbook(io.BytesIO(contents), read_only=True, data_only=True)
        sheet = wb.active
        rows = list(sheet.iter_rows(values_only=True))
    except Exception as e:
        raise ValueError(f"Failed to parse Excel file: {str(e)}")

    if not rows:
        raise ValueError("The Excel file is empty.")

    headers = [str(cell) if cell is not None else "" for cell in rows[0]]
    header_map = normalize_header(headers)
    missing = [col for col in ["site_id", "cluster", "district"] if col not in header_map]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}. Detected headers: {headers}")

    site_id_col = header_map["site_id"]
    cluster_col = header_map["cluster"]
    district_col = header_map["district"]

    site_id_idx = headers.index(site_id_col)
    cluster_idx = headers.index(cluster_col)
    district_idx = headers.index(district_col)

    rows_data = []
    for row_num, row in enumerate(rows[1:], start=2):
        if not row or all(val is None or str(val).strip() == "" for val in row):
            continue

        site_id = str(row[site_id_idx]).strip() if row[site_id_idx] is not None else ""
        cluster = str(row[cluster_idx]).strip() if row[cluster_idx] is not None else ""
        district = str(row[district_idx]).strip() if row[district_idx] is not None else ""

        if not site_id:
            raise ValueError(f"Row {row_num} has empty 'Site ID'.")
        if not cluster:
            raise ValueError(f"Row {row_num} has empty 'Cluster'.")
        if not district:
            raise ValueError(f"Row {row_num} has empty 'District'.")

        rows_data.append({
            "site_id": site_id,
            "cluster": cluster,
            "district": district
        })
    return rows_data

@router.post("/upload", status_code=status.HTTP_201_CREATED)
async def upload_site_info(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload a CSV or XLSX file containing Site ID, Cluster, and District.
    """
    filename = (file.filename or "").lower()
    is_csv = filename.endswith(".csv")
    is_xlsx = filename.endswith(".xlsx")

    if not (is_csv or is_xlsx):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported file format. Please upload a .csv or .xlsx file."
        )

    try:
        contents = await file.read()
        if is_csv:
            rows = parse_csv_data(contents)
        else:
            rows = parse_xlsx_data(contents)
    except ValueError as val_err:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(val_err)
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while reading the file: {str(exc)}"
        )

    try:
        db.query(SiteInfo).delete()
        
        site_objects = [
            SiteInfo(site_id=r["site_id"], cluster=r["cluster"], district=r["district"])
            for r in rows
        ]
        
        batch_size = 1000
        for i in range(0, len(site_objects), batch_size):
            db.bulk_save_objects(site_objects[i:i+batch_size])
        
        db.commit()
    except Exception as db_err:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error occurred: {str(db_err)}"
        )

    clear_dashboard_cache()

    return {
        "message": f"Successfully uploaded and processed {len(rows)} site(s).",
        "rows_count": len(rows)
    }

@router.get("/", response_model=List[Dict[str, Any]])
def get_all_site_info(db: Session = Depends(get_db)):
    """
    Get all uploaded site metadata.
    """
    sites = db.query(SiteInfo).all()
    return [
        {"site_id": s.site_id, "cluster": s.cluster, "district": s.district}
        for s in sites
    ]

@router.delete("/", status_code=status.HTTP_204_NO_CONTENT)
def delete_all_site_info(db: Session = Depends(get_db)):
    """
    Clear all site metadata records.
    """
    try:
        db.query(SiteInfo).delete()
        db.commit()
    except Exception as db_err:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error occurred while clearing records: {str(db_err)}"
        )
    clear_dashboard_cache()
    return None

@router.delete("/{site_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_site_info(site_id: str, db: Session = Depends(get_db)):
    """
    Delete a specific site info mapping record by Site ID.
    """
    db_site = db.query(SiteInfo).filter(SiteInfo.site_id == site_id).first()
    if not db_site:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Site ID not found in mapping database."
        )
    try:
        db.delete(db_site)
        db.commit()
    except Exception as db_err:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error occurred: {str(db_err)}"
        )
    clear_dashboard_cache()
    return None
