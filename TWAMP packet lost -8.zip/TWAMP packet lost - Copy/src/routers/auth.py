from fastapi import APIRouter
from pydantic import BaseModel
from typing import List
from src.config import settings

router = APIRouter()


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    success: bool
    role: str = ""
    username: str = ""
    name: str = ""
    message: str = ""


class EnvUserInfo(BaseModel):
    username: str
    role: str
    name: str


@router.post("/login", response_model=LoginResponse)
async def login(req: LoginRequest):
    """
    Validate user credentials against values in .env file.
    Returns role, username, and display name on success.
    No passwords are ever sent back to the client.
    """
    u = req.username.strip()
    p = req.password.strip()

    if u == settings.ADMIN_USERNAME and p == settings.ADMIN_PASSWORD:
        return LoginResponse(
            success=True,
            role="admin",
            username=settings.ADMIN_USERNAME,
            name="Administrator",
        )

    if u == settings.USER_USERNAME and p == settings.USER_PASSWORD:
        return LoginResponse(
            success=True,
            role="user",
            username=settings.USER_USERNAME,
            name="TWAMP User",
        )

    return LoginResponse(
        success=False,
        message="Invalid username or password.",
    )


@router.get("/users", response_model=List[EnvUserInfo])
async def get_env_users():
    """
    Return the list of env-defined accounts (username + role only, no passwords).
    Used by the UserManagement page to display and sync with .env-defined accounts.
    """
    return [
        EnvUserInfo(username=settings.ADMIN_USERNAME, role="admin", name="Administrator"),
        EnvUserInfo(username=settings.USER_USERNAME,  role="user",  name="TWAMP User"),
    ]
