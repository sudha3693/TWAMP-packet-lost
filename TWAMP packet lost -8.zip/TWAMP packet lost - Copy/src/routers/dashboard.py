from typing import Any, Dict, List, Optional
import time

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from src.database import get_db
from src.services import dashboard as dashboard_service

router = APIRouter()


def _log_api_timing(page: str, endpoint: str, started_at: float, db_time: float = 0.0, excel_time: float = 0.0, processing_time: float = 0.0) -> None:
    total_time = time.perf_counter() - started_at
    print(
        f"[PERF][{page}] endpoint={endpoint} api_time={total_time:.4f}s "
        f"db_time={db_time:.4f}s excel_time={excel_time:.4f}s processing_time={processing_time:.4f}s total_time={total_time:.4f}s"
    )


@router.get('/clusters')
def get_clusters(
    circle: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """Return distinct cluster names for the given circle, plus 'Not Found' if applicable."""
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_clusters(db, circle=circle)
    _log_api_timing('Dashboard', '/api/v1/dashboard/clusters', started_at)
    return result


@router.get('/summary')
def get_summary(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_summary(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'site_id': site_id,
            'pl_count': pl_count,
            'search': search,
            'cluster': cluster,
            'district': district,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/summary', started_at)
    return result


@router.get('/trend-7days')
def get_trend_7days(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_trend_7days(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'site_id': site_id,
            'pl_count': pl_count,
            'search': search,
            'cluster': cluster,
            'district': district,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/trend-7days', started_at)
    return result


@router.get('/trend-wow')
def get_trend_wow(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    _ts: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_trend_wow(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            '_ts': _ts,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'site_id': site_id,
            'pl_count': pl_count,
            'search': search,
            'cluster': cluster,
            'district': district,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/trend-wow', started_at)
    return result


@router.get('/backhaul')
def get_backhaul(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    technology: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_backhaul(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            'technology': technology,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'site_id': site_id,
            'pl_count': pl_count,
            'search': search,
            'cluster': cluster,
            'district': district,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/backhaul', started_at)
    return result


@router.get('/technology')
def get_technology(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    technology: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_technology(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            'technology': technology,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'site_id': site_id,
            'pl_count': pl_count,
            'search': search,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/technology', started_at)
    return result


@router.get('/top-sites')
def get_top_sites(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    report_date: Optional[str] = Query(None),
    technology: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    backhaul: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    site_query: Optional[str] = Query(None),
    site_id_status: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    sort_by: Optional[str] = Query(None),
    sort_dir: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    page: int = Query(1),
    page_size: Optional[str] = Query("25"),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_top_sites(
        db,
        filters={
            'circle': circle,
            'start_date': start_date,
            'end_date': end_date,
            'report_date': report_date,
            'technology': technology,
            'pop_name': pop_name,
            'connection_type': connection_type,
            'backhaul': backhaul or connection_type,
            'site_id': site_id,
            'site_query': site_query or site_id or search,
            'site_id_status': site_id_status,
            'pl_count': pl_count,
            'search': search,
            'sort_by': sort_by,
            'sort_dir': sort_dir,
            'page': page,
            'page_size': page_size,
            'cluster': cluster,
            'district': district,
        },
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/top-sites', started_at)
    return result


@router.get('/circle-breakdown')
def get_circle_breakdown(
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_circle_breakdown(
        db,
        filters={'start_date': start_date, 'end_date': end_date},
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/circle-breakdown', started_at)
    return result


@router.get('/history')
def get_history(
    circle: Optional[str] = Query(None),
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    technology: Optional[str] = Query(None),
    pop_name: Optional[str] = Query(None),
    connection_type: Optional[str] = Query(None),
    site_id: Optional[str] = Query(None),
    pl_count: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    skip: int = Query(0),
    limit: int = Query(20),
    db: Session = Depends(get_db),
):
    started_at = time.perf_counter()
    result = dashboard_service.get_dashboard_history(
        db,
        circle=circle,
        start_date=start_date,
        end_date=end_date,
        technology=technology,
        pop_name=pop_name,
        connection_type=connection_type,
        site_id=site_id,
        pl_count=pl_count,
        search=search,
        skip=skip,
        limit=limit,
    )
    _log_api_timing('Dashboard', '/api/v1/dashboard/history', started_at)
    return result
