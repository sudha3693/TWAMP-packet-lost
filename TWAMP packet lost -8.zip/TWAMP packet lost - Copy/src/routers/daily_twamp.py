"""
Router for the Daily TWAMP upload endpoint.

POST /api/v1/daily-twamp/upload
  Accepts an .xlsx file, extracts the report date from row 4,
  reads headers from row 7, and inserts data (starting row 8) into
  a table named  twamp_YYYY_MM_DD.

GET /api/v1/daily-twamp/tables
  Lists all daily TWAMP tables in the database.

GET /api/v1/daily-twamp/{table_name}/data
  Retrieves paginated data from a specific daily table.

DELETE /api/v1/daily-twamp/{table_name}
  Drops a specific daily table.
"""

import io
from typing import Optional, List

import openpyxl
from fastapi import APIRouter, HTTPException, UploadFile, File, status

from src.database import engine
from src.services.daily_twamp_import import (
    import_daily_twamp_sheet,
    list_daily_tables,
    get_daily_table_data,
    delete_daily_table,
)

router = APIRouter()


@router.post("/upload")
async def upload_daily_twamp(
    file: UploadFile = File(...),
):
    """
    Upload the daily TWAMP Excel sheet.

    - Reads the report date from row 4 (cells A4–D4).
    - Reads column headers from row 7; blank cells get predefined short names.
    - Inserts all non-empty rows starting from row 8 into a table
      named  twamp_YYYY_MM_DD.
    - The table is created automatically if it does not exist yet.
    """
    filename_lower = (file.filename or "").lower()
    if not (filename_lower.endswith(".xlsx") or filename_lower.endswith(".xls")):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only Excel files (.xlsx / .xls) are accepted.",
        )

    contents = await file.read()

    wb = None
    try:
        wb = openpyxl.load_workbook(
            io.BytesIO(contents), read_only=True, data_only=True
        )
        sheet = wb.active
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to open the Excel file: {exc}",
        )

    try:
        result = import_daily_twamp_sheet(engine=engine, sheet=sheet)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Import failed: {exc}",
        )
    finally:
        if wb is not None:
            wb.close()

    return {
        "message": (
            f"Successfully imported {result['row_count']} rows "
            f"into table '{result['table_name']}'."
        ),
        "table_name": result["table_name"],
        "report_date": result["report_date"],
        "row_count": result["row_count"],
        "columns": result["columns"],
    }


@router.get("/tables")
def get_tables() -> List[dict]:
    """
    Retrieve all daily TWAMP tables.
    Returns a list with table_name, report_date, and row_count.
    """
    try:
        tables = list_daily_tables(engine=engine)
        return tables
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list tables: {exc}",
        )


@router.get("/{table_name}/data")
def get_table_data(
    table_name: str,
    search: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
) -> dict:
    """
    Retrieve paginated data from a specific daily TWAMP table.
    Supports optional full-text search across all columns.
    """
    try:
        result = get_daily_table_data(
            engine=engine,
            table_name=table_name,
            skip=skip,
            limit=limit,
            search=search,
        )
        return result
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve table data: {exc}",
        )


@router.delete("/{table_name}", status_code=status.HTTP_204_NO_CONTENT)
def delete_table(table_name: str):
    """
    Delete a specific daily TWAMP table.
    """
    try:
        delete_daily_table(engine=engine, table_name=table_name)
        return None
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete table: {exc}",
        )
