import os
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "Daily TWAMP Analytics"
    DATABASE_URL: str = "sqlite:///./sql_app.db"

    # Auth credentials — loaded from .env file
    ADMIN_USERNAME: str = "admin01"
    ADMIN_PASSWORD: str = "admin@20"
    USER_USERNAME: str = "twamp"
    USER_PASSWORD: str = "twamp@20"

    # SettingsConfigDict loads variables from a .env file if it exists
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()

