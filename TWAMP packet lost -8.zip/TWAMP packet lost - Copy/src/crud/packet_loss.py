from datetime import datetime, date
from typing import List, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc
from src.models.packet_loss import ReportMetadata, PacketLossData
from src.schemas.packet_loss import PacketLossDataCreate
from src.services.packet_loss_filters import apply_packet_loss_filters


def _classify_technology(value: Optional[str]) -> str:
    normalized = (value or "").strip().lower()
    if "voice" in normalized and "4g" in normalized:
        return "VOICE"
    if "5g" in normalized:
        return "5G"
    if "4g" in normalized:
        return "4G"
    return "OTHER"


def _parse_pl_count_num(value: Optional[str]) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return 0.0


def get_report_metadata_by_date_and_circle(
    db: Session,
    report_date: date,
    circle: str
) -> Optional[ReportMetadata]:
    return (
        db.query(ReportMetadata)
        .filter(ReportMetadata.report_date == report_date)
        .filter(ReportMetadata.circle == circle)
        .first()
    )


def create_report_metadata(
    db: Session,
    report_date: date,
    circle: str,
    uploaded_at: datetime
) -> ReportMetadata:
    metadata = ReportMetadata(
        report_date=report_date,
        circle=circle,
        uploaded_at=uploaded_at,
    )
    db.add(metadata)
    db.flush()
    return metadata


def create_packet_loss_data_batch(
    db: Session,
    report_id: int,
    rows: List[dict],
) -> List[PacketLossData]:
    # Build a fast mapping of TWAMP-Unique-SiteID to site_id from 5g_data
    # Query ONLY the site names that are actually present in the uploaded sheet
    from src.models.five_g_data import FiveGData
    from sqlalchemy import func
    
    unique_site_names = {row.get("site_name").strip().lower() for row in rows if row.get("site_name")}
    five_g_mapping = {}
    
    if unique_site_names:
        site_names_list = list(unique_site_names)
        # SQLite limit on host parameters is 999. Chunk to 900 to be safe.
        chunk_size = 900
        for i in range(0, len(site_names_list), chunk_size):
            chunk = site_names_list[i : i + chunk_size]
            five_g_records = (
                db.query(FiveGData.twamp_unique_site_id, FiveGData.site_id)
                .filter(func.lower(FiveGData.twamp_unique_site_id).in_(chunk))
                .all()
            )
            for twamp_id, s_id in five_g_records:
                if twamp_id:
                    five_g_mapping[twamp_id.strip().lower()] = s_id

    dedup_map = {}
    for row in rows:
        # VLOOKUP logic
        site_id = None
        site_name_val = row.get("site_name")
        if site_name_val:
            search_key = site_name_val.strip().lower()
            site_id = five_g_mapping.get(search_key)

        m = {
            "report_id": report_id,
            "short_name": row.get("short_name"),
            "pop_name": row.get("pop_name"),
            "connection_type": row.get("connection_type"),
            "packet_loss_05_90_percent_count": row.get("packet_loss_05_90_percent_count"),
            "pl_count_num": _parse_pl_count_num(row.get("packet_loss_05_90_percent_count")),
            "packet_loss_ageing": row.get("packet_loss_ageing"),
            "no_of_hrs_session_having_pl_05_90_count": row.get("no_of_hrs_session_having_pl_05_90_count"),
            "site_name": site_name_val,
            "site_id": site_id,
            "site_type": row.get("site_type"),
            "twamp_technology": row.get("twamp_technology"),
            "technology_class": _classify_technology(row.get("twamp_technology")),
        }
        for hour in range(24):
            m[f"rt_packet_loss_{hour:02d}_percent"] = row.get(f"rt_packet_loss_{hour:02d}_percent")
            m[f"packet_loss_{hour:02d}_count"] = row.get(f"packet_loss_{hour:02d}_count")
        short_name_upper = (row.get("short_name") or "").upper()
        if "DATA" in short_name_upper:
            service_type = "DATA"
        elif "VOIP" in short_name_upper or "VOICE" in short_name_upper:
            service_type = "VOICE"
        else:
            service_type = "UNKNOWN"

        group_key = (
            site_id if site_id else short_name_upper, 
            row.get("twamp_technology", ""),
            row.get("connection_type", ""), 
            service_type
        )
        
        if group_key in dedup_map:
            existing_m = dedup_map[group_key]
            try:
                existing_hrs = float(existing_m.get("no_of_hrs_session_having_pl_05_90_count") or 0)
                new_hrs = float(m.get("no_of_hrs_session_having_pl_05_90_count") or 0)
            except ValueError:
                existing_hrs, new_hrs = 0, 0
                
            if new_hrs > existing_hrs:
                dedup_map[group_key] = m
            elif new_hrs == existing_hrs:
                try:
                    existing_cnt = float(existing_m.get("packet_loss_05_90_percent_count") or 0)
                    new_cnt = float(m.get("packet_loss_05_90_percent_count") or 0)
                except ValueError:
                    existing_cnt, new_cnt = 0, 0
                if new_cnt > existing_cnt:
                    dedup_map[group_key] = m
        else:
            dedup_map[group_key] = m

    mappings = list(dedup_map.values())

    if mappings:
        db.bulk_insert_mappings(PacketLossData, mappings)

    # Recreate in-memory objects for compatibility without database-roundtrip fetches
    return [PacketLossData(**m) for m in mappings]


def get_packet_loss_data_list(db: Session, skip: int = 0, limit: int = 100) -> List[PacketLossData]:
    return db.query(PacketLossData).offset(skip).limit(limit).all()


def get_packet_loss_reports(db: Session, skip: int = 0, limit: int = 100) -> List[ReportMetadata]:
    return db.query(ReportMetadata).order_by(desc(ReportMetadata.report_date)).offset(skip).limit(limit).all()


def get_packet_loss_circle_summaries(db: Session, circles: Optional[List[str]] = None) -> List[dict]:
    circle_names = circles or ["Bihar Circle", "Jharkhand Circle"]
    summaries = []
    for circle_name in circle_names:
        latest_report = (
            db.query(ReportMetadata)
            .filter(ReportMetadata.circle == circle_name)
            .order_by(desc(ReportMetadata.report_date), desc(ReportMetadata.uploaded_at))
            .limit(1)
            .first()
        )
        total_records = (
            db.query(PacketLossData)
            .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
            .filter(ReportMetadata.circle == circle_name)
            .count()
        )
        report_count = db.query(ReportMetadata).filter(ReportMetadata.circle == circle_name).count()
        summaries.append({
            "circle": circle_name,
            "latest_upload_date": latest_report.report_date.isoformat() if latest_report else None,
            "report_count": report_count,
            "total_records": total_records,
        })
    return summaries


def delete_report_by_id(db: Session, report_id: int) -> bool:
    report = db.query(ReportMetadata).filter(ReportMetadata.id == report_id).first()
    if report:
        db.delete(report)
        db.commit()
        return True
    return False


def delete_all_reports(db: Session):
    db.query(ReportMetadata).delete()
    db.commit()


def _build_packet_loss_query(
    db: Session,
    report_id: int,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
):
    query = db.query(PacketLossData).filter(PacketLossData.report_id == report_id)
    return apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=twamp_technology,
        pl_count=pl_count,
        cluster=cluster,
        district=district,
    )


def get_packet_loss_data_by_report_id(
    db: Session,
    report_id: int,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
    skip: int = 0,
    limit: int = 100
) -> List[PacketLossData]:
    query = _build_packet_loss_query(
        db=db,
        report_id=report_id,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=twamp_technology,
        pl_count=pl_count,
        cluster=cluster,
        district=district,
    )
    rows = query.offset(skip).limit(limit).all()
    return rows


def get_packet_loss_data_count_by_report_id(
    db: Session,
    report_id: int,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
) -> int:
    query = _build_packet_loss_query(
        db=db,
        report_id=report_id,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=twamp_technology,
        pl_count=pl_count,
        cluster=cluster,
        district=district,
    )
    return query.count()


def get_packet_loss_data_by_circle(
    db: Session,
    circle: str,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
) -> List[PacketLossData]:
    query = (
        db.query(PacketLossData)
        .options(joinedload(PacketLossData.report))
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.circle == circle)
    )
    query = apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=twamp_technology,
        pl_count=pl_count,
        cluster=cluster,
        district=district,
    )
    return (
        query.order_by(desc(ReportMetadata.report_date), desc(PacketLossData.created_at), desc(PacketLossData.id))
        .offset(skip)
        .limit(limit)
        .all()
    )


def get_packet_loss_data_count_by_circle(
    db: Session,
    circle: str,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
) -> int:
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.circle == circle)
    )
    query = apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=twamp_technology,
        pl_count=pl_count,
        cluster=cluster,
        district=district,
    )
    return query.count()


def get_circle_filter_options(db: Session, circle: str) -> dict:
    from src.models.site_info import SiteInfo
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.circle == circle)
    )
    pop_names = query.filter(
        PacketLossData.pop_name.isnot(None),
        PacketLossData.pop_name != "",
    ).with_entities(PacketLossData.pop_name).distinct().all()

    connection_types = query.filter(
        PacketLossData.connection_type.isnot(None),
        PacketLossData.connection_type != "",
    ).with_entities(PacketLossData.connection_type).distinct().all()

    technologies = query.filter(
        PacketLossData.twamp_technology.isnot(None),
        PacketLossData.twamp_technology != "",
    ).with_entities(PacketLossData.twamp_technology).distinct().all()

    pl_counts = query.filter(
        PacketLossData.packet_loss_05_90_percent_count.isnot(None),
    ).with_entities(PacketLossData.packet_loss_05_90_percent_count).distinct().all()

    clusters = query.join(SiteInfo, PacketLossData.site_id == SiteInfo.site_id).filter(
        SiteInfo.cluster.isnot(None),
        SiteInfo.cluster != ""
    ).with_entities(SiteInfo.cluster).distinct().all()

    districts = query.join(SiteInfo, PacketLossData.site_id == SiteInfo.site_id).filter(
        SiteInfo.district.isnot(None),
        SiteInfo.district != ""
    ).with_entities(SiteInfo.district).distinct().all()

    return {
        "pop_names": sorted([r[0] for r in pop_names if r[0] is not None]),
        "connection_types": sorted([r[0] for r in connection_types if r[0] is not None]),
        "technologies": sorted([r[0] for r in technologies if r[0] is not None]),
        "pl_counts": sorted([r[0] for r in pl_counts if r[0] is not None]),
        "clusters": sorted([r[0] for r in clusters if r[0] is not None]),
        "districts": sorted([r[0] for r in districts if r[0] is not None]),
    }


def get_filter_options(db: Session, report_id: int) -> dict:
    """
    Get unique values for pop_name, connection_type, twamp_technology, 
    packet_loss_05_90_percent_count, cluster, and district for a report.
    """
    from src.models.site_info import SiteInfo
    pop_names = db.query(PacketLossData.pop_name).filter(
        PacketLossData.report_id == report_id,
        PacketLossData.pop_name.isnot(None),
        PacketLossData.pop_name != ""
    ).distinct().all()
    
    connection_types = db.query(PacketLossData.connection_type).filter(
        PacketLossData.report_id == report_id,
        PacketLossData.connection_type.isnot(None),
        PacketLossData.connection_type != ""
    ).distinct().all()

    technologies = db.query(PacketLossData.twamp_technology).filter(
        PacketLossData.report_id == report_id,
        PacketLossData.twamp_technology.isnot(None),
        PacketLossData.twamp_technology != ""
    ).distinct().all()

    pl_counts = db.query(PacketLossData.packet_loss_05_90_percent_count).filter(
        PacketLossData.report_id == report_id,
        PacketLossData.packet_loss_05_90_percent_count.isnot(None)
    ).distinct().all()

    clusters = db.query(SiteInfo.cluster).join(
        PacketLossData, PacketLossData.site_id == SiteInfo.site_id
    ).filter(
        PacketLossData.report_id == report_id,
        SiteInfo.cluster.isnot(None),
        SiteInfo.cluster != ""
    ).distinct().all()

    districts = db.query(SiteInfo.district).join(
        PacketLossData, PacketLossData.site_id == SiteInfo.site_id
    ).filter(
        PacketLossData.report_id == report_id,
        SiteInfo.district.isnot(None),
        SiteInfo.district != ""
    ).distinct().all()

    return {
        "pop_names": sorted([r[0] for r in pop_names if r[0] is not None]),
        "connection_types": sorted([r[0] for r in connection_types if r[0] is not None]),
        "technologies": sorted([r[0] for r in technologies if r[0] is not None]),
        "pl_counts": sorted([r[0] for r in pl_counts if r[0] is not None], key=lambda x: float(x) if x and x.replace('.', '', 1).isdigit() else 0),
        "clusters": sorted([r[0] for r in clusters if r[0] is not None]),
        "districts": sorted([r[0] for r in districts if r[0] is not None]),
    }


from sqlalchemy import text

def resolve_vacant_site_ids(db: Session) -> int:
    """
    Find all PacketLossData records that do not have a site_id,
    and update them in a single optimized index-backed SQLite query.
    """
    # 1. Ensure case-insensitive collation indexes exist on join columns for speed
    db.execute(text("CREATE INDEX IF NOT EXISTS ix_5g_data_twamp_unique_site_id ON [5g_data] (twamp_unique_site_id COLLATE NOCASE)"))
    db.execute(text("CREATE INDEX IF NOT EXISTS ix_packet_loss_data_site_name ON packet_loss_data (site_name COLLATE NOCASE)"))
    db.execute(text("CREATE INDEX IF NOT EXISTS ix_packet_loss_data_site_id ON packet_loss_data (site_id)"))
    db.commit()

    # 2. Run a single index-backed correlated UPDATE query
    sql = """
        UPDATE packet_loss_data
        SET site_id = (
            SELECT site_id 
            FROM [5g_data] 
            WHERE [5g_data].twamp_unique_site_id = packet_loss_data.site_name COLLATE NOCASE
            LIMIT 1
        )
        WHERE (packet_loss_data.site_id IS NULL OR packet_loss_data.site_id = '')
          AND packet_loss_data.site_name IS NOT NULL
          AND EXISTS (
              SELECT 1 
              FROM [5g_data] 
              WHERE [5g_data].twamp_unique_site_id = packet_loss_data.site_name COLLATE NOCASE
          )
    """
    result = db.execute(text(sql))
    db.commit()

    return result.rowcount


def get_site_daily_detail(
    db: Session,
    site_name: Optional[str] = None,
    site_id: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    twamp_technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
) -> List[PacketLossData]:
    """
    Query daily packet loss historical records for a specific site name or site ID,
    ordered by date descending.
    """
    query = (
        db.query(PacketLossData)
        .options(joinedload(PacketLossData.report))
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
    )

    if site_id and site_id.strip():
        query = query.filter(PacketLossData.site_id == site_id.strip())
    elif site_name and site_name.strip():
        name_val = site_name.strip()
        query = query.filter((PacketLossData.site_name == name_val) | (PacketLossData.short_name == name_val))
    else:
        return []

    if start_date:
        query = query.filter(ReportMetadata.report_date >= start_date)
    if end_date:
        query = query.filter(ReportMetadata.report_date <= end_date)

    query = apply_packet_loss_filters(
        query,
        search=search,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=twamp_technology,
        pl_count=pl_count,
    )

    return query.order_by(desc(ReportMetadata.report_date)).all()


def get_site_filter_options(
    db: Session,
    site_name: Optional[str] = None,
    site_id: Optional[str] = None,
) -> dict:
    """
    Get unique values for pop_name, connection_type, twamp_technology, and pl_count for a site.
    """
    query = db.query(PacketLossData)
    if site_id and site_id.strip():
        query = query.filter(PacketLossData.site_id == site_id.strip())
    elif site_name and site_name.strip():
        name_val = site_name.strip()
        query = query.filter((PacketLossData.site_name == name_val) | (PacketLossData.short_name == name_val))
    else:
        return {
            "pop_names": [],
            "connection_types": [],
            "technologies": [],
            "pl_counts": [],
        }

    pop_names = query.filter(
        PacketLossData.pop_name.isnot(None),
        PacketLossData.pop_name != "",
    ).with_entities(PacketLossData.pop_name).distinct().all()

    connection_types = query.filter(
        PacketLossData.connection_type.isnot(None),
        PacketLossData.connection_type != "",
    ).with_entities(PacketLossData.connection_type).distinct().all()

    technologies = query.filter(
        PacketLossData.twamp_technology.isnot(None),
        PacketLossData.twamp_technology != "",
    ).with_entities(PacketLossData.twamp_technology).distinct().all()

    pl_counts = query.filter(
        PacketLossData.packet_loss_05_90_percent_count.isnot(None),
    ).with_entities(PacketLossData.packet_loss_05_90_percent_count).distinct().all()

    return {
        "pop_names": sorted([r[0] for r in pop_names if r[0] is not None]),
        "connection_types": sorted([r[0] for r in connection_types if r[0] is not None]),
        "technologies": sorted([r[0] for r in technologies if r[0] is not None]),
        "pl_counts": sorted([r[0] for r in pl_counts if r[0] is not None], key=lambda x: float(x) if x and x.replace('.', '', 1).isdigit() else 0)
    }


