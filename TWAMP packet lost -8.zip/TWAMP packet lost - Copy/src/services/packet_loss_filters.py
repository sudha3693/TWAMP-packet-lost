from typing import Optional

from sqlalchemy import func, or_
from sqlalchemy.orm import Query

from src.models.packet_loss import PacketLossData
from src.models.site_info import SiteInfo


def normalize_filter_value(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    normalized = str(value).strip()
    return normalized or None


def apply_packet_loss_filters(
    query: Query,
    *,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    cluster: Optional[str] = None,
    district: Optional[str] = None,
) -> Query:
    # Left outer join SiteInfo so we can filter by SiteInfo.cluster and SiteInfo.district
    query = query.outerjoin(SiteInfo, PacketLossData.site_id == SiteInfo.site_id)

    normalized_search = normalize_filter_value(search)
    if normalized_search:
        search_term = f"%{normalized_search.lower()}%"
        query = query.filter(
            or_(
                func.lower(func.coalesce(PacketLossData.site_id, '')).like(search_term),
                func.lower(func.coalesce(PacketLossData.site_name, '')).like(search_term),
                func.lower(func.coalesce(PacketLossData.short_name, '')).like(search_term),
                func.lower(func.coalesce(PacketLossData.pop_name, '')).like(search_term),
                func.lower(func.coalesce(PacketLossData.twamp_technology, '')).like(search_term),
                func.lower(func.coalesce(SiteInfo.cluster, '')).like(search_term),
                func.lower(func.coalesce(SiteInfo.district, '')).like(search_term),
            )
        )

    for column, value, exact in [
        (PacketLossData.site_id, site_id, False),
        (PacketLossData.pop_name, pop_name, True),
        (PacketLossData.connection_type, connection_type, True),
        (PacketLossData.twamp_technology, technology, True),
        (PacketLossData.packet_loss_05_90_percent_count, pl_count, True),
    ]:
        normalized_value = normalize_filter_value(value)
        if normalized_value is None:
            continue
        normalized_column = func.lower(func.coalesce(column, ''))
        normalized_value_lower = normalized_value.lower()
        if exact:
            query = query.filter(normalized_column == normalized_value_lower)
        else:
            query = query.filter(normalized_column.like(f"%{normalized_value_lower}%"))

    # Handle cluster with special "Not Found" support
    cluster_val = normalize_filter_value(cluster)
    if cluster_val:
        if cluster_val.lower() == "not found":
            # Sites with no SiteInfo match or null/empty cluster
            query = query.filter(
                or_(
                    SiteInfo.site_id.is_(None),
                    SiteInfo.cluster.is_(None),
                    func.trim(SiteInfo.cluster) == ''
                )
            )
        else:
            query = query.filter(
                func.lower(func.coalesce(SiteInfo.cluster, '')).like(f"%{cluster_val.lower()}%")
            )

    # Handle district with special "Not Found" support
    district_val = normalize_filter_value(district)
    if district_val:
        if district_val.lower() == "not found":
            query = query.filter(
                or_(
                    SiteInfo.site_id.is_(None),
                    SiteInfo.district.is_(None),
                    func.trim(SiteInfo.district) == ''
                )
            )
        else:
            query = query.filter(
                func.lower(func.coalesce(SiteInfo.district, '')).like(f"%{district_val.lower()}%")
            )

    return query
