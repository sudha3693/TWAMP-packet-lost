import { useCallback, useMemo, useState } from 'react';

export default function usePacketLossFilters(initialFilters = {}) {
  const [filters, setFilters] = useState({
    siteId: '',
    popName: '',
    connectionType: '',
    technology: '',
    plCount: '',
    cluster: '',
    district: '',
    ...initialFilters
  });

  const setFilter = useCallback((field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value || ''
    }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({
      siteId: '',
      popName: '',
      connectionType: '',
      technology: '',
      plCount: '',
      cluster: '',
      district: ''
    });
  }, []);

  const normalizedFilters = useMemo(() => ({
    siteId: (filters.siteId || '').toString().trim(),
    popName: (filters.popName || '').toString().trim(),
    connectionType: (filters.connectionType || '').toString().trim(),
    technology: (filters.technology || '').toString().trim(),
    plCount: (filters.plCount || '').toString().trim(),
    cluster: (filters.cluster || '').toString().trim(),
    district: (filters.district || '').toString().trim()
  }), [filters]);

  return {
    filters,
    setFilter,
    resetFilters,
    normalizedFilters
  };
}
