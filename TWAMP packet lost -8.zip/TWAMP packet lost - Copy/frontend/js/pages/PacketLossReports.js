import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';
import PacketLossFilterPanel from '../components/PacketLossFilterPanel.js';
import PacketLossSummaryCard from '../components/PacketLossSummaryCard.js';
import usePacketLossFilters from '../hooks/usePacketLossFilters.js';

export default function PacketLossReports({ onSiteClick, circle = 'All', startDate, endDate, userRole = 'admin' }) {
  const isAdmin = userRole === 'admin';
  const [summaries, setSummaries] = useState([]);
  const [loadingSummaries, setLoadingSummaries] = useState(true);
  const [selectedCircle, setSelectedCircle] = useState(null);
  const [historyRows, setHistoryRows] = useState([]);
  const [totalRows, setTotalRows] = useState(0);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [expandedRowId, setExpandedRowId] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [filterOptions, setFilterOptions] = useState({
    pop_names: [],
    connection_types: [],
    technologies: [],
    pl_counts: []
  });
  const [filterResetKey, setFilterResetKey] = useState(0);

  const { filters, setFilter, resetFilters, normalizedFilters } = usePacketLossFilters();
  const fileInputRef = useRef(null);
  const pageSize = 10;

  useEffect(() => {
    loadCircleSummaries();
  }, []);

  useEffect(() => {
    if (selectedCircle) {
      loadCircleFilterOptions(selectedCircle);
      loadHistoryData(selectedCircle, currentPage, search, normalizedFilters);
    }
  }, [selectedCircle, currentPage, search, normalizedFilters]);

  const getCircleDisplayName = (circle) => {
    const rawValue = (circle || '').toString().trim();
    const normalized = rawValue.toLowerCase();
    if (normalized.includes('bihar')) return 'Bihar';
    if (normalized.includes('jharkhand') || normalized.includes('jhk')) return 'Jharkhand';
    return rawValue.replace(/\s+Circle$/i, '');
  };

  const loadCircleSummaries = async () => {
    setLoadingSummaries(true);
    setError('');
    try {
      const reports = await api.getPacketLossReports();
      const summaryMap = new Map();

      (reports || []).forEach((report) => {
        const circleName = report.circle || 'Unknown';
        if (!summaryMap.has(circleName)) {
          summaryMap.set(circleName, {
            circle: circleName,
            displayName: getCircleDisplayName(circleName),
            latest_upload_date: null,
            report_count: 0,
            total_records: 0
          });
        }

        const summary = summaryMap.get(circleName);
        summary.report_count += 1;
        summary.total_records += Number(report.row_count || 0);

        const reportDate = report.report_date || report.uploaded_at;
        if (!summary.latest_upload_date || reportDate > summary.latest_upload_date) {
          summary.latest_upload_date = reportDate;
        }
      });

      setSummaries(Array.from(summaryMap.values()));
    } catch (err) {
      try {
        const fallback = await api.getPacketLossCircleSummaries();
        setSummaries(fallback || []);
      } catch (fallbackErr) {
        setError(`Unable to load circle summaries: ${fallbackErr.message}`);
      }
    } finally {
      setLoadingSummaries(false);
    }
  };

  const loadCircleFilterOptions = async (circle) => {
    try {
      const data = await api.getPacketLossCircleFilterOptions(circle);
      setFilterOptions(data || { pop_names: [], connection_types: [], technologies: [], pl_counts: [] });
    } catch (err) {
      console.error('Failed to load circle filter options:', err);
    }
  };

  const loadHistoryData = async (circle, page = 1, searchQuery = '', activeFilters = normalizedFilters) => {
    setLoadingHistory(true);
    setExpandedRowId(null);
    setError('');
    try {
      const response = await api.getPacketLossCircleHistoryData(circle, searchQuery, (page - 1) * pageSize, pageSize, activeFilters);
      setHistoryRows(response.rows || []);
      setTotalRows(response.total || 0);
    } catch (err) {
      setError(`Unable to load packet loss history: ${err.message}`);
      setHistoryRows([]);
      setTotalRows(0);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleViewCircle = (circle) => {
    setSelectedCircle(circle);
    setSearch('');
    resetFilters();
    setFilterResetKey((value) => value + 1);
    setCurrentPage(1);
  };

  const handleBackToSummaries = () => {
    setSelectedCircle(null);
    setHistoryRows([]);
    setTotalRows(0);
    setSearch('');
    resetFilters();
    setFilterResetKey((value) => value + 1);
    setExpandedRowId(null);
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleFilterSubmit = () => {
    if (!selectedCircle) return;
    setCurrentPage(1);
    loadHistoryData(selectedCircle, 1, search, normalizedFilters);
  };

  const handleResetFilters = () => {
    resetFilters();
    setSearch('');
    setCurrentPage(1);
    setFilterResetKey((value) => value + 1);
    if (selectedCircle) {
      loadHistoryData(selectedCircle, 1, '', {
        siteId: '',
        popName: '',
        connectionType: '',
        technology: '',
        plCount: ''
      });
    }
  };

  const handleUploadFile = async (file) => {
    if (!file) return;
    if (!file.name.endsWith('.xlsx')) {
      setError('Only Excel files (.xlsx) are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadPacketLossData(formData);
      setMessage(res.message || 'Packet loss report uploaded successfully.');
      loadCircleSummaries();
      if (selectedCircle) {
        loadHistoryData(selectedCircle, 1, '', normalizedFilters);
      }
    } catch (err) {
      setError(err.message || 'Failed to upload packet loss report.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const onButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const toggleRowExpansion = (rowId) => {
    setExpandedRowId(expandedRowId === rowId ? null : rowId);
  };

  const formatVal = (val) => {
    if (val === null || val === undefined || val === '') return '0';
    const num = parseFloat(val);
    if (!isNaN(num)) {
      return num % 1 === 0 ? num.toString() : num.toFixed(4);
    }
    return val;
  };

  const isSignificantLoss = (pct, cnt) => {
    const p = parseFloat(pct);
    const c = parseInt(cnt);
    return (p > 0) || (c > 0);
  };

  const renderHourlyTimeline = (row) => {
    const hourlyData = Array.from({ length: 24 }, (_, h) => {
      const hStr = h.toString().padStart(2, '0');
      const pctKey = 'rt_packet_loss_' + hStr + '_percent';
      const cntKey = 'packet_loss_' + hStr + '_count';
      const pct = row[pctKey];
      const count = row[cntKey];
      const hasLoss = isSignificantLoss(pct, count);
      const label = hStr + ':00 - ' + (h + 1).toString().padStart(2, '0') + ':00';
      return { h, label, pct, count, hasLoss };
    });

    return html`
      <div style=${{
        padding: '20px',
        backgroundColor: 'rgba(0, 0, 0, 0.18)',
        borderRadius: 'var(--radius-md)',
        border: '1px solid var(--glass-border)',
        marginTop: '10px',
        marginBottom: '10px'
      }}>
        <h4 style=${{ fontSize: '14px', marginBottom: '12px', fontWeight: '600', color: 'hsl(var(--primary))' }}>
          24-Hour Packet Loss Timeline
        </h4>
        <div style=${{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
          gap: '10px'
        }}>
          ${hourlyData.map((item) => html`
            <div key=${item.h} style=${{
              padding: '10px',
              borderRadius: '8px',
              border: '1px solid ' + (item.hasLoss ? 'rgba(239, 68, 68, 0.3)' : 'var(--glass-border)'),
              backgroundColor: item.hasLoss ? 'rgba(239, 68, 68, 0.1)' : 'rgba(255, 255, 255, 0.02)',
              textAlign: 'center'
            }}>
              <div style=${{ fontSize: '11px', fontWeight: '600', marginBottom: '6px', color: item.hasLoss ? 'hsl(var(--danger))' : 'hsl(var(--text-muted))' }}>${item.label}</div>
              <div style=${{ fontSize: '13px', fontWeight: '600', color: item.hasLoss ? '#dc2626' : 'hsl(var(--text-main))' }}>Loss: ${formatVal(item.pct)}%</div>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>Count: ${formatVal(item.count)}</div>
            </div>
          `)}
        </div>
      </div>
    `;
  };

  const totalPages = Math.max(1, Math.ceil(totalRows / pageSize));

  return html`
    <div>
      <div className="glass-panel" style=${{ marginBottom: '30px' }}>
        <h2 className="list-title" style=${{ marginBottom: '24px' }}>Circle Summary Reports</h2>
        <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h3 style=${{ margin: 0, fontSize: '18px' }}>Circle Summary</h3>
            <p style=${{ margin: '8px 0 0 0', color: 'hsl(var(--text-muted))' }}>
              Historical packet loss uploads are grouped by circle and preserved forever. Click Open to query all history for that circle.
            </p>
          </div>
        </div>

        ${loadingSummaries ? html`
          <div style=${{ textAlign: 'center', padding: '40px 0', color: '#8f9bb3' }}>
            <div className="spinner" style=${{ width: '28px', height: '28px', margin: '0 auto 10px' }}></div>
            Loading circle summaries...
          </div>
        ` : summaries.length === 0 ? html`
          <div className="empty-state" style=${{ padding: '40px 0' }}>
            <div className="empty-icon">📄</div>
            <p>No packet loss uploads found yet. Upload a Bihar or Jharkhand report to populate the cards.</p>
          </div>
        ` : html`
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px', marginTop: '20px' }}>
            ${summaries.map((summary) => html`
              <${PacketLossSummaryCard}
                key=${summary.circle}
                title=${summary.displayName || summary.circle}
                latestUploadDate=${summary.latest_upload_date}
                reportCount=${summary.report_count}
                totalRecords=${summary.total_records}
                onOpen=${() => handleViewCircle(summary.circle)}
              />
            `)}
          </div>
        `}
      </div>

      ${selectedCircle && html`
        <div className="glass-panel">
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
            <div>
              <button type="button" className="btn btn-secondary btn-sm" onClick=${handleBackToSummaries}>⬅️ Back to Summaries</button>
              <h2 className="list-title" style=${{ marginTop: '16px' }}>Packet Loss History — ${selectedCircle}</h2>
              <p style=${{ color: 'hsl(var(--text-muted))', marginTop: '8px' }}>
                Searches span all uploaded dates for this circle. Results are sorted by report date descending.
              </p>
            </div>
          </div>

          <${PacketLossFilterPanel}
            filters=${filters}
            setFilter=${setFilter}
            onApply=${handleFilterSubmit}
            onReset=${handleResetFilters}
            filterOptions=${filterOptions}
            searchText=${search}
            onSearchChange=${handleSearchChange}
            onClearSearch=${() => {
              setSearch('');
              setCurrentPage(1);
              if (selectedCircle) {
                loadHistoryData(selectedCircle, 1, '', normalizedFilters);
              }
            }}
            resetKey=${filterResetKey}
            recentSiteIds=${[]}
            onRecentSiteSelect=${() => {}}
            showRecentDropdown=${false}
            setShowRecentDropdown=${() => {}}
          />

          ${loadingHistory ? html`
            <div style=${{ textAlign: 'center', padding: '60px 0', color: '#8f9bb3' }}>
              <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
              <p>Loading circle history records...</p>
            </div>
          ` : historyRows.length === 0 ? html`
            <div className="empty-state">
              <div className="empty-icon">🔍</div>
              <p>No matching history records found.</p>
            </div>
          ` : html`
            <div className="custom-table-container">
              <table className="custom-table" style=${{ minWidth: '960px' }}>
                <thead>
                  <tr>
                    <th></th>
                    <th>Report Date</th>
                    <th>Site Name</th>
                    <th>Site ID</th>
                    <th>Cluster</th>
                    <th>District</th>
                    <th>Site Type</th>
                    <th>POP Name</th>
                    <th>Connection Type</th>
                    <th>Technology</th>
                    <th>PL ≥0.5 Count</th>
                    <th>Ageing</th>
                    <th>PL Hours</th>
                  </tr>
                </thead>
                <tbody>
                  ${historyRows.map((row) => {
                    const isExpanded = expandedRowId === row.id;
                    const hasLoss = parseInt(row.no_of_hrs_session_having_pl_05_90_count) > 0;
                    return html`
                      <${React.Fragment} key=${row.id}>
                        <tr onClick=${() => toggleRowExpansion(row.id)} style=${{ cursor: 'pointer' }}>
                          <td style=${{ width: '30px', textAlign: 'center' }}>
                            <span style=${{ transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)', display: 'inline-block', transition: 'transform 0.2s', color: 'hsl(var(--primary))' }}>▶</span>
                          </td>
                          <td>${row.report_date || 'N/A'}</td>
                          <td>
                            <div style=${{ fontWeight: '600', color: 'hsl(var(--text-main))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '200px' }} title=${row.site_name || row.short_name || 'N/A'}>
                              ${(row.site_name || row.short_name) ? html`
                                <a 
                                  href="#"
                                  onClick=${(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (onSiteClick) {
                                      onSiteClick({ 
                                        siteName: row.site_name || row.short_name, 
                                        siteId: row.site_id,
                                        filters: normalizedFilters,
                                        search: search
                                      });
                                    }
                                  }}
                                  style=${{
                                    color: 'hsl(var(--text-main))',
                                    textDecoration: 'underline',
                                    cursor: 'pointer'
                                  }}
                                >
                                  ${row.site_name || row.short_name}
                                </a>
                              ` : html`<em>N/A</em>`}
                            </div>
                          </td>
                          <td>
                            ${row.site_id ? html`
                              <a 
                                href="#"
                                onClick=${(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  if (onSiteClick) {
                                    onSiteClick({ 
                                      siteName: row.site_name || row.short_name, 
                                      siteId: row.site_id,
                                      filters: normalizedFilters,
                                      search: search
                                    });
                                  }
                                }}
                                style=${{
                                  fontWeight: '600',
                                  color: 'hsl(var(--primary))',
                                  textDecoration: 'underline',
                                  cursor: 'pointer'
                                }}
                              >
                                ${row.site_id}
                              </a>
                            ` : 'N/A'}
                          </td>
                          <td style=${{ whiteSpace: 'nowrap' }}>
                            <span style=${{
                              padding: '2px 6px',
                              borderRadius: '4px',
                              fontSize: '12px',
                              backgroundColor: row.cluster === 'Not Found' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                              color: row.cluster === 'Not Found' ? '#f87171' : '#34d399',
                              border: row.cluster === 'Not Found' ? '1px solid rgba(239, 68, 68, 0.2)' : '1px solid rgba(16, 185, 129, 0.2)'
                            }}>
                              ${row.cluster || 'Not Found'}
                            </span>
                          </td>
                          <td style=${{ whiteSpace: 'nowrap' }}>
                            <span style=${{
                              padding: '2px 6px',
                              borderRadius: '4px',
                              fontSize: '12px',
                              backgroundColor: row.district === 'Not Found' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(59, 130, 246, 0.1)',
                              color: row.district === 'Not Found' ? '#f87171' : '#60a5fa',
                              border: row.district === 'Not Found' ? '1px solid rgba(239, 68, 68, 0.2)' : '1px solid rgba(59, 130, 246, 0.2)'
                            }}>
                              ${row.district || 'Not Found'}
                            </span>
                          </td>
                          <td>${row.site_type || 'N/A'}</td>
                          <td>${row.pop_name || 'N/A'}</td>
                          <td>${row.connection_type || 'N/A'}</td>
                          <td>${row.twamp_technology || 'N/A'}</td>
                          <td style=${{ textAlign: 'center' }}>${row.packet_loss_05_90_percent_count || '0'}</td>
                          <td>${row.packet_loss_ageing || 'N/A'}</td>
                          <td style=${{ textAlign: 'center' }}>${row.no_of_hrs_session_having_pl_05_90_count || '0'}</td>
                        </tr>
                        ${isExpanded && html`
                          <tr>
                            <td colSpan=${11} style=${{ padding: '0', backgroundColor: 'rgba(0,0,0,0.08)' }}>
                              ${renderHourlyTimeline(row)}
                            </td>
                          </tr>
                        `}
                      </${React.Fragment}>
                    `;
                  })}
                </tbody>
              </table>
            </div>

            ${totalPages > 1 && html`
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '18px' }}>
                <div style=${{ color: 'hsl(var(--text-muted))', fontSize: '13px' }}>
                  Page <strong>${currentPage}</strong> of <strong>${totalPages}</strong> — ${totalRows} total records
                </div>
                <div style=${{ display: 'flex', gap: '8px' }}>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    disabled=${currentPage === 1}
                    onClick=${() => setCurrentPage(currentPage - 1)}
                  >
                    Previous
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    disabled=${currentPage === totalPages}
                    onClick=${() => setCurrentPage(currentPage + 1)}
                  >
                    Next
                  </button>
                </div>
              </div>
            `}
          `}
        </div>
      `}
    </div>
  `;
}
