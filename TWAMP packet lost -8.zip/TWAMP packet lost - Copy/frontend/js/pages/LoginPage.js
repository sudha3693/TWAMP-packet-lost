import React, { useState } from 'react';
import html from '../html.js';

export default function LoginPage({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const u = username.trim();
    const p = password.trim();

    if (!u || !p) {
      setError('Please enter both username and password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: u, password: p }),
      });

      if (!res.ok) {
        setError('Server error. Please try again.');
        return;
      }

      const data = await res.json();

      if (data.success) {
        onLogin({ username: data.username, role: data.role, name: data.name });
      } else {
        setError(data.message || 'Invalid username or password.');
      }
    } catch (err) {
      setError('Could not connect to server. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  return html`
    <div style=${{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#0c101a',
      color: '#fff',
      padding: '20px'
    }}>
      <div className="glass-panel" style=${{
        width: '100%',
        maxWidth: '420px',
        padding: '36px',
        borderRadius: '16px',
        border: '1px solid rgba(255, 255, 255, 0.12)',
        backgroundColor: '#111622',
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.5)'
      }}>
        <div style=${{ textAlign: 'center', marginBottom: '28px' }}>
          <div style=${{
            width: '56px',
            height: '56px',
            borderRadius: '12px',
            backgroundColor: '#0062ff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '28px',
            margin: '0 auto 16px auto',
            boxShadow: '0 8px 24px rgba(0, 98, 255, 0.3)'
          }}>
            🔐
          </div>
          <h2 style=${{ fontSize: '22px', fontWeight: '800', margin: '0 0 6px 0', letterSpacing: '0.5px' }}>
            Analytics Dashboard Login
          </h2>
          <p style=${{ fontSize: '13px', color: '#8f9bb3', margin: 0 }}>
            Sign in to access Daily TWAMP & Packet Loss Analytics
          </p>
        </div>

        ${error && html`
          <div style=${{
            backgroundColor: 'rgba(239, 68, 68, 0.12)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            color: '#f87171',
            padding: '12px 14px',
            borderRadius: '8px',
            fontSize: '13px',
            marginBottom: '20px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            ⚠️ ${error}
          </div>
        `}

        <form onSubmit=${handleSubmit}>
          <div style=${{ marginBottom: '18px' }}>
            <label style=${{ display: 'block', fontSize: '12px', fontWeight: '600', color: '#8f9bb3', marginBottom: '6px' }}>
              Username / User ID
            </label>
            <input 
              type="text" 
              value=${username} 
              onChange=${(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              required
              disabled=${loading}
              style=${{
                width: '100%',
                height: '42px',
                padding: '0 14px',
                backgroundColor: '#1b2234',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '14px',
                outline: 'none',
                boxSizing: 'border-box',
                opacity: loading ? 0.6 : 1,
              }}
            />
          </div>

          <div style=${{ marginBottom: '24px' }}>
            <label style=${{ display: 'block', fontSize: '12px', fontWeight: '600', color: '#8f9bb3', marginBottom: '6px' }}>
              Password
            </label>
            <input 
              type="password" 
              value=${password} 
              onChange=${(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
              disabled=${loading}
              style=${{
                width: '100%',
                height: '42px',
                padding: '0 14px',
                backgroundColor: '#1b2234',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '14px',
                outline: 'none',
                boxSizing: 'border-box',
                opacity: loading ? 0.6 : 1,
              }}
            />
          </div>

          <button 
            type="submit" 
            disabled=${loading}
            style=${{
              width: '100%',
              height: '44px',
              backgroundColor: loading ? '#0044bb' : '#0062ff',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: '700',
              fontSize: '15px',
              cursor: loading ? 'not-allowed' : 'pointer',
              boxShadow: '0 4px 14px rgba(0, 98, 255, 0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              transition: 'background-color 0.2s',
            }}
          >
            ${loading ? html`<span>⏳ Signing in…</span>` : html`<span>Sign In</span>`}
          </button>
        </form>
      </div>
    </div>
  `;
}
