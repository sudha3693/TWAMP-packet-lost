import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';

export default function SiteInfoImport({ userRole = 'admin' }) {
  const isAdmin = userRole === 'admin';
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const fileInputRef = useRef(null);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const records = await api.getSiteInfo();
      setData(records);
    } catch (err) {
      setError('Could not connect to the backend server. Please verify the FastAPI service is running on port 8000.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUploadFile = async (file) => {
    if (!file) return;
    const name = file.name.toLowerCase();
    if (!name.endsWith('.csv') && !name.endsWith('.xlsx')) {
      setError('Only CSV (.csv) and Excel (.xlsx) files are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadSiteInfo(formData);
      setMessage(res.message || 'File uploaded successfully.');
      loadData();
    } catch (err) {
      setError(err.message || 'Failed to upload file.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleUploadFile(e.target.files[0]);
    }
  };

  const onButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDeleteItem = async (siteId) => {
    if (!confirm(`Are you sure you want to delete the mapping for Site ID "${siteId}"?`)) return;
    try {
      await api.deleteSiteInfo(siteId);
      setData(data.filter((item) => item.site_id !== siteId));
    } catch (err) {
      alert(`Failed to delete record: ${err.message}`);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Are you sure you want to delete all site mapping records?')) return;
    try {
      await api.deleteAllSiteInfo();
      setData([]);
      setMessage('All mapping records cleared successfully.');
      setCurrentPage(1);
    } catch (err) {
      alert(`Failed to clear records: ${err.message}`);
    }
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };

  const handlePageSizeChange = (e) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  const filteredData = data.filter((item) => {
    const s = search.toLowerCase();
    return (
      (item.site_id && item.site_id.toLowerCase().includes(s)) ||
      (item.cluster && item.cluster.toLowerCase().includes(s)) ||
      (item.district && item.district.toLowerCase().includes(s))
    );
  });

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const pagedData = filteredData.slice((safePage - 1) * pageSize, safePage * pageSize);

  return html`
    <div>
      <div className="glass-panel" style=${{ marginBottom: '30px' }}>
        <h2 className="list-title" style=${{ marginBottom: '16px' }}>Site Info Mapping Import</h2>
        <p style=${{ color: 'hsl(var(--text-muted))', fontSize: '15px', marginBottom: '24px', lineHeight: '1.6' }}>
          Upload your site mapping spreadsheet here. The database stores <strong>Site ID</strong>, <strong>Cluster</strong>, and <strong>District</strong>. 
          The system dynamically validates headers case-insensitively. Supports both <strong>.csv</strong> and <strong>.xlsx</strong> files.
        </p>

        <!-- Drag & Drop Zone (Admin only) -->
        ${isAdmin ? html`
          <div 
            className=${`upload-zone ${dragActive ? 'drag-active' : ''}`}
            onDragEnter=${handleDrag}
            onDragOver=${handleDrag}
            onDragLeave=${handleDrag}
            onDrop=${handleDrop}
            onClick=${onButtonClick}
          >
            <input 
              type="file"
              ref=${fileInputRef}
              style=${{ display: 'none' }}
              onChange=${handleFileInputChange}
              accept=".xlsx,.csv"
            />
            <div className="upload-icon">
              ${uploading ? html`🔄` : html`📥`}
            </div>
            <div className="upload-text">
              ${uploading ? 'Processing & parsing sheet...' : 'Drag & drop CSV or Excel sheet here or click to browse'}
            </div>
            <div className="upload-subtext">
              Required columns: Site ID, Cluster, and District. Existing mappings will be refreshed.
            </div>
          </div>
        ` : html`
          <div style=${{ padding: '16px 20px', borderRadius: 'var(--radius-lg)', backgroundColor: 'rgba(59, 130, 246, 0.08)', border: '1px solid rgba(59, 130, 246, 0.2)', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style=${{ fontSize: '20px' }}>🔒</span>
            <div>
              <div style=${{ fontWeight: '600', fontSize: '14px', color: 'hsl(var(--text-main))' }}>Read-Only Mode</div>
              <div style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))' }}>Uploading mapping files and clearing database are restricted to Admin users.</div>
            </div>
          </div>
        `}

        <!-- Success Banner -->
        ${message && html`
          <div style=${{ 
            color: 'hsl(var(--success))', 
            backgroundColor: 'var(--success-glow)', 
            padding: '12px 16px', 
            borderRadius: 'var(--radius-md)', 
            marginTop: '20px',
            fontSize: '14px', 
            border: '1px solid rgba(34, 197, 94, 0.2)' 
          }}>
            ✅ <strong>Success:</strong> ${message}
          </div>
        `}

        <!-- Error Banner -->
        ${error && html`
          <div style=${{ 
            color: 'hsl(var(--danger))', 
            backgroundColor: 'var(--danger-glow)', 
            padding: '12px 16px', 
            borderRadius: 'var(--radius-md)', 
            marginTop: '20px',
            fontSize: '14px', 
            border: '1px solid rgba(244, 63, 94, 0.2)' 
          }}>
            ⚠️ <strong>Error:</strong> ${error}
          </div>
        `}
      </div>

      <!-- Imported Data Inventory -->
      <div className="glass-panel">
        <div className="list-header" style=${{ flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <h2 className="list-title">Site Info Mappings</h2>
            <p style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
              Showing <strong>${pagedData.length}</strong> of <strong>${filteredData.length}</strong> records
              ${filteredData.length !== data.length
                ? html` (filtered from <strong>${data.length}</strong> total)`
                : html` total`}
            </p>
          </div>

          <div style=${{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
            <input 
              type="text" 
              className="form-input search-bar" 
              placeholder="🔍 Search site mapping..." 
              value=${search} 
              onChange=${handleSearchChange}
              style=${{ width: '220px' }}
            />

            <select
              className="form-input"
              value=${pageSize}
              onChange=${handlePageSizeChange}
              style=${{ width: '110px', fontSize: '13px' }}
            >
              <option value=${25}>25 / page</option>
              <option value=${50}>50 / page</option>
              <option value=${100}>100 / page</option>
            </select>

            ${isAdmin && data.length > 0 && html`
              <button 
                type="button" 
                className="btn btn-danger btn-sm"
                onClick=${handleClearAll}
                title="Clear Database"
              >
                Clear All
              </button>
            `}
          </div>
        </div>

        <!-- Loading -->
        ${loading && html`
          <div style=${{ textAlign: 'center', padding: '48px 0', color: '#8f9bb3' }}>
            <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
            <p>Fetching imported records from SQLite database...</p>
          </div>
        `}

        <!-- Empty State -->
        ${!loading && filteredData.length === 0 && html`
          <div className="empty-state" style=${{ padding: '48px 0' }}>
            <div className="empty-icon">📁</div>
            <p>${data.length === 0
              ? 'No site info mappings have been imported yet. Upload a CSV or XLSX sheet above to get started.'
              : 'No mapping records match your search queries.'}</p>
          </div>
        `}

        <!-- Table -->
        ${!loading && pagedData.length > 0 && html`
          <div className="custom-table-container">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Site ID</th>
                  <th>Cluster</th>
                  <th>District</th>
                  <th style=${{ width: '80px', textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                ${pagedData.map((item) => html`
                  <tr key=${item.site_id}>
                    <td style=${{ color: 'hsl(var(--text-main))', fontWeight: '600' }}>
                      ${item.site_id || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    <td>
                      ${item.cluster || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    <td>
                      ${item.district || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    ${isAdmin && html`<td style=${{ textAlign: 'center' }}>
                      <button 
                        type="button" 
                        className="item-action-btn delete-btn"
                        onClick=${() => handleDeleteItem(item.site_id)}
                        title="Delete Record"
                        style=${{ padding: '6px' }}
                      >
                        🗑️
                      </button>
                    </td>`}
                  </tr>
                `)}
              </tbody>
            </table>
          </div>

          <!-- Pagination Controls -->
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '18px', flexWrap: 'wrap', gap: '12px' }}>
            <div style=${{ color: 'hsl(var(--text-muted))', fontSize: '13px' }}>
              Page <strong>${safePage}</strong> of <strong>${totalPages}</strong> — ${filteredData.length} records
            </div>
            <div style=${{ display: 'flex', gap: '8px' }}>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === 1}
                onClick=${() => setCurrentPage(1)}
              >««</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === 1}
                onClick=${() => setCurrentPage(safePage - 1)}
              >Previous</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === totalPages}
                onClick=${() => setCurrentPage(safePage + 1)}
              >Next</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === totalPages}
                onClick=${() => setCurrentPage(totalPages)}
              >»»</button>
            </div>
          </div>
        `}
      </div>
    </div>
  `;
}
