import React, { useState, useEffect } from 'react';
import html from '../html.js';
import { api } from '../api.js';
import SearchableDropdown from '../components/SearchableDropdown.js';

export default function SiteDetail({ siteName, siteId, onBack, initialFilters, initialSearch }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Date filter states
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // Other filter states initialized from incoming filters (if any)
  const [popName, setPopName] = useState(initialFilters?.popName || '');
  const [connectionType, setConnectionType] = useState(initialFilters?.connectionType || '');
  const [technology, setTechnology] = useState(initialFilters?.technology || '');
  const [plCount, setPlCount] = useState(initialFilters?.plCount || '');
  const [search, setSearch] = useState(initialSearch || '');
  const [resetKey, setResetKey] = useState(0);

  const [filterOptions, setFilterOptions] = useState({
    pop_names: [],
    connection_types: [],
    technologies: [],
    pl_counts: []
  });
  
  // Active panel tab state: 'rt' or 'count'
  const [activeTab, setActiveTab] = useState('rt');

  const loadData = async (
    start = startDate, 
    end = endDate, 
    pop = popName, 
    conn = connectionType, 
    tech = technology, 
    pl = plCount, 
    q = search
  ) => {
    setLoading(true);
    setError('');
    try {
      const result = await api.getPacketLossSiteDetail(siteName, siteId, start, end, pop, conn, tech, pl, q);
      setData(result || []);
    } catch (err) {
      setError(`Failed to retrieve site history: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const loadFilterOptions = async () => {
    try {
      const options = await api.getPacketLossSiteFilterOptions(siteName, siteId);
      setFilterOptions(options || { pop_names: [], connection_types: [], technologies: [], pl_counts: [] });
    } catch (err) {
      console.error("Failed to load filter options:", err);
    }
  };

  useEffect(() => {
    loadFilterOptions();
    loadData(
      startDate, 
      endDate, 
      initialFilters?.popName || '', 
      initialFilters?.connectionType || '', 
      initialFilters?.technology || '', 
      initialFilters?.plCount || '', 
      initialSearch || ''
    );
  }, [siteName, siteId]);

  const handleApplyFilters = (e) => {
    e.preventDefault();
    loadData(startDate, endDate, popName, connectionType, technology, plCount, search);
  };

  const handleResetFilters = () => {
    setStartDate('');
    setEndDate('');
    setPopName('');
    setConnectionType('');
    setTechnology('');
    setPlCount('');
    setSearch('');
    setResetKey(prev => prev + 1);
    loadData('', '', '', '', '', '', '');
  };

  const formatVal = (val) => {
    if (val === null || val === undefined || val === '') return '0';
    const num = parseFloat(val);
    if (!isNaN(num)) {
      return num % 1 === 0 ? num.toString() : num.toFixed(3);
    }
    return val;
  };

  const hasLoss = (val) => {
    const num = parseFloat(val);
    return !isNaN(num) && num > 0;
  };

  // Get metadata from the first record if available
  const siteInfo = data.length > 0 ? data[0] : {
    site_name: siteName,
    site_id: siteId,
    pop_name: 'N/A',
    connection_type: 'N/A',
    twamp_technology: 'N/A'
  };

  const hoursList = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));

  return html`
    <div style=${{ paddingBottom: '40px' }}>
      <!-- Back Button -->
      <button 
        type="button" 
        className="btn btn-secondary btn-sm" 
        onClick=${onBack}
        style=${{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        ⬅️ Back to Previous List
      </button>

      <!-- Site Meta Info Header -->
      <div className="glass-panel" style=${{ marginBottom: '24px', padding: '24px' }}>
        <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <span style=${{
              padding: '4px 10px',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: '600',
              backgroundColor: 'rgba(124, 77, 255, 0.15)',
              border: '1px solid rgba(124, 77, 255, 0.3)',
              color: 'hsl(var(--primary))',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Node Daily Analysis
            </span>
            <h2 style=${{ margin: '8px 0 4px 0', fontSize: '24px', fontWeight: '700', color: 'hsl(var(--text-main))' }}>
              ${siteInfo.site_name || siteName || 'Unknown Site'}
            </h2>
            <p style=${{ margin: 0, fontSize: '14px', color: 'hsl(var(--text-muted))' }}>
              Site ID: <strong style=${{ color: 'hsl(var(--primary))' }}>${siteInfo.site_id || siteId || 'N/A'}</strong>
            </p>
          </div>

          <!-- Metadata Tags -->
          <div style=${{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <div style=${{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--glass-border)',
              minWidth: '120px'
            }}>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Cluster</div>
              <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: siteInfo.cluster === 'Not Found' ? '#f87171' : '#34d399' }}>${siteInfo.cluster || 'Not Found'}</div>
            </div>
            <div style=${{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--glass-border)',
              minWidth: '120px'
            }}>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>District</div>
              <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: siteInfo.district === 'Not Found' ? '#f87171' : '#60a5fa' }}>${siteInfo.district || 'Not Found'}</div>
            </div>
            <div style=${{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--glass-border)',
              minWidth: '120px'
            }}>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>POP Name</div>
              <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${siteInfo.pop_name || 'N/A'}</div>
            </div>
            <div style=${{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--glass-border)',
              minWidth: '120px'
            }}>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Connection</div>
              <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${siteInfo.connection_type || 'N/A'}</div>
            </div>
            <div style=${{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--glass-border)',
              minWidth: '120px'
            }}>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Technology</div>
              <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${siteInfo.twamp_technology || 'N/A'}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Filters & Tab Panel -->
      <div className="glass-panel" style=${{ marginBottom: '24px', padding: '20px' }}>
        <h3 style=${{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', color: 'hsl(var(--primary))', display: 'flex', alignItems: 'center', gap: '6px' }}>
          🔍 Daily History Filters
        </h3>
        <form onSubmit=${handleApplyFilters}>
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '12px', marginBottom: '16px' }}>
            <div style=${{ display: 'flex', flexDirection: 'column' }}>
              <label style=${{ display: 'block', fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px', fontWeight: '500' }}>Start Date</label>
              <input 
                type="date" 
                value=${startDate} 
                onChange=${(e) => setStartDate(e.target.value)}
                style=${{
                  width: '100%',
                  height: '40px',
                  padding: '0 12px',
                  backgroundColor: '#1b2234',
                  border: '1px solid rgba(255,255,255,0.12)',
                  borderRadius: '6px',
                  color: '#fff',
                  fontSize: '14px',
                  outline: 'none'
                }}
              />
            </div>
            <div style=${{ display: 'flex', flexDirection: 'column' }}>
              <label style=${{ display: 'block', fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px', fontWeight: '500' }}>End Date</label>
              <input 
                type="date" 
                value=${endDate} 
                onChange=${(e) => setEndDate(e.target.value)}
                style=${{
                  width: '100%',
                  height: '40px',
                  padding: '0 12px',
                  backgroundColor: '#1b2234',
                  border: '1px solid rgba(255,255,255,0.12)',
                  borderRadius: '6px',
                  color: '#fff',
                  fontSize: '14px',
                  outline: 'none'
                }}
              />
            </div>
            <${SearchableDropdown}
              label="POP Name"
              value=${popName}
              options=${filterOptions.pop_names || []}
              placeholder="Search POP..."
              onChange=${setPopName}
              resetKey=${resetKey}
            />
            <${SearchableDropdown}
              label="Connection Type"
              value=${connectionType}
              options=${filterOptions.connection_types || []}
              placeholder="Search connection type..."
              onChange=${setConnectionType}
              resetKey=${resetKey}
            />
            <${SearchableDropdown}
              label="Technology"
              value=${technology}
              options=${filterOptions.technologies || []}
              placeholder="Search technology..."
              onChange=${setTechnology}
              resetKey=${resetKey}
            />
            <${SearchableDropdown}
              label="PL ≥0.5 Count"
              value=${plCount}
              options=${filterOptions.pl_counts || []}
              placeholder="Search PL count..."
              onChange=${setPlCount}
              resetKey=${resetKey}
            />
          </div>

          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <div style=${{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <input
                type="text"
                placeholder="Search metrics or details..."
                value=${search}
                onChange=${(e) => setSearch(e.target.value)}
                style=${{
                  width: '260px',
                  height: '40px',
                  padding: '0 12px',
                  backgroundColor: '#1b2234',
                  border: '1px solid rgba(255,255,255,0.12)',
                  borderRadius: '6px',
                  color: '#fff',
                  fontSize: '14px',
                  outline: 'none'
                }}
              />
              ${search && html`<button type="button" className="btn btn-secondary btn-sm" onClick=${() => { setSearch(''); loadData(startDate, endDate, popName, connectionType, technology, plCount, ''); }}>Clear Search</button>`}
            </div>
            
            <div style=${{ display: 'flex', gap: '8px' }}>
              <button type="button" className="btn btn-secondary btn-sm" onClick=${handleResetFilters}>Reset Filters</button>
              <button type="submit" className="btn btn-primary btn-sm">Apply Filters</button>
            </div>
          </div>
        </form>

        <div style=${{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
          <!-- Toggle Panel Tabs -->
          <div style=${{
            display: 'flex',
            backgroundColor: 'rgba(0,0,0,0.2)',
            padding: '4px',
            borderRadius: '8px',
            border: '1px solid var(--glass-border)'
          }}>
            <button
              type="button"
              onClick=${() => setActiveTab('rt')}
              style=${{
                padding: '8px 16px',
                borderRadius: '6px',
                border: 'none',
                backgroundColor: activeTab === 'rt' ? 'hsl(var(--primary))' : 'transparent',
                color: activeTab === 'rt' ? '#ffffff' : 'hsl(var(--text-muted))',
                fontSize: '13px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              RT Packet Loss (%)
            </button>
            <button
              type="button"
              onClick=${() => setActiveTab('count')}
              style=${{
                padding: '8px 16px',
                borderRadius: '6px',
                border: 'none',
                backgroundColor: activeTab === 'count' ? 'hsl(var(--primary))' : 'transparent',
                color: activeTab === 'count' ? '#ffffff' : 'hsl(var(--text-muted))',
                fontSize: '13px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              Packet Loss Count
            </button>
          </div>
        </div>
      </div>

      <!-- Detail Table Container -->
      <div className="glass-panel" style=${{ padding: '20px' }}>
        ${loading ? html`
          <div style=${{ textAlign: 'center', padding: '60px 0', color: '#8f9bb3' }}>
            <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
            <p>Loading historical daily records...</p>
          </div>
        ` : error ? html`
          <div className="notification error">${error}</div>
        ` : data.length === 0 ? html`
          <div className="empty-state">
            <div className="empty-icon">📅</div>
            <p>No historical packet loss records found for the selected filters.</p>
          </div>
        ` : html`
          <div className="custom-table-container" style=${{ overflowX: 'auto', overflowY: 'auto', maxHeight: '520px', position: 'relative' }}>
            <table className="custom-table" style=${{ minWidth: '1400px', tableLayout: 'fixed' }}>
              <thead>
                <tr>
                  <th style=${{ width: '135px', position: 'sticky', left: 0, top: 0, backgroundColor: 'var(--theme-table-header-bg, #131926)', color: 'var(--theme-text, #fff)', zIndex: 20, borderRight: '1px solid var(--glass-border)' }}>Date</th>
                  ${hoursList.map(h => html`
                    <th key=${h} style=${{ textAlign: 'center', width: '55px', fontSize: '11px', padding: '8px 4px', position: 'sticky', top: 0, backgroundColor: 'var(--theme-table-header-bg, #131926)', color: 'var(--theme-text, #fff)', zIndex: 10, boxShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
                      ${h}:00
                    </th>
                  `)}
                </tr>
              </thead>
              <tbody>
                ${data.map((row) => html`
                  <tr key=${row.id}>
                    <!-- Sticky Date column -->
                    <td style=${{ 
                      fontWeight: '600', 
                      color: 'hsl(var(--primary))', 
                      position: 'sticky', 
                      left: 0, 
                      backgroundColor: 'var(--theme-panel-bg, #131926)', 
                      zIndex: 8,
                      borderRight: '1px solid var(--glass-border)',
                      boxShadow: '2px 0 5px rgba(0,0,0,0.2)'
                    }}>
                      📅 ${row.report_date}
                    </td>

                    <!-- 24 hourly columns -->
                    ${hoursList.map(h => {
                      const valKey = activeTab === 'rt' ? `rt_packet_loss_${h}_percent` : `packet_loss_${h}_count`;
                      const cellValue = row[valKey];
                      const activeLoss = hasLoss(cellValue);
                      
                      return html`
                        <td 
                          key=${h} 
                          style=${{ 
                            textAlign: 'center', 
                            fontSize: '12px',
                            padding: '10px 4px',
                            transition: 'background-color 0.2s',
                            backgroundColor: activeLoss ? 'rgba(239, 68, 68, 0.18)' : 'transparent',
                            color: activeLoss ? '#ff4d6d' : 'hsl(var(--text-main))',
                            fontWeight: activeLoss ? '600' : 'normal',
                            border: activeLoss ? '1px solid rgba(239, 68, 68, 0.3)' : '1px solid var(--glass-border)'
                          }}
                          title=${`Hour ${h}:00 - Value: ${formatVal(cellValue)}${activeTab === 'rt' ? '%' : ''}`}
                        >
                          ${formatVal(cellValue)}${activeTab === 'rt' && activeLoss ? '%' : ''}
                        </td>
                      `;
                    })}
                  </tr>
                `)}
              </tbody>
            </table>
          </div>
        `}
      </div>
    </div>
  `;
}
