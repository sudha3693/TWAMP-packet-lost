import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';

export default function DailyTwampImport({ onSiteClick, userRole = 'admin' }) {
  const isAdmin = userRole === 'admin';
  const [tables, setTables] = useState([]);
  const [loadingTables, setLoadingTables] = useState(true);
  const [selectedTable, setSelectedTable] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [totalRows, setTotalRows] = useState(0);
  const [loadingData, setLoadingData] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [expandedRowId, setExpandedRowId] = useState(null);

  // Selected site for detailed single-day TWAMP analysis
  const [selectedSiteRecord, setSelectedSiteRecord] = useState(null);
  const [detailActiveTab, setDetailActiveTab] = useState('rt'); // 'rt' or 'count'

  const fileInputRef = useRef(null);
  const pageSize = 10;

  const loadTables = async () => {
    setLoadingTables(true);
    setError('');
    try {
      const list = await api.getDailyTwampTables();
      setTables(list || []);
    } catch (err) {
      setError('Could not load tables from backend.');
    } finally {
      setLoadingTables(false);
    }
  };

  const loadTableData = async (tableName, page = 1, searchQuery = '') => {
    setLoadingData(true);
    setExpandedRowId(null);
    setSelectedSiteRecord(null);
    try {
      const res = await api.getDailyTwampData(tableName, searchQuery, (page - 1) * pageSize, pageSize);
      setTableData(res.rows || []);
      setTotalRows(res.total || 0);
    } catch (err) {
      setError(`Failed to load table data: ${err.message}`);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    loadTables();
  }, []);

  useEffect(() => {
    if (selectedTable) {
      loadTableData(selectedTable.table_name, currentPage, search);
    }
  }, [selectedTable, currentPage, search]);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (selectedTable) {
      setCurrentPage(1);
      loadTableData(selectedTable.table_name, 1, search);
    }
  };

  const handleClearSearch = () => {
    setSearch('');
    if (selectedTable) {
      setCurrentPage(1);
      loadTableData(selectedTable.table_name, 1, '');
    }
  };

  const handleUploadFile = async (file) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.xlsx') && !file.name.toLowerCase().endsWith('.xls')) {
      setError('Only Excel files (.xlsx / .xls) are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadDailyTwamp(formData);
      setMessage(res.message || 'Daily TWAMP file uploaded successfully.');
      loadTables();
    } catch (err) {
      setError(err.message || 'Failed to upload file.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleDeleteTable = async (tableName, e) => {
    e.stopPropagation();
    if (!confirm(`Delete table ${tableName}? This action cannot be undone.`)) return;
    try {
      await api.deleteDailyTwampTable(tableName);
      setTables(tables.filter((t) => t.table_name !== tableName));
      if (selectedTable && selectedTable.table_name === tableName) {
        setSelectedTable(null);
        setTableData([]);
        setSelectedSiteRecord(null);
      }
      setMessage('Table deleted successfully.');
    } catch (err) {
      alert(`Failed to delete table: ${err.message}`);
    }
  };

  const handleViewTable = (table) => {
    setSelectedTable(table);
    setCurrentPage(1);
    setSearch('');
    setSelectedSiteRecord(null);
  };

  const handleBackToList = () => {
    setSelectedTable(null);
    setTableData([]);
    setTotalRows(0);
    setSearch('');
    setSelectedSiteRecord(null);
  };

  const toggleRowExpansion = (rowId) => {
    setExpandedRowId(expandedRowId === rowId ? null : rowId);
  };

  const formatVal = (val) => {
    if (val === null || val === undefined || val === '') return '0';
    const num = parseFloat(val);
    if (!isNaN(num)) {
      return num % 1 === 0 ? num.toString() : num.toFixed(4);
    }
    return val;
  };

  const isSignificantLoss = (pct, cnt) => {
    const p = parseFloat(pct);
    const c = parseInt(cnt);
    return (p > 0) || (c > 0);
  };

  // ---------------------------------------------------------------------------
  // 24-Hour Timeline Cards Breakdown
  // ---------------------------------------------------------------------------
  const renderHourlyTimeline = (row) => {
    const hourlyData = Array.from({ length: 24 }, (_, h) => {
      const hStr = h.toString().padStart(2, '0');
      const pctKey = 'rt_packet_loss_' + hStr + '_percent';
      const cntKey = 'packet_loss_' + hStr + '_count';
      const pct = row[pctKey];
      const count = row[cntKey];
      const hasLoss = isSignificantLoss(pct, count);
      const label = hStr + ':00 - ' + (h + 1).toString().padStart(2, '0') + ':00';
      return { h, hStr, pct, count, hasLoss, label };
    });

    return html`
      <div style=${{
        padding: '20px',
        backgroundColor: 'rgba(0, 0, 0, 0.25)',
        borderRadius: 'var(--radius-md)',
        border: '1px solid var(--glass-border)',
        marginTop: '10px',
        marginBottom: '10px'
      }}>
        <h4 style=${{ fontSize: '14px', marginBottom: '12px', fontWeight: '600', color: 'hsl(var(--primary))' }}>
          Daily TWAMP 24-Hour Packet Loss Timeline${selectedTable ? ' (' + selectedTable.report_date + ')' : ''}
        </h4>
        <div style=${{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))',
          gap: '10px'
        }}>
          ${hourlyData.map((item) => html`
            <div key=${item.h} style=${{
              padding: '10px',
              borderRadius: '6px',
              border: '1px solid ' + (item.hasLoss ? 'rgba(239, 68, 68, 0.4)' : 'var(--glass-border)'),
              backgroundColor: item.hasLoss ? 'rgba(239, 68, 68, 0.08)' : 'rgba(255, 255, 255, 0.02)',
              textAlign: 'center',
              transition: 'var(--transition-smooth)'
            }}>
              <div style=${{ fontSize: '11px', fontWeight: '600', color: item.hasLoss ? 'hsl(var(--danger))' : 'hsl(var(--text-muted))', marginBottom: '4px' }}>
                ${item.label}
              </div>
              <div style=${{ fontSize: '13px', fontWeight: '500', color: item.hasLoss ? '#ff4d6d' : 'hsl(var(--text-main))' }}>
                Loss: ${formatVal(item.pct)}%
              </div>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', marginTop: '2px' }}>
                Count: ${formatVal(item.count)}
              </div>
            </div>
          `)}
        </div>
      </div>
    `;
  };

  // ---------------------------------------------------------------------------
  // Dedicated Single-Day TWAMP Site Detail Page (Matches Packet Loss SiteDetail UI)
  // ---------------------------------------------------------------------------
  const renderDailySiteDetail = (row) => {
    const hoursList = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
    const shortNameVal = row.short_name || row.shortname || 'N/A';
    const siteIdVal = row.site_id && row.site_id !== 'Not Found' ? row.site_id : 'N/A';
    const rawPlCount = row.packet_loss_0_5_90_percent_count || row.packet_loss_05_90_percent_count || row.packet_loss_2_90_percent_count || '0';
    const plCount = parseInt(rawPlCount) || 0;
    const maxPl = row.max_packet_loss_hour_percent || '0.00';

    return html`
      <div style=${{ paddingBottom: '40px' }}>
        <!-- Back Button -->
        <button 
          type="button" 
          className="btn btn-secondary btn-sm" 
          onClick=${() => setSelectedSiteRecord(null)}
          style=${{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          ⬅️ Back to Daily TWAMP Table
        </button>

        <!-- Site Meta Info Header Card -->
        <div className="glass-panel" style=${{ marginBottom: '24px', padding: '24px' }}>
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <span style=${{
                padding: '4px 10px',
                borderRadius: '4px',
                fontSize: '12px',
                fontWeight: '600',
                backgroundColor: 'rgba(124, 77, 255, 0.15)',
                border: '1px solid rgba(124, 77, 255, 0.3)',
                color: 'hsl(var(--primary))',
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}>
                Daily TWAMP Node Analysis (Single Day)
              </span>
              <h2 style=${{ margin: '8px 0 4px 0', fontSize: '22px', fontWeight: '700', color: 'hsl(var(--text-main))' }}>
                ${shortNameVal}
              </h2>
              <p style=${{ margin: 0, fontSize: '14px', color: 'hsl(var(--text-muted))' }}>
                Site ID: <strong style=${{ color: 'hsl(var(--primary))' }}>${siteIdVal}</strong>
                ${selectedTable ? html` &bull; Report Date: <strong style=${{ color: '#34d399' }}>📅 ${selectedTable.report_date}</strong>` : ''}
              </p>
            </div>

            <!-- Metadata Cards -->
            <div style=${{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Cluster</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: row.cluster === 'Not Found' ? '#f87171' : '#34d399' }}>${row.cluster || 'Not Found'}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>District</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: row.district === 'Not Found' ? '#f87171' : '#60a5fa' }}>${row.district || 'Not Found'}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Site Type</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${row.site_type || 'N/A'}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>POP Name</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${row.pop_name || 'N/A'}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Connection</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px' }}>${row.connection_type || 'N/A'}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>PL 05-90 Count</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: plCount > 0 ? '#ff4d6d' : '#34d399' }}>${plCount}</div>
              </div>
              <div style=${{ padding: '10px 16px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--glass-border)', minWidth: '110px' }}>
                <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', textTransform: 'uppercase' }}>Max Loss %</div>
                <div style=${{ fontSize: '14px', fontWeight: '600', marginTop: '4px', color: parseFloat(maxPl) > 0 ? '#ff4d6d' : '#34d399' }}>${formatVal(maxPl)}%</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Tab Panel Toggle (RT Packet Loss % vs Packet Loss Count) -->
        <div className="glass-panel" style=${{ marginBottom: '24px', padding: '20px' }}>
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style=${{ fontSize: '15px', fontWeight: '600', color: 'hsl(var(--primary))' }}>
              📊 24-Hour Packet Loss Metrics Matrix
            </h3>
            <div style=${{
              display: 'flex',
              backgroundColor: 'rgba(0,0,0,0.2)',
              padding: '4px',
              borderRadius: '8px',
              border: '1px solid var(--glass-border)'
            }}>
              <button
                type="button"
                onClick=${() => setDetailActiveTab('rt')}
                style=${{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: detailActiveTab === 'rt' ? 'hsl(var(--primary))' : 'transparent',
                  color: detailActiveTab === 'rt' ? '#ffffff' : 'hsl(var(--text-muted))',
                  fontSize: '13px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                RT Packet Loss (%)
              </button>
              <button
                type="button"
                onClick=${() => setDetailActiveTab('count')}
                style=${{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: detailActiveTab === 'count' ? 'hsl(var(--primary))' : 'transparent',
                  color: detailActiveTab === 'count' ? '#ffffff' : 'hsl(var(--text-muted))',
                  fontSize: '13px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                Packet Loss Count
              </button>
            </div>
          </div>
        </div>

        <!-- Matrix Table Container -->
        <div className="glass-panel" style=${{ padding: '20px', marginBottom: '24px' }}>
          <div className="custom-table-container" style=${{ overflowX: 'auto' }}>
            <table className="custom-table" style=${{ minWidth: '1400px', tableLayout: 'fixed' }}>
              <thead>
                <tr>
                  <th style=${{ width: '135px', backgroundColor: 'var(--theme-table-header-bg, #131926)', color: '#fff' }}>Date</th>
                  ${hoursList.map(h => html`
                    <th key=${h} style=${{ textAlign: 'center', width: '55px', fontSize: '11px', padding: '8px 4px', backgroundColor: 'var(--theme-table-header-bg, #131926)', color: '#fff' }}>
                      ${h}:00
                    </th>
                  `)}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style=${{ fontWeight: '600', color: 'hsl(var(--primary))' }}>
                    📅 ${selectedTable ? selectedTable.report_date : 'Daily'}
                  </td>
                  ${hoursList.map(h => {
                    const valKey = detailActiveTab === 'rt' ? `rt_packet_loss_${h}_percent` : `packet_loss_${h}_count`;
                    const cellValue = row[valKey];
                    const activeLoss = isSignificantLoss(row[`rt_packet_loss_${h}_percent`], row[`packet_loss_${h}_count`]);

                    return html`
                      <td 
                        key=${h} 
                        style=${{ 
                          textAlign: 'center', 
                          fontSize: '12px',
                          padding: '10px 4px',
                          backgroundColor: activeLoss ? 'rgba(239, 68, 68, 0.18)' : 'transparent',
                          color: activeLoss ? '#ff4d6d' : 'hsl(var(--text-main))',
                          fontWeight: activeLoss ? '600' : 'normal',
                          border: activeLoss ? '1px solid rgba(239, 68, 68, 0.3)' : '1px solid var(--glass-border)'
                        }}
                        title=${`Hour ${h}:00 - Value: ${formatVal(cellValue)}${detailActiveTab === 'rt' ? '%' : ''}`}
                      >
                        ${formatVal(cellValue)}${detailActiveTab === 'rt' && activeLoss ? '%' : ''}
                      </td>
                    `;
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- 24-Hour Visual Cards Grid -->
        <div className="glass-panel" style=${{ padding: '20px' }}>
          <h4 style=${{ fontSize: '14px', marginBottom: '16px', fontWeight: '600', color: 'hsl(var(--primary))' }}>
            24-Hour Timeline Breakdown Cards (${selectedTable ? selectedTable.report_date : ''})
          </h4>
          ${renderHourlyTimeline(row)}
        </div>
      </div>
    `;
  };

  const totalPages = Math.ceil(totalRows / pageSize);

  // ===========================================================================
  // RENDER
  // ===========================================================================
  return html`
    <div>
      <!-- If a site detail record is clicked, show single-day TWAMP site detail view -->
      ${selectedSiteRecord ? renderDailySiteDetail(selectedSiteRecord) : html`
        <${React.Fragment}>
          <!-- LIST VIEW (no table selected) -->
          ${!selectedTable && html`
            <div className="glass-panel" style=${{ marginBottom: '30px' }}>
              <h2 className="list-title" style=${{ marginBottom: '16px' }}>Daily TWAMP Import Manager</h2>
              <p style=${{ color: 'hsl(var(--text-muted))', fontSize: '15px', marginBottom: '24px', lineHeight: '1.6' }}>
                Upload daily TWAMP Excel sheets (.xlsx / .xls). An automated per-day table named <strong>twamp_YYYY_MM_DD</strong> is created for each report date.
              </p>

              <!-- Upload Zone (Admin only) -->
              ${isAdmin ? html`
                <div
                  className="upload-dropzone"
                  onDragEnter=${handleDrag}
                  onDragOver=${handleDrag}
                  onDragLeave=${handleDrag}
                  onDrop=${handleDrop}
                  onClick=${() => !uploading && fileInputRef.current && fileInputRef.current.click()}
                  style=${{
                    border: `2px dashed ${dragActive ? 'hsl(var(--primary))' : 'var(--glass-border)'}`,
                    borderRadius: 'var(--radius-lg)',
                    padding: '48px 24px',
                    textAlign: 'center',
                    cursor: uploading ? 'not-allowed' : 'pointer',
                    backgroundColor: dragActive ? 'rgba(0,98,255,0.06)' : 'var(--theme-panel-bg)',
                    transition: 'border-color 0.2s, background-color 0.2s',
                    marginBottom: '20px',
                  }}
                >
                  <input
                    ref=${fileInputRef}
                    type="file"
                    accept=".xlsx,.xls"
                    style=${{ display: 'none' }}
                    onChange=${(e) => e.target.files[0] && handleUploadFile(e.target.files[0])}
                  />

                  <div className="upload-icon" style=${{ fontSize: uploading ? '32px' : '40px', marginBottom: '12px' }}>
                    ${uploading ? '🔄' : '📥'}
                  </div>
                  <div className="upload-text" style=${{ fontWeight: '700', fontSize: uploading ? '14px' : '16px', color: 'var(--theme-text)', marginBottom: '6px' }}>
                    ${uploading ? 'Importing daily TWAMP report...' : 'Drag & drop Excel report here or click to browse'}
                  </div>
                  <div className="upload-subtext" style=${{ fontSize: '13px', color: 'var(--theme-text-muted)' }}>
                    ${uploading ? 'Processing sheet and storing hourly logs.' : '.xlsx / .xls files supported'}
                  </div>
                </div>
              ` : html`
                <div style=${{ padding: '16px 20px', borderRadius: 'var(--radius-lg)', backgroundColor: 'rgba(59, 130, 246, 0.08)', border: '1px solid rgba(59, 130, 246, 0.2)', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style=${{ fontSize: '20px' }}>🔒</span>
                  <div>
                    <div style=${{ fontWeight: '600', fontSize: '14px', color: 'hsl(var(--text-main))' }}>Read-Only Mode</div>
                    <div style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))' }}>Uploading Excel files and deleting tables are restricted to Admin users.</div>
                  </div>
                </div>
              `}

              <!-- Messages -->
              ${message && html`
                <div style=${{ 
                  color: 'hsl(var(--success))', 
                  backgroundColor: 'var(--success-glow)', 
                  padding: '12px 16px', 
                  borderRadius: 'var(--radius-md)', 
                  marginBottom: '20px', 
                  fontSize: '14px', 
                  border: '1px solid rgba(34, 197, 94, 0.2)' 
                }}>
                  ✅ <strong>Success:</strong> ${message}
                </div>
              `}
              ${error && html`
                <div style=${{ 
                  color: 'hsl(var(--danger))', 
                  backgroundColor: 'var(--danger-glow)', 
                  padding: '12px 16px', 
                  borderRadius: 'var(--radius-md)', 
                  marginBottom: '20px', 
                  fontSize: '14px', 
                  border: '1px solid rgba(244, 63, 94, 0.2)' 
                }}>
                  ⚠️ <strong>Error:</strong> ${error}
                </div>
              `}
            </div>

            <!-- Tables Index -->
            <div className="glass-panel">
              <div className="list-header" style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <div>
                  <h2 className="list-title">Imported Daily TWAMP Tables</h2>
                  <p style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
                    Found <strong>${tables.length}</strong> imported daily TWAMP tables.
                  </p>
                </div>
              </div>

              ${loadingTables ? html`
                <div style=${{ textAlign: 'center', padding: '48px 0', color: '#8f9bb3' }}>
                  <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
                  <p>Fetching daily TWAMP tables...</p>
                </div>
              ` : tables.length === 0 ? html`
                <div className="empty-state">
                  <div className="empty-icon">📊</div>
                  <p>No daily TWAMP tables imported yet.</p>
                </div>
              ` : html`
                <div className="custom-table-container">
                  <table className="custom-table">
                    <thead>
                      <tr>
                        <th>Table Name</th>
                        <th>Report Date</th>
                        <th>Total Rows</th>
                        <th style=${{ textAlign: 'center', width: '150px' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${tables.map((table) => html`
                        <tr 
                          key=${table.table_name} 
                          onClick=${() => handleViewTable(table)}
                          style=${{ cursor: 'pointer', transition: 'var(--transition-smooth)' }}
                          className="report-row-hover"
                        >
                          <td style=${{ fontFamily: 'monospace', fontWeight: '600', color: 'hsl(var(--primary))' }}>
                            ${table.table_name}
                          </td>
                          <td style=${{ fontWeight: '600', color: 'hsl(var(--primary))' }}>
                            📅 ${table.report_date}
                          </td>
                          <td style=${{ fontWeight: '500' }}>
                            ${table.row_count.toLocaleString()} rows
                          </td>
                          <td style=${{ textAlign: 'center' }} onClick=${(e) => e.stopPropagation()}>
                            <div style=${{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                              <button 
                                type="button" 
                                className="btn btn-secondary btn-sm"
                                onClick=${() => handleViewTable(table)}
                                style=${{ padding: '5px 10px', fontSize: '12px' }}
                              >
                                👁️ View Data
                              </button>
                              ${isAdmin && html`
                                <button 
                                  type="button" 
                                  className="item-action-btn delete-btn"
                                  onClick=${(e) => handleDeleteTable(table.table_name, e)}
                                  style=${{ padding: '6px' }}
                                >
                                  🗑️
                                </button>
                              `}
                            </div>
                          </td>
                        </tr>
                      `)}
                    </tbody>
                  </table>
                </div>
              `}
            </div>
          `}

          <!-- DETAIL VIEW (a daily TWAMP table is selected) -->
          ${selectedTable && html`
            <div className="glass-panel" style=${{ marginBottom: '30px' }}>
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px', marginBottom: '20px' }}>
                <div>
                  <button 
                    type="button" 
                    className="btn btn-secondary btn-sm" 
                    onClick=${handleBackToList}
                    style=${{ marginBottom: '10px' }}
                  >
                    ⬅️ Back to Tables List
                  </button>
                  <h2 className="list-title" style=${{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span>Table: ${selectedTable.table_name}</span>
                    <span style=${{
                      padding: '4px 10px',
                      borderRadius: '4px',
                      fontSize: '13px',
                      backgroundColor: 'rgba(124, 77, 255, 0.1)',
                      border: '1px solid rgba(124, 77, 255, 0.2)',
                      color: 'hsl(var(--primary))',
                      fontWeight: '500'
                    }}>
                      📅 ${selectedTable.report_date}
                    </span>
                  </h2>
                  <p style=${{ fontSize: '14px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
                    Showing daily TWAMP loss metrics for <strong>${totalRows}</strong> records (single day: ${selectedTable.report_date}).
                  </p>
                </div>

                <!-- Search Form -->
                <form onSubmit=${handleSearchSubmit} style=${{ display: 'flex', gap: '8px' }}>
                  <input 
                    type="text" 
                    className="form-input" 
                    placeholder="Search Site ID, POP Name, Short Name, Cluster..." 
                    value=${search} 
                    onChange=${handleSearchChange}
                    style=${{ width: '280px', padding: '8px 12px', backgroundColor: 'var(--theme-input-bg)', border: '1px solid var(--theme-border)', borderRadius: '6px', color: 'var(--theme-input-color)', fontSize: '14px' }}
                  />
                  <button type="submit" className="btn btn-primary btn-sm" style=${{ padding: '8px 16px', backgroundColor: '#0062ff', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '600' }}>Search</button>
                  ${search && html`
                    <button type="button" className="btn btn-secondary btn-sm" onClick=${handleClearSearch} style=${{ padding: '8px 16px', backgroundColor: 'var(--theme-badge-bg)', border: '1px solid var(--theme-border)', borderRadius: '6px', cursor: 'pointer', color: 'var(--theme-text)' }}>Clear</button>
                  `}
                </form>
              </div>

              <!-- Data Table -->
              ${loadingData ? html`
                <div style=${{ textAlign: 'center', padding: '60px 0', color: '#8f9bb3' }}>
                  <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
                  <p>Fetching daily TWAMP records from database...</p>
                </div>
              ` : tableData.length === 0 ? html`
                <div className="empty-state">
                  <div className="empty-icon">🔍</div>
                  <p>No matching daily TWAMP records found for "${search}".</p>
                </div>
              ` : html`
                <div className="custom-table-container">
                  <table className="custom-table" style=${{ minWidth: '1000px' }}>
                    <thead>
                      <tr>
                        <th style=${{ width: '36px', textAlign: 'center' }}></th>
                        <th style=${{ minWidth: '180px' }}>Short Name</th>
                        <th style=${{ minWidth: '130px' }}>Site ID</th>
                        <th style=${{ minWidth: '110px' }}>Cluster</th>
                        <th style=${{ minWidth: '110px' }}>District</th>
                        <th style=${{ minWidth: '100px' }}>Site Type</th>
                        <th style=${{ minWidth: '120px' }}>POP Name</th>
                        <th style=${{ minWidth: '100px' }}>Conn. Type</th>
                        <th style=${{ minWidth: '110px', textAlign: 'center' }}>PL 05-90 Count</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${tableData.map((row, idx) => {
                        const rowId = row.id || idx;
                        const isExpanded = expandedRowId === rowId;
                        const shortNameVal = row.short_name || row.shortname || '';
                        const popNameVal = row.pop_name || '';
                        const siteIdVal = row.site_id && row.site_id !== 'Not Found' ? row.site_id : '';
                        const rawPlCount = row.packet_loss_0_5_90_percent_count || row.packet_loss_05_90_percent_count || row.packet_loss_2_90_percent_count || '0';
                        const plCount = parseInt(rawPlCount) || 0;
                        const hasLoss = plCount > 0;

                        return html`
                          <${React.Fragment} key=${rowId}>
                            <tr 
                              onClick=${() => toggleRowExpansion(rowId)}
                              style=${{ cursor: 'pointer' }}
                            >
                              <td style=${{ textAlign: 'center', width: '36px' }}>
                                <span style=${{ 
                                  display: 'inline-block', 
                                  transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
                                  transition: 'transform 0.2s',
                                  color: 'hsl(var(--primary))',
                                  fontWeight: 'bold'
                                }}>
                                  ▶
                                </span>
                              </td>
                              <td>
                                <div style=${{ fontWeight: '600', color: 'hsl(var(--text-main))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '240px' }} title=${shortNameVal || 'N/A'}>
                                  ${shortNameVal ? html`
                                    <a 
                                      href="#"
                                      onClick=${(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setSelectedSiteRecord(row);
                                      }}
                                      style=${{
                                        color: 'hsl(var(--text-main))',
                                        textDecoration: 'underline',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      ${shortNameVal}
                                    </a>
                                  ` : html`<em>N/A</em>`}
                                </div>
                              </td>
                              <td>
                                <div style=${{ fontWeight: '600', color: 'hsl(var(--primary))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '130px' }} title=${siteIdVal || 'N/A'}>
                                  ${siteIdVal ? html`
                                    <a 
                                      href="#"
                                      onClick=${(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setSelectedSiteRecord(row);
                                      }}
                                      style=${{
                                        fontWeight: '600',
                                        color: 'hsl(var(--primary))',
                                        textDecoration: 'underline',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      ${siteIdVal}
                                    </a>
                                  ` : html`<span style=${{ color: 'hsl(var(--text-muted))', fontStyle: 'italic' }}>${row.site_id || 'N/A'}</span>`}
                                </div>
                              </td>
                              <td style=${{ whiteSpace: 'nowrap' }}>
                                <span style=${{
                                  padding: '2px 6px',
                                  borderRadius: '4px',
                                  fontSize: '12px',
                                  backgroundColor: row.cluster === 'Not Found' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                                  color: row.cluster === 'Not Found' ? '#f87171' : '#34d399',
                                  border: row.cluster === 'Not Found' ? '1px solid rgba(239, 68, 68, 0.2)' : '1px solid rgba(16, 185, 129, 0.2)'
                                }}>
                                  ${row.cluster || 'Not Found'}
                                </span>
                              </td>
                              <td style=${{ whiteSpace: 'nowrap' }}>
                                <span style=${{
                                  padding: '2px 6px',
                                  borderRadius: '4px',
                                  fontSize: '12px',
                                  backgroundColor: row.district === 'Not Found' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(59, 130, 246, 0.1)',
                                  color: row.district === 'Not Found' ? '#f87171' : '#60a5fa',
                                  border: row.district === 'Not Found' ? '1px solid rgba(239, 68, 68, 0.2)' : '1px solid rgba(59, 130, 246, 0.2)'
                                }}>
                                  ${row.district || 'Not Found'}
                                </span>
                              </td>
                              <td style=${{ whiteSpace: 'nowrap' }}>
                                ${row.site_type || 'N/A'}
                              </td>
                              <td style=${{ whiteSpace: 'nowrap' }}>
                                <div style=${{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '140px' }} title=${popNameVal || 'N/A'}>
                                  ${popNameVal || 'N/A'}
                                </div>
                              </td>
                              <td style=${{ whiteSpace: 'nowrap' }}>
                                ${row.connection_type || 'N/A'}
                              </td>
                              <td style=${{ textAlign: 'center' }}>
                                <span style=${{
                                  padding: '3px 8px',
                                  borderRadius: '12px',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  whiteSpace: 'nowrap',
                                  backgroundColor: hasLoss ? 'var(--danger-glow)' : 'rgba(255,255,255,0.02)',
                                  border: '1px solid ' + (hasLoss ? 'rgba(244,63,94,0.3)' : 'var(--glass-border)'),
                                  color: hasLoss ? 'hsl(var(--danger))' : 'hsl(var(--text-muted))'
                                }}>
                                  ${plCount}
                                </span>
                              </td>
                            </tr>
                            ${isExpanded && html`
                              <tr>
                                <td colSpan=${9} style=${{ padding: '0', backgroundColor: 'rgba(0,0,0,0.1)' }}>
                                  ${renderHourlyTimeline(row)}
                                </td>
                              </tr>
                            `}
                          </${React.Fragment}>
                        `;
                      })}
                    </tbody>
                  </table>
                </div>

                <!-- Pagination Row -->
                ${totalPages > 1 && html`
                  <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '20px' }}>
                    <div style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))' }}>
                      Page <strong>${currentPage}</strong> of <strong>${totalPages}</strong> (Total <strong>${totalRows}</strong> records)
                    </div>
                    <div style=${{ display: 'flex', gap: '8px' }}>
                      <button 
                        type="button" 
                        className="btn btn-secondary btn-sm" 
                        disabled=${currentPage === 1}
                        onClick=${() => setCurrentPage(currentPage - 1)}
                      >
                        Previous
                      </button>
                      <button 
                        type="button" 
                        className="btn btn-secondary btn-sm" 
                        disabled=${currentPage === totalPages}
                        onClick=${() => setCurrentPage(currentPage + 1)}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                `}
              `}
            </div>
          `}
        </${React.Fragment}>
      `}
    </div>
  `;
}
