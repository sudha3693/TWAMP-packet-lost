import React, { useState, useEffect } from 'react';
import html from '../html.js';

const STORAGE_KEY = 'twamp_extra_users_db';

function loadExtraUsers() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

function saveExtraUsers(users) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  } catch {}
}

export default function UserManagement({ isDarkMode }) {
  // env-based accounts (loaded from backend, read-only)
  const [envUsers, setEnvUsers]         = useState([]);
  const [envLoading, setEnvLoading]     = useState(true);

  // extra manually-added accounts (stored in localStorage)
  const [extraUsers, setExtraUsers]     = useState(loadExtraUsers);

  const [showForm, setShowForm]         = useState(false);
  const [form, setForm]                 = useState({ username: '', password: '', name: '', role: 'user' });
  const [formError, setFormError]       = useState('');
  const [showPwdFor, setShowPwdFor]     = useState(null);
  const [editId, setEditId]             = useState(null);
  const [searchQ, setSearchQ]           = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  // Load env accounts from backend on mount
  useEffect(() => {
    setEnvLoading(true);
    fetch('/api/v1/auth/users')
      .then(r => r.json())
      .then(data => {
        setEnvUsers(Array.isArray(data) ? data.map((u, i) => ({ ...u, id: `env_${i}`, isEnv: true })) : []);
      })
      .catch(() => setEnvUsers([]))
      .finally(() => setEnvLoading(false));
  }, []);

  // Persist extra users on every change
  useEffect(() => { saveExtraUsers(extraUsers); }, [extraUsers]);

  const theme = isDarkMode ? {
    panel:    '#111622',
    border:   'rgba(255,255,255,0.08)',
    borderS:  'rgba(255,255,255,0.14)',
    text:     '#fff',
    muted:    '#8f9bb3',
    input:    '#1b2234',
    inputC:   '#fff',
    rowHover: 'rgba(255,255,255,0.03)',
    badgeBg:  'rgba(255,255,255,0.06)',
    tableHdr: '#0d1117',
  } : {
    panel:    '#fff',
    border:   'rgba(0,0,0,0.09)',
    borderS:  'rgba(0,0,0,0.14)',
    text:     '#111827',
    muted:    '#4b5563',
    input:    '#f0f4f9',
    inputC:   '#111827',
    rowHover: 'rgba(0,0,0,0.02)',
    badgeBg:  'rgba(0,0,0,0.05)',
    tableHdr: '#f8fafc',
  };

  const inputStyle = {
    width: '100%', height: '40px', padding: '0 12px',
    backgroundColor: theme.input, border: `1px solid ${theme.borderS}`,
    borderRadius: '8px', color: theme.inputC, fontSize: '13px', outline: 'none',
    boxSizing: 'border-box',
  };

  const labelStyle = {
    display: 'block', fontSize: '12px', fontWeight: '600',
    color: theme.muted, marginBottom: '5px',
  };

  // All users combined for display
  const allUsers = [...envUsers, ...extraUsers];

  const filtered = allUsers.filter(u =>
    u.username.toLowerCase().includes(searchQ.toLowerCase()) ||
    u.name.toLowerCase().includes(searchQ.toLowerCase()) ||
    u.role.toLowerCase().includes(searchQ.toLowerCase())
  );

  const openAdd = () => {
    setEditId(null);
    setForm({ username: '', password: '', name: '', role: 'user' });
    setFormError('');
    setShowForm(true);
  };

  const openEdit = (user) => {
    setEditId(user.id);
    setForm({ username: user.username, password: user.password || '', name: user.name, role: user.role });
    setFormError('');
    setShowForm(true);
  };

  const handleFormChange = (field, val) => setForm(prev => ({ ...prev, [field]: val }));

  const handleSave = () => {
    const u = form.username.trim();
    const p = form.password.trim();
    const n = form.name.trim();

    if (!u || !p || !n) { setFormError('All fields are required.'); return; }
    if (u.length < 3)   { setFormError('Username must be at least 3 characters.'); return; }
    if (p.length < 6)   { setFormError('Password must be at least 6 characters.'); return; }

    // Check duplicate username
    const dup = allUsers.find(x => x.username === u && x.id !== editId);
    if (dup) { setFormError(`Username "${u}" already exists.`); return; }

    if (editId) {
      setExtraUsers(prev => prev.map(x =>
        x.id === editId ? { ...x, username: u, password: p, name: n, role: form.role } : x
      ));
    } else {
      const newId = `extra_${Date.now()}`;
      setExtraUsers(prev => [...prev, { id: newId, username: u, password: p, name: n, role: form.role, isEnv: false }]);
    }
    setShowForm(false);
    setEditId(null);
    setForm({ username: '', password: '', name: '', role: 'user' });
    setFormError('');
  };

  const handleDelete = (id) => {
    setExtraUsers(prev => prev.filter(x => x.id !== id));
    setDeleteConfirm(null);
  };

  const roleTag = (role) => {
    const isAdmin = role === 'admin';
    return html`
      <span style=${{
        display: 'inline-flex', alignItems: 'center', gap: '5px',
        padding: '3px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: '700',
        backgroundColor: isAdmin ? 'rgba(124,77,255,0.13)' : 'rgba(59,130,246,0.12)',
        color: isAdmin ? '#a78bfa' : '#60a5fa',
        border: `1px solid ${isAdmin ? 'rgba(124,77,255,0.28)' : 'rgba(59,130,246,0.25)'}`,
      }}>
        ${isAdmin ? '👑' : '👤'} ${isAdmin ? 'Admin' : 'User'}
      </span>
    `;
  };

  const envBadge = () => html`
    <span style=${{
      display: 'inline-flex', alignItems: 'center', gap: '4px',
      padding: '2px 8px', borderRadius: '20px', fontSize: '11px', fontWeight: '600',
      backgroundColor: 'rgba(16,185,129,0.1)', color: '#34d399',
      border: '1px solid rgba(16,185,129,0.25)',
    }}>
      🔒 .env
    </span>
  `;

  return html`
    <div style=${{ maxWidth: '960px', margin: '0 auto' }}>

      <!-- Page Title -->
      <div style=${{ marginBottom: '24px' }}>
        <h2 style=${{ margin: '0 0 4px 0', fontSize: '22px', fontWeight: '800', color: theme.text }}>
          👥 User Management
        </h2>
        <p style=${{ margin: 0, fontSize: '13px', color: theme.muted }}>
          Add, edit, or remove users. <strong style=${{ color: '#34d399' }}>🔒 .env</strong> accounts are controlled from the <code style=${{ fontSize: '12px', padding: '1px 5px', backgroundColor: theme.badgeBg, borderRadius: '4px' }}>.env</code> file. Only Admins can access this page.
        </p>
      </div>

      <!-- Toolbar -->
      <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px', gap: '12px', flexWrap: 'wrap' }}>
        <div style=${{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: theme.input, border: `1px solid ${theme.borderS}`, borderRadius: '8px', padding: '0 12px', height: '38px', flex: '1', maxWidth: '320px' }}>
          <span style=${{ fontSize: '14px', color: theme.muted }}>🔍</span>
          <input
            type="text"
            placeholder="Search users…"
            value=${searchQ}
            onInput=${(e) => setSearchQ(e.target.value)}
            style=${{ border: 'none', background: 'transparent', color: theme.inputC, fontSize: '13px', outline: 'none', flex: 1 }}
          />
        </div>

        <button
          onClick=${openAdd}
          style=${{
            height: '38px', padding: '0 18px', borderRadius: '8px',
            backgroundColor: '#0062ff', color: '#fff', border: 'none',
            fontWeight: '700', fontSize: '13px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: '8px',
            boxShadow: '0 4px 12px rgba(0,98,255,0.3)',
          }}
        >
          ＋ Add User
        </button>
      </div>

      <!-- Add / Edit Modal -->
      ${showForm && html`
        <div style=${{
          position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 1000, padding: '20px',
        }}>
          <div style=${{
            backgroundColor: theme.panel, borderRadius: '16px',
            border: `1px solid ${theme.borderS}`, padding: '32px',
            width: '100%', maxWidth: '420px',
            boxShadow: '0 24px 60px rgba(0,0,0,0.5)',
          }}>
            <h3 style=${{ margin: '0 0 22px 0', fontSize: '18px', fontWeight: '800', color: theme.text }}>
              ${editId ? '✏️ Edit User' : '➕ Add New User'}
            </h3>

            ${formError && html`
              <div style=${{
                backgroundColor: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)',
                color: '#f87171', padding: '10px 14px', borderRadius: '8px',
                fontSize: '13px', marginBottom: '16px',
              }}>⚠️ ${formError}</div>
            `}

            <div style=${{ marginBottom: '14px' }}>
              <label style=${labelStyle}>Full Name</label>
              <input type="text" placeholder="e.g. John Smith" value=${form.name}
                onInput=${(e) => handleFormChange('name', e.target.value)} style=${inputStyle} />
            </div>

            <div style=${{ marginBottom: '14px' }}>
              <label style=${labelStyle}>Username / User ID</label>
              <input type="text" placeholder="e.g. jsmith01" value=${form.username}
                onInput=${(e) => handleFormChange('username', e.target.value)} style=${inputStyle} />
            </div>

            <div style=${{ marginBottom: '14px' }}>
              <label style=${labelStyle}>Password</label>
              <input type="text" placeholder="Min 6 characters" value=${form.password}
                onInput=${(e) => handleFormChange('password', e.target.value)} style=${inputStyle} />
            </div>

            <div style=${{ marginBottom: '22px' }}>
              <label style=${labelStyle}>Role</label>
              <select value=${form.role} onChange=${(e) => handleFormChange('role', e.target.value)}
                style=${{ ...inputStyle, cursor: 'pointer' }}>
                <option value="user">👤 User (View Only)</option>
                <option value="admin">👑 Admin (Full Access)</option>
              </select>
            </div>

            <div style=${{ display: 'flex', gap: '10px' }}>
              <button onClick=${handleSave} style=${{
                flex: 1, height: '42px', backgroundColor: '#0062ff',
                color: '#fff', border: 'none', borderRadius: '8px',
                fontWeight: '700', fontSize: '14px', cursor: 'pointer',
              }}>
                ${editId ? 'Save Changes' : 'Create User'}
              </button>
              <button onClick=${() => { setShowForm(false); setFormError(''); }} style=${{
                flex: 1, height: '42px', backgroundColor: theme.badgeBg,
                color: theme.text, border: `1px solid ${theme.borderS}`,
                borderRadius: '8px', fontWeight: '600', fontSize: '14px', cursor: 'pointer',
              }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      `}

      <!-- Delete Confirm Modal -->
      ${deleteConfirm !== null && html`
        <div style=${{
          position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 1000, padding: '20px',
        }}>
          <div style=${{
            backgroundColor: theme.panel, borderRadius: '14px',
            border: '1px solid rgba(239,68,68,0.3)', padding: '28px',
            width: '100%', maxWidth: '360px',
            boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
          }}>
            <div style=${{ fontSize: '32px', textAlign: 'center', marginBottom: '12px' }}>⚠️</div>
            <h3 style=${{ margin: '0 0 8px 0', fontSize: '17px', fontWeight: '800', color: theme.text, textAlign: 'center' }}>
              Delete User?
            </h3>
            <p style=${{ margin: '0 0 22px 0', fontSize: '13px', color: theme.muted, textAlign: 'center' }}>
              This action cannot be undone.
            </p>
            <div style=${{ display: 'flex', gap: '10px' }}>
              <button onClick=${() => handleDelete(deleteConfirm)} style=${{
                flex: 1, height: '40px', backgroundColor: 'rgba(239,68,68,0.15)',
                color: '#f87171', border: '1px solid rgba(239,68,68,0.3)',
                borderRadius: '8px', fontWeight: '700', fontSize: '13px', cursor: 'pointer',
              }}>
                🗑️ Delete
              </button>
              <button onClick=${() => setDeleteConfirm(null)} style=${{
                flex: 1, height: '40px', backgroundColor: theme.badgeBg,
                color: theme.text, border: `1px solid ${theme.borderS}`,
                borderRadius: '8px', fontWeight: '600', fontSize: '13px', cursor: 'pointer',
              }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      `}

      <!-- Users Table -->
      <div style=${{
        backgroundColor: theme.panel, borderRadius: '12px',
        border: `1px solid ${theme.border}`, overflow: 'hidden',
        boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
      }}>
        <div style=${{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '16px 20px', borderBottom: `1px solid ${theme.border}`,
        }}>
          <span style=${{ fontSize: '13px', fontWeight: '700', color: theme.text }}>
            Total Users: ${filtered.length}
          </span>
          <span style=${{ fontSize: '12px', color: theme.muted }}>
            ${allUsers.filter(u => u.role === 'admin').length} Admin · ${allUsers.filter(u => u.role === 'user').length} User
          </span>
        </div>

        ${envLoading ? html`
          <div style=${{ padding: '40px', textAlign: 'center', color: theme.muted, fontSize: '14px' }}>
            ⏳ Loading accounts…
          </div>
        ` : html`
          <div style=${{ overflowX: 'auto' }}>
            <table style=${{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style=${{ backgroundColor: theme.tableHdr }}>
                  ${['#', 'Name', 'Username', 'Password', 'Role', 'Source', 'Actions'].map(h => html`
                    <th style=${{ padding: '12px 16px', textAlign: h === 'Actions' ? 'center' : 'left', fontSize: '11px', fontWeight: '700', color: theme.muted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      ${h}
                    </th>
                  `)}
                </tr>
              </thead>
              <tbody>
                ${filtered.length === 0 ? html`
                  <tr>
                    <td colspan="7" style=${{ padding: '40px', textAlign: 'center', color: theme.muted, fontSize: '14px' }}>
                      No users found.
                    </td>
                  </tr>
                ` : filtered.map((user, idx) => html`
                  <tr key=${user.id}
                    style=${{ borderTop: `1px solid ${theme.border}`, transition: 'background-color 0.15s' }}
                    onMouseEnter=${(e) => e.currentTarget.style.backgroundColor = theme.rowHover}
                    onMouseLeave=${(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                  >
                    <td style=${{ padding: '13px 16px', fontSize: '13px', color: theme.muted }}>${idx + 1}</td>
                    <td style=${{ padding: '13px 16px', fontSize: '13px', fontWeight: '600', color: theme.text }}>${user.name}</td>
                    <td style=${{ padding: '13px 16px' }}>
                      <code style=${{ backgroundColor: theme.badgeBg, padding: '3px 8px', borderRadius: '6px', fontSize: '12px', color: '#60a5fa', fontWeight: '600' }}>
                        ${user.username}
                      </code>
                    </td>
                    <td style=${{ padding: '13px 16px' }}>
                      ${user.isEnv
                        ? html`<span style=${{ fontSize: '12px', color: theme.muted, fontStyle: 'italic' }}>Set in .env file</span>`
                        : html`
                          <div style=${{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <code style=${{
                              backgroundColor: theme.badgeBg, padding: '3px 8px', borderRadius: '6px',
                              fontSize: '12px', color: theme.muted, fontWeight: '600',
                              letterSpacing: showPwdFor === user.id ? '0' : '2px',
                              minWidth: '80px', display: 'inline-block',
                            }}>
                              ${showPwdFor === user.id ? user.password : '••••••••'}
                            </code>
                            <button
                              onClick=${() => setShowPwdFor(prev => prev === user.id ? null : user.id)}
                              style=${{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', padding: '2px', lineHeight: 1, color: theme.muted }}
                            >
                              ${showPwdFor === user.id ? '🙈' : '👁️'}
                            </button>
                          </div>
                        `}
                    </td>
                    <td style=${{ padding: '13px 16px' }}>${roleTag(user.role)}</td>
                    <td style=${{ padding: '13px 16px' }}>
                      ${user.isEnv ? envBadge() : html`
                        <span style=${{ fontSize: '12px', color: theme.muted }}>Manual</span>
                      `}
                    </td>
                    <td style=${{ padding: '13px 16px', textAlign: 'center' }}>
                      ${user.isEnv
                        ? html`<span style=${{ fontSize: '12px', color: theme.muted, fontStyle: 'italic' }}>Edit .env to change</span>`
                        : html`
                          <div style=${{ display: 'flex', justifyContent: 'center', gap: '6px' }}>
                            <button onClick=${() => openEdit(user)} style=${{
                              height: '32px', padding: '0 12px', borderRadius: '6px',
                              backgroundColor: 'rgba(0,98,255,0.12)', color: '#60a5fa',
                              border: '1px solid rgba(0,98,255,0.25)',
                              fontSize: '12px', fontWeight: '600', cursor: 'pointer',
                            }}>✏️ Edit</button>
                            <button onClick=${() => setDeleteConfirm(user.id)} style=${{
                              height: '32px', padding: '0 12px', borderRadius: '6px',
                              backgroundColor: 'rgba(239,68,68,0.1)', color: '#f87171',
                              border: '1px solid rgba(239,68,68,0.25)',
                              fontSize: '12px', fontWeight: '600', cursor: 'pointer',
                            }}>🗑️ Delete</button>
                          </div>
                        `}
                    </td>
                  </tr>
                `)}
              </tbody>
            </table>
          </div>
        `}
      </div>

      <!-- Info Note -->
      <div style=${{
        marginTop: '16px', padding: '12px 16px',
        backgroundColor: 'rgba(0,98,255,0.07)',
        border: '1px solid rgba(0,98,255,0.2)',
        borderRadius: '8px', fontSize: '12px', color: theme.muted,
        display: 'flex', alignItems: 'flex-start', gap: '8px',
      }}>
        <span>ℹ️</span>
        <div>
          <strong style=${{ color: theme.text }}>🔒 .env accounts</strong> (admin & user) are defined in the <code style=${{ backgroundColor: theme.badgeBg, padding: '1px 5px', borderRadius: '4px' }}>.env</code> file on the server. To change their username or password, edit <code style=${{ backgroundColor: theme.badgeBg, padding: '1px 5px', borderRadius: '4px' }}>.env</code> and restart the server.
          <br/>
          <strong style=${{ color: theme.text }}>Manual accounts</strong> are stored locally in the browser and can be edited or deleted here.
        </div>
      </div>
    </div>
  `;
}
