import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import html from './html.js';
import { loadConfig } from './config.js';
import { setApiUrl, api } from './api.js?v=6';
import Home from './pages/Home.js?v=6';
import PlaceholderPage from './pages/PlaceholderPage.js';
import FiveGImport from './pages/FiveGImport.js';
import PacketLossReports from './pages/PacketLossReports.js?v=1';
import PacketLoss from './pages/PacketLoss.js?v=1';
import SiteDetail from './pages/SiteDetail.js';
import SiteInfoImport from './pages/SiteInfoImport.js';
import DailyTwampImport from './pages/DailyTwampImport.js';
import LoginPage from './pages/LoginPage.js';
import UserManagement from './pages/UserManagement.js';


function App() {
  const [authUser, setAuthUser] = useState(() => {
    try {
      const saved = localStorage.getItem('twamp_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [activeTab, setActiveTab] = useState('home');
  const [selectedSiteForDetail, setSelectedSiteForDetail] = useState(null);
  const [selectedCircle, setSelectedCircle] = useState('All');
  const [selectedCluster, setSelectedCluster] = useState('All');
  const [clusterOptions, setClusterOptions] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [configReady, setConfigReady] = useState(false);

  const handleLogin = (userObj) => {
    setAuthUser(userObj);
    try {
      localStorage.setItem('twamp_auth_user', JSON.stringify(userObj));
    } catch {}
  };

  const handleLogout = () => {
    setAuthUser(null);
    try {
      localStorage.removeItem('twamp_auth_user');
    } catch {}
  };

  useEffect(() => {
    let active = true;
    loadConfig().then((cfg) => {
      setApiUrl(cfg.API_URL);
      if (active) setConfigReady(true);
    }).catch(() => {
      if (active) setConfigReady(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!configReady || !authUser) return;
    let active = true;
    api.getDashboardClusters(selectedCircle)
      .then((clusters) => {
        if (active && Array.isArray(clusters)) {
          setClusterOptions(clusters);
        }
      })
      .catch((err) => console.error('Failed to load clusters:', err));
    setSelectedCluster('All');
    return () => { active = false; };
  }, [selectedCircle, refreshKey, configReady, authUser]);

  useEffect(() => {
    const root = document.documentElement;
    document.body.classList.toggle('light-mode', !isDarkMode);
    if (isDarkMode) {
      root.style.setProperty('--theme-panel-bg', '#111622');
      root.style.setProperty('--theme-page-bg', '#0c101a');
      root.style.setProperty('--theme-border', 'rgba(255,255,255,0.08)');
      root.style.setProperty('--theme-border-strong', 'rgba(255,255,255,0.12)');
      root.style.setProperty('--theme-text', '#ffffff');
      root.style.setProperty('--theme-text-muted', '#8f9bb3');
      root.style.setProperty('--theme-input-bg', '#1b2234');
      root.style.setProperty('--theme-input-color', '#ffffff');
      root.style.setProperty('--theme-badge-bg', 'rgba(255,255,255,0.05)');
      root.style.setProperty('--theme-table-header-bg', '#0d1117');
      root.style.setProperty('--theme-tag-bg-4g', 'rgba(255,107,53,0.15)');
      root.style.setProperty('--theme-tag-bg-5g', 'rgba(224,64,251,0.15)');
      root.style.setProperty('--theme-tag-bg-voice', 'rgba(0,98,255,0.15)');
    } else {
      root.style.setProperty('--theme-panel-bg', '#ffffff');
      root.style.setProperty('--theme-page-bg', '#f0f4f9');
      root.style.setProperty('--theme-border', 'rgba(0,0,0,0.1)');
      root.style.setProperty('--theme-border-strong', 'rgba(0,0,0,0.15)');
      root.style.setProperty('--theme-text', '#111827');
      root.style.setProperty('--theme-text-muted', '#4b5563');
      root.style.setProperty('--theme-input-bg', '#e8edf5');
      root.style.setProperty('--theme-input-color', '#111827');
      root.style.setProperty('--theme-badge-bg', 'rgba(0,0,0,0.05)');
      root.style.setProperty('--theme-table-header-bg', '#f1f5f9');
      root.style.setProperty('--theme-tag-bg-4g', 'rgba(220,80,20,0.12)');
      root.style.setProperty('--theme-tag-bg-5g', 'rgba(160,40,200,0.12)');
      root.style.setProperty('--theme-tag-bg-voice', 'rgba(0,60,200,0.12)');
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (!configReady || !authUser) return;
    let active = true;
    api.getDashboardSummary({}).then((data) => {
      if (!active || !data || !data.latest_upload_date) return;
      const end = data.latest_upload_date;
      const d = new Date(end);
      d.setDate(d.getDate() - 6);
      const start = d.toISOString().slice(0, 10);
      setEndDate(end);
      setStartDate(start);
    }).catch(() => {});
    return () => { active = false; };
  }, [configReady, authUser]);

  useEffect(() => { setSelectedSiteForDetail(null); }, [activeTab]);

  // If user is not authenticated, render Login Screen
  if (!authUser) {
    return html`<${LoginPage} onLogin=${handleLogin} />`;
  }

  const theme = isDarkMode ? {
    appBg: '#0c101a', sidebarBg: '#111622', headerBg: '#111622',
    border: 'rgba(255,255,255,0.08)', borderStrong: 'rgba(255,255,255,0.12)',
    text: '#fff', textMuted: '#8f9bb3', inputBg: '#1b2234',
    inputColor: '#fff', calIconStroke: '#8f9bb3', mainBg: '#0c101a',
  } : {
    appBg: '#f0f4f9', sidebarBg: '#ffffff', headerBg: '#ffffff',
    border: 'rgba(0,0,0,0.1)', borderStrong: 'rgba(0,0,0,0.15)',
    text: '#111827', textMuted: '#4b5563', inputBg: '#e8edf5',
    inputColor: '#111827', calIconStroke: '#4b5563', mainBg: '#f0f4f9',
  };

  const userRole = authUser.role;

  return html`
    <div className="app-shell" style=${{ display: 'flex', minHeight: '100vh', backgroundColor: theme.appBg, color: theme.text, transition: 'background-color 0.3s, color 0.3s' }}>
      <aside style=${{ width: isSidebarOpen ? '260px' : '0px', minWidth: 0, overflowY: 'auto', overflowX: 'hidden', backgroundColor: theme.sidebarBg, borderRight: isSidebarOpen ? `1px solid ${theme.border}` : 'none', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: isSidebarOpen ? '20px 14px' : '0', flexShrink: 0, position: 'sticky', top: 0, height: '100vh', alignSelf: 'flex-start', transition: 'width 0.3s ease, padding 0.3s ease, background-color 0.3s' }}>
        <div>
          <div style=${{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingLeft: '4px' }}>
            <div style=${{ width: '28px', height: '28px', borderRadius: '6px', backgroundColor: '#0062ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '16px' }}>📊</div>
            <span style=${{ fontSize: '17px', fontWeight: '800', letterSpacing: '0.5px', color: theme.text }}>Analytics</span>
          </div>
          <nav style=${{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            ${[
              { key: 'home', label: 'Dashboard', icon: '🏠' },
              { key: 'daily_twamp', label: 'Daily TWAMP Import', icon: '📤' },
              ...(userRole === 'admin' ? [
                { key: 'five_g', label: 'DB', icon: '📥' },
                { key: 'site_info', label: 'Site Info Import', icon: '📂' },
              ] : []),
              { key: 'packet_loss_reports', label: 'Packet Loss', icon: '📉' },
              { key: 'reports', label: 'Reports', icon: '📄' },
              ...(userRole === 'admin' ? [{ key: 'user_management', label: 'User Management', icon: '👥' }] : []),
            ].map(item => {
              const active = activeTab === item.key;
              return html`
                <a key=${item.key} href="javascript:void(0)" onClick=${() => { setSelectedSiteForDetail(null); setActiveTab(item.key); }}
                  style=${{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 12px', borderRadius: '8px', textDecoration: 'none', color: active ? '#fff' : theme.textMuted, backgroundColor: active ? '#0062ff' : 'transparent', fontWeight: '600', transition: 'all 0.2s ease', fontSize: '13px' }}>
                  <span style=${{ fontSize: '15px' }}>${item.icon}</span>
                  <span>${item.label}</span>
                </a>
              `;
            })}
          </nav>
        </div>
        <div style=${{ borderTop: `1px solid ${theme.border}`, paddingTop: '14px', marginTop: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div>
            <label style=${{ display: 'block', fontSize: '11px', color: theme.textMuted, marginBottom: '4px', fontWeight: '600' }}>Select Circle</label>
            <select value=${selectedCircle} onChange=${(e) => setSelectedCircle(e.target.value)}
              style=${{ width: '100%', backgroundColor: theme.inputBg, color: theme.inputColor, border: `1px solid ${theme.borderStrong}`, borderRadius: '6px', padding: '8px 10px', fontSize: '13px', outline: 'none', cursor: 'pointer' }}>
              <option value="All">All Circles</option>
              <option value="Bihar">Bihar</option>
              <option value="Jharkhand">Jharkhand</option>
            </select>
          </div>
          <div>
            <label style=${{ display: 'block', fontSize: '11px', color: theme.textMuted, marginBottom: '4px', fontWeight: '600' }}>Select Cluster</label>
            <select value=${selectedCluster} onChange=${(e) => setSelectedCluster(e.target.value)}
              style=${{ width: '100%', backgroundColor: theme.inputBg, color: theme.inputColor, border: `1px solid ${theme.borderStrong}`, borderRadius: '6px', padding: '8px 10px', fontSize: '13px', outline: 'none', cursor: 'pointer' }}>
              <option value="All">All Clusters</option>
              ${clusterOptions.map((c) => html`<option key=${c} value=${c}>${c}</option>`)}
            </select>
          </div>
        </div>
      </aside>

      <div style=${{ flex: 1, display: 'flex', flexDirection: 'column', overflowX: 'hidden' }}>
        <header style=${{ height: '70px', borderBottom: `1px solid ${theme.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 32px', backgroundColor: theme.headerBg, flexShrink: 0, transition: 'background-color 0.3s' }}>
          <div style=${{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <button onClick=${() => setIsSidebarOpen(prev => !prev)} style=${{ border: 'none', background: 'transparent', color: theme.text, fontSize: '20px', cursor: 'pointer', lineHeight: 1 }}>☰</button>
            <h1 style=${{ margin: 0, fontSize: '22px', fontWeight: '800', fontStyle: 'italic', color: '#0062ff', letterSpacing: '0.5px' }}>Daily TWAMP Analytics</h1>
          </div>
          <div style=${{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <!-- User Profile & Role Tag -->
            <div style=${{ display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 12px', borderRadius: '6px', backgroundColor: userRole === 'admin' ? 'rgba(124, 77, 255, 0.15)' : 'rgba(59, 130, 246, 0.15)', border: `1px solid ${userRole === 'admin' ? 'rgba(124, 77, 255, 0.3)' : 'rgba(59, 130, 246, 0.3)'}`, color: userRole === 'admin' ? '#a78bfa' : '#60a5fa', fontSize: '13px', fontWeight: '600' }}>
              <span>${userRole === 'admin' ? '👑' : '👤'}</span>
              <span>${authUser.name} (${authUser.username})</span>
            </div>

            <!-- Date Range Selector -->
            <div style=${{ display: 'flex', alignItems: 'center', backgroundColor: theme.inputBg, border: `1px solid ${theme.borderStrong}`, borderRadius: '6px', padding: '6px 12px', gap: '8px', transition: 'background-color 0.3s' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke=${theme.calIconStroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style=${{ flexShrink: 0 }}>
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              <input type="date" value=${startDate} onChange=${(e) => setStartDate(e.target.value)}
                style=${{ border: 'none', background: 'transparent', color: theme.inputColor, fontSize: '13px', outline: 'none', cursor: 'pointer', colorScheme: isDarkMode ? 'dark' : 'light' }} />
              <span style=${{ color: theme.textMuted, fontSize: '13px' }}>-</span>
              <input type="date" value=${endDate} onChange=${(e) => setEndDate(e.target.value)}
                style=${{ border: 'none', background: 'transparent', color: theme.inputColor, fontSize: '13px', outline: 'none', cursor: 'pointer', colorScheme: isDarkMode ? 'dark' : 'light' }} />
            </div>

            <!-- Dark Mode Toggle -->
            <button onClick=${() => setIsDarkMode(prev => !prev)} title=${isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              style=${{ width: '36px', height: '36px', borderRadius: '6px', backgroundColor: isDarkMode ? '#1b2234' : '#e8edf5', color: isDarkMode ? '#ffd60a' : '#334155', border: `1px solid ${isDarkMode ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.15)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '16px', transition: 'all 0.2s' }}>
              ${isDarkMode ? '☀️' : '🌙'}
            </button>

            <!-- Refresh Button -->
            <button onClick=${() => setRefreshKey(prev => prev + 1)} title="Refresh Data"
              style=${{ width: '36px', height: '36px', borderRadius: '6px', backgroundColor: '#0062ff', color: '#fff', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold', transition: 'background-color 0.2s' }}>
              🔄
            </button>

            <!-- Logout Button -->
            <button onClick=${handleLogout} title="Log Out"
              style=${{ height: '36px', padding: '0 12px', borderRadius: '6px', backgroundColor: 'rgba(239, 68, 68, 0.15)', color: '#f87171', border: '1px solid rgba(239, 68, 68, 0.3)', display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: '600' }}>
              <span>🚪</span>
              <span>Logout</span>
            </button>
          </div>
        </header>

        <main style=${{ flex: 1, padding: '32px', overflowY: 'auto', backgroundColor: theme.mainBg, transition: 'background-color 0.3s' }}>
          ${selectedSiteForDetail && html`
            <${SiteDetail} siteName=${selectedSiteForDetail.siteName} siteId=${selectedSiteForDetail.siteId}
              initialFilters=${selectedSiteForDetail.filters} initialSearch=${selectedSiteForDetail.search}
              onBack=${() => setSelectedSiteForDetail(null)} />
          `}
          <div style=${{ display: selectedSiteForDetail ? 'none' : 'block' }}>
            ${activeTab === 'home' && html`<${Home} circle=${selectedCircle} cluster=${selectedCluster} startDate=${startDate} endDate=${endDate} refreshKey=${refreshKey} onSiteClick=${setSelectedSiteForDetail} isDarkMode=${isDarkMode} />`}
            ${activeTab === 'daily_twamp' && html`<${DailyTwampImport} onSiteClick=${setSelectedSiteForDetail} userRole=${userRole} />`}
            ${activeTab === 'five_g' && html`<${FiveGImport} userRole=${userRole} />`}
            ${activeTab === 'site_info' && html`<${SiteInfoImport} userRole=${userRole} />`}
            ${activeTab === 'packet_loss_reports' && html`<${PacketLoss} onSiteClick=${setSelectedSiteForDetail} circle=${selectedCircle} startDate=${startDate} endDate=${endDate} userRole=${userRole} />`}
            ${activeTab === 'reports' && html`<${PacketLossReports} onSiteClick=${setSelectedSiteForDetail} circle=${selectedCircle} startDate=${startDate} endDate=${endDate} userRole=${userRole} />`}
            ${activeTab === 'user_management' && userRole === 'admin' && html`<${UserManagement} isDarkMode=${isDarkMode} />`}
          </div>
        </main>
      </div>
    </div>
  `;
}

const rootElement = document.getElementById('root');
const root = createRoot(rootElement);
root.render(html`<${App} />`);
