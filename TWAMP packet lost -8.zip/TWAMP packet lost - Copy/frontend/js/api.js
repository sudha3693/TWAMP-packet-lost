let apiBaseUrl = '/api/v1';

/**
 * Configure the API base URL.
 * Typically called on startup after config.js parses .env.
 */
export function setApiUrl(url) {
  apiBaseUrl = url;
}

/**
 * Generic fetch wrapper to send JSON and parse response.
 */
async function request(path, options = {}) {
  const url = `${apiBaseUrl}${path}`;
  
  const headers = {
    ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers || {})
  };
  
  const response = await fetch(url, {
    ...options,
    headers
  });
  
  if (response.status === 204) {
    return null;
  }
  
  if (!response.ok) {
    let errorDetail = 'API call failed';
    try {
      const errorJson = await response.json();
      errorDetail = errorJson.detail || errorDetail;
    } catch (_) {}
    throw new Error(errorDetail);
  }
  
  return response.json();
}

/**
 * API client helper methods.
 */
export const api = {
  getItems: (skip = 0, limit = 100) => 
    request(`/items/?skip=${skip}&limit=${limit}`),
    
  getItem: (id) => 
    request(`/items/${id}`),
    
  createItem: (itemData) => 
    request('/items/', {
      method: 'POST',
      body: JSON.stringify(itemData)
    }),
    
  updateItem: (id, itemData) => 
    request(`/items/${id}`, {
      method: 'PUT',
      body: JSON.stringify(itemData)
    }),
    
  deleteItem: (id) => 
    request(`/items/${id}`, {
      method: 'DELETE'
    }),

  uploadFiveGData: (formData) =>
    request('/five-g-data/upload', {
      method: 'POST',
      body: formData
    }),

  getFiveGData: (skip = 0) =>
    request(`/five-g-data/?skip=${skip}`),

  deleteAllFiveGData: () =>
    request('/five-g-data/', {
      method: 'DELETE'
    }),

  deleteFiveGDataItem: (id) =>
    request(`/five-g-data/${id}`, {
      method: 'DELETE'
    }),

  uploadPacketLossData: (formData) =>
    request('/packet-loss/upload', {
      method: 'POST',
      body: formData
    }),

  getPacketLossReports: (skip = 0, limit = 100) =>
    request(`/packet-loss/reports?skip=${skip}&limit=${limit}`),

  getPacketLossReportData: (reportId, search = '', skip = 0, limit = 100, filters = {}) => {
    const normalizedFilters = {
      siteId: (filters.siteId || '').toString().trim(),
      popName: (filters.popName || '').toString().trim(),
      connectionType: (filters.connectionType || '').toString().trim(),
      technology: (filters.technology || '').toString().trim(),
      plCount: (filters.plCount || '').toString().trim(),
      cluster: (filters.cluster || '').toString().trim(),
      district: (filters.district || '').toString().trim()
    };
    const searchParam = search ? `&search=${encodeURIComponent(search)}` : '';
    let filterParams = '';
    if (normalizedFilters.siteId) filterParams += `&site_id=${encodeURIComponent(normalizedFilters.siteId)}`;
    if (normalizedFilters.popName) filterParams += `&pop_name=${encodeURIComponent(normalizedFilters.popName)}`;
    if (normalizedFilters.connectionType) filterParams += `&connection_type=${encodeURIComponent(normalizedFilters.connectionType)}`;
    if (normalizedFilters.technology) filterParams += `&technology=${encodeURIComponent(normalizedFilters.technology)}`;
    if (normalizedFilters.plCount) filterParams += `&pl_count=${encodeURIComponent(normalizedFilters.plCount)}`;
    if (normalizedFilters.cluster) filterParams += `&cluster=${encodeURIComponent(normalizedFilters.cluster)}`;
    if (normalizedFilters.district) filterParams += `&district=${encodeURIComponent(normalizedFilters.district)}`;

    const path = `/packet-loss/reports/${reportId}/data?skip=${skip}&limit=${limit}${searchParam}${filterParams}`;
    console.log('[Packet Loss API] Requesting data', {
      reportId,
      search,
      skip,
      limit,
      filters: normalizedFilters,
      path
    });

    return request(path);
  },

  getPacketLossCircleSummaries: () =>
    request('/packet-loss/circles/summary'),

  getPacketLossCircleHistoryData: (circle, search = '', skip = 0, limit = 100, filters = {}) => {
    const normalizedFilters = {
      siteId: (filters.siteId || '').toString().trim(),
      popName: (filters.popName || '').toString().trim(),
      connectionType: (filters.connectionType || '').toString().trim(),
      technology: (filters.technology || '').toString().trim(),
      plCount: (filters.plCount || '').toString().trim(),
      cluster: (filters.cluster || '').toString().trim(),
      district: (filters.district || '').toString().trim()
    };
    const encodedCircle = encodeURIComponent(circle);
    const searchParam = search ? `&search=${encodeURIComponent(search)}` : '';
    let filterParams = '';
    if (normalizedFilters.siteId) filterParams += `&site_id=${encodeURIComponent(normalizedFilters.siteId)}`;
    if (normalizedFilters.popName) filterParams += `&pop_name=${encodeURIComponent(normalizedFilters.popName)}`;
    if (normalizedFilters.connectionType) filterParams += `&connection_type=${encodeURIComponent(normalizedFilters.connectionType)}`;
    if (normalizedFilters.technology) filterParams += `&technology=${encodeURIComponent(normalizedFilters.technology)}`;
    if (normalizedFilters.plCount) filterParams += `&pl_count=${encodeURIComponent(normalizedFilters.plCount)}`;
    if (normalizedFilters.cluster) filterParams += `&cluster=${encodeURIComponent(normalizedFilters.cluster)}`;
    if (normalizedFilters.district) filterParams += `&district=${encodeURIComponent(normalizedFilters.district)}`;
    const path = `/packet-loss/history?circle=${encodedCircle}&skip=${skip}&limit=${limit}${searchParam}${filterParams}`;
    return request(path);
  },

  getPacketLossCircleFilterOptions: (circle) =>
    request(`/packet-loss/history/${encodeURIComponent(circle)}/filter-options`),

  getPacketLossFilterOptions: (reportId) =>
    request(`/packet-loss/reports/${reportId}/filter-options`),

  deletePacketLossReport: (reportId) =>
    request(`/packet-loss/reports/${reportId}`, {
      method: 'DELETE'
    }),

  deleteAllPacketLossReports: () =>
    request('/packet-loss/reports', {
      method: 'DELETE'
    }),

  getDashboardSummary: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/summary${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardTrend: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/trend${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardTrend7Days: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/trend-7days${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardTrendWow: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    // Always fetch fresh W-o-W values to avoid stale in-memory cache snapshots.
    params.append('_ts', Date.now().toString());
    return request(`/dashboard/trend-wow${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardBackhaul: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/backhaul${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardTechnology: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/technology${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardTopSites: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/top-sites${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardClusters: (circle = '') => {
    const params = new URLSearchParams();
    if (circle && circle !== 'All') params.append('circle', circle);
    return request(`/dashboard/clusters${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardCircleBreakdown: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.append(key, value);
    });
    return request(`/dashboard/circle-breakdown${params.toString() ? `?${params.toString()}` : ''}`);
  },

  getDashboardHistory: (filters = {}, skip = 0, limit = 20) => {
    const params = new URLSearchParams();
    params.append('skip', skip);
    params.append('limit', limit);
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    return request(`/dashboard/history?${params.toString()}`);
  },

  getPacketLossSiteDetail: (siteName = '', siteId = '', startDate = '', endDate = '', popName = '', connectionType = '', technology = '', plCount = '', search = '') => {
    const params = new URLSearchParams();
    if (siteName) params.append('site_name', siteName);
    if (siteId) params.append('site_id', siteId);
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);
    if (popName) params.append('pop_name', popName);
    if (connectionType) params.append('connection_type', connectionType);
    if (technology) params.append('technology', technology);
    if (plCount) params.append('pl_count', plCount);
    if (search) params.append('search', search);
    return request(`/packet-loss/site-detail?${params.toString()}`);
  },

  getPacketLossSiteFilterOptions: (siteName = '', siteId = '') => {
    const params = new URLSearchParams();
    if (siteName) params.append('site_name', siteName);
    if (siteId) params.append('site_id', siteId);
    return request(`/packet-loss/site-detail/filter-options?${params.toString()}`);
  },

  uploadSiteInfo: (formData) =>
    request('/site-info/upload', {
      method: 'POST',
      body: formData
    }),

  getSiteInfo: () =>
    request('/site-info/'),

  deleteSiteInfo: (siteId) =>
    request(`/site-info/${encodeURIComponent(siteId)}`, {
      method: 'DELETE'
    }),

  deleteAllSiteInfo: () =>
    request('/site-info/', {
      method: 'DELETE'
    }),

  uploadDailyTwamp: (formData) =>
    request('/daily-twamp/upload', {
      method: 'POST',
      body: formData
    }),

  getDailyTwampTables: () =>
    request('/daily-twamp/tables'),

  getDailyTwampData: (tableName, search = '', skip = 0, limit = 100) => {
    const searchParam = search ? `&search=${encodeURIComponent(search)}` : '';
    return request(`/daily-twamp/${encodeURIComponent(tableName)}/data?skip=${skip}&limit=${limit}${searchParam}`);
  },

  deleteDailyTwampTable: (tableName) =>
    request(`/daily-twamp/${encodeURIComponent(tableName)}`, {
      method: 'DELETE'
    }),
};

