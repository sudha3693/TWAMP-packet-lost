from fastapi.testclient import TestClient
from src.main import app


client = TestClient(app)


def test_dashboard_summary_endpoint_returns_metrics():
    response = client.get('/api/dashboard/summary')
    assert response.status_code == 200
    payload = response.json()
    assert 'latest_upload_date' in payload
    assert 'total_reports' in payload
    assert 'total_records' in payload
    assert 'voice_count' in payload
    assert 'four_g_count' in payload
    assert 'five_g_count' in payload


def test_dashboard_history_endpoint_supports_filters():
    response = client.get('/api/dashboard/history?limit=5')
    assert response.status_code == 200
    payload = response.json()
    assert 'total' in payload
    assert 'rows' in payload
    assert isinstance(payload['rows'], list)
