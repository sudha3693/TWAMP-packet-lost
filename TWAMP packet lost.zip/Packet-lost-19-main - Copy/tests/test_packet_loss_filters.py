from fastapi.testclient import TestClient
from src.database import SessionLocal
from src.crud.packet_loss import get_packet_loss_data_by_report_id
from src.main import app


client = TestClient(app)


def test_filters_apply_with_and_logic():
    db = SessionLocal()
    try:
        rows = get_packet_loss_data_by_report_id(
            db=db,
            report_id=1,
            pop_name=' JXKLB-01 ',
            connection_type=' ubr ',
            twamp_technology=' 4g_data ',
            pl_count=' 635.00 ',
            skip=0,
            limit=20,
        )
        assert len(rows) >= 1
        assert rows[0].pop_name == 'JXKLB-01'
        assert rows[0].connection_type == 'UBR'
        assert rows[0].twamp_technology == '4G_Data'
        assert rows[0].packet_loss_05_90_percent_count == '635.00'
    finally:
        db.close()


def test_circle_history_endpoint_returns_rows():
    response = client.get('/api/v1/packet-loss/history?circle=BIHAR&skip=0&limit=5')
    assert response.status_code == 200
    payload = response.json()
    assert payload['total'] > 0
    assert len(payload['rows']) > 0
