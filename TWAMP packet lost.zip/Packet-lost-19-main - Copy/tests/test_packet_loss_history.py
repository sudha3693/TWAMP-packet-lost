from src.database import SessionLocal
from src.crud.packet_loss import get_packet_loss_circle_summaries, get_packet_loss_data_by_circle


def test_history_query_returns_rows_for_selected_circle():
    db = SessionLocal()
    try:
        summaries = get_packet_loss_circle_summaries(db=db)
        assert isinstance(summaries, list)
        assert any(summary['circle'] == 'Bihar Circle' for summary in summaries)
        assert any(summary['circle'] == 'Jharkhand Circle' for summary in summaries)

        if not summaries:
            return

        circle = summaries[0]['circle']
        rows = get_packet_loss_data_by_circle(
            db=db,
            circle=circle,
            skip=0,
            limit=10,
        )

        assert isinstance(rows, list)
        if rows:
            assert rows[0].report.circle == circle
    finally:
        db.close()
