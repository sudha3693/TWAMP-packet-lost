import io
import re
import time
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
import openpyxl

from src.database import get_db
from src.schemas import five_g_data as schemas
from src.crud import five_g_data as crud
from src.services.packet_loss_import import (
    is_exfo_packet_loss_report,
    import_exfo_packet_loss_report,
)

router = APIRouter()


def clean_header(val) -> str:
    if val is None:
        return ""
    # Lowercase and keep alphanumeric only for flexible matching
    return "".join(c for c in str(val).strip().lower() if c.isalnum())


@router.post(
    "/upload", 
    response_model=dict, 
    status_code=status.HTTP_201_CREATED
)
async def upload_excel_sheet(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload an Excel file (.xlsx) and parse/upload either the existing 5G site sheet or
    the EXFO 24Hr Packet Loss report, depending on the file contents.
    """
    if not file.filename.endswith(".xlsx"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file format. Only Excel files (.xlsx) are supported."
        )

    started_at = time.perf_counter()
    excel_time = 0.0
    db_time = 0.0
    processing_time = 0.0

    try:
        t_excel = time.perf_counter()
        contents = await file.read()
        wb = openpyxl.load_workbook(io.BytesIO(contents), read_only=True, data_only=True)
        sheet = wb.active
        excel_time += time.perf_counter() - t_excel
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to read Excel file: {str(e)}"
        )

    try:
        if is_exfo_packet_loss_report(sheet):
            try:
                with db.begin():
                    t_db = time.perf_counter()
                    result = import_exfo_packet_loss_report(db=db, sheet=sheet)
                    db_time += time.perf_counter() - t_db
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=str(exc)
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to import EXFO packet loss report: {str(exc)}"
                )

            from src.crud.packet_loss import resolve_vacant_site_ids
            t_db = time.perf_counter()
            resolve_vacant_site_ids(db=db)
            db_time += time.perf_counter() - t_db

            total_time = time.perf_counter() - started_at
            print(
                f"[PERF][5G Data Import] endpoint=/api/v1/five-g-data/upload api_time={total_time:.4f}s "
                f"db_time={db_time:.4f}s excel_time={excel_time:.4f}s processing_time={processing_time:.4f}s total_time={total_time:.4f}s"
            )

            return {
                "message": (
                    f"Successfully imported EXFO packet loss report for "
                    f"{result['report_date']} ({result['circle']})."
                ),
                "report_id": result["report_id"],
                "row_count": result["row_count"],
            }

        # Fallback to legacy 5G data import behavior
        # Read headers from row 1 using iter_rows for read-only safety
        headers_row = next(sheet.iter_rows(min_row=1, max_row=1, values_only=True), None)
        if not headers_row:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The uploaded Excel sheet is empty or has no headers."
            )
        headers = list(headers_row)
        
        # Map normalized header values to their column index
        col_mapping = {}
        required_mappings = {
            "siteid": "site_id",
            "twampuniquesiteid": "twamp_unique_site_id",
            "sitename": "twamp_unique_site_id",
            "pop": "pop",
            "fibermwrc": "fiber_mw_rc"
        }
        
        original_titles = {
            "site_id": "site id",
            "twamp_unique_site_id": "TWAMP-Unique-SiteID (or site name)",
            "pop": "pop",
            "fiber_mw_rc": "Fiber/MW(R/C)"
        }

        found_mappings = {}
        for idx, header_val in enumerate(headers):
            cleaned = clean_header(header_val)
            if cleaned in required_mappings:
                mapped_field = required_mappings[cleaned]
                found_mappings[mapped_field] = idx

        # Check if all required columns are found
        missing_fields = [
            original_titles[field] 
            for field in original_titles 
            if field not in found_mappings
        ]
        if missing_fields:
            found_list = [str(h) for h in headers if h is not None]
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Missing required columns in Excel sheet: {', '.join(missing_fields)}. "
                    f"Found headers: {', '.join(found_list)}"
                )
            )

        # Process all rows starting from row 2 using fast iterator
        t_processing = time.perf_counter()
        items_to_create = []
        for row_values in sheet.iter_rows(min_row=2, max_col=len(headers), values_only=True):
            # Skip completely empty rows
            if not row_values or all(val is None or str(val).strip() == "" for val in row_values):
                continue

            site_id_val = row_values[found_mappings["site_id"]]
            twamp_val = row_values[found_mappings["twamp_unique_site_id"]]
            pop_val = row_values[found_mappings["pop"]]
            fiber_val = row_values[found_mappings["fiber_mw_rc"]]

            # Convert values to string, handling None
            site_id = str(site_id_val).strip() if site_id_val is not None else None
            twamp_unique_site_id = str(twamp_val).strip() if twamp_val is not None else None
            pop = str(pop_val).strip() if pop_val is not None else None
            fiber_mw_rc = str(fiber_val).strip() if fiber_val is not None else None

            # Build schema instance
            item = schemas.FiveGDataCreate(
                site_id=site_id,
                twamp_unique_site_id=twamp_unique_site_id,
                pop=pop,
                fiber_mw_rc=fiber_mw_rc
            )
            items_to_create.append(item)
        processing_time += time.perf_counter() - t_processing

        if not items_to_create:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No data rows found in the uploaded Excel sheet."
            )

        # Save to database
        t_db = time.perf_counter()
        created_items = crud.create_five_g_data_batch(db=db, items=items_to_create)
        db_time += time.perf_counter() - t_db

        # Automatically resolve vacant site IDs in packet loss data
        from src.crud.packet_loss import resolve_vacant_site_ids
        t_db = time.perf_counter()
        resolve_vacant_site_ids(db=db)
        db_time += time.perf_counter() - t_db

        total_time = time.perf_counter() - started_at
        print(
            f"[PERF][5G Data Import] endpoint=/api/v1/five-g-data/upload api_time={total_time:.4f}s "
            f"db_time={db_time:.4f}s excel_time={excel_time:.4f}s processing_time={processing_time:.4f}s total_time={total_time:.4f}s"
        )

        return {
            "message": f"Successfully imported {len(created_items)} records.",
            "count": len(created_items)
        }
    finally:
        wb.close()


@router.get("/", response_model=List[schemas.FiveGData])
def read_five_g_data(
    skip: int = 0,
    limit: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """
    Retrieve all imported 5G Site Data items. No limit applied by default.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    result = crud.get_five_g_data_list(db=db, skip=skip, limit=limit)
    db_time = time.perf_counter() - t_db
    total_time = time.perf_counter() - started_at
    print(
        f"[PERF][5G Data Import] endpoint=/api/v1/five-g-data/ api_time={total_time:.4f}s "
        f"db_time={db_time:.4f}s excel_time=0.0000s processing_time=0.0000s total_time={total_time:.4f}s"
    )
    return result


@router.delete("/", status_code=status.HTTP_204_NO_CONTENT)
def clear_all_five_g_data(
    db: Session = Depends(get_db)
):
    """
    Delete all imported 5G Site Data.
    """
    crud.delete_all_five_g_data(db=db)
    return None


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_five_g_data_item(
    item_id: int,
    db: Session = Depends(get_db)
):
    """
    Delete a single 5G Site Data item.
    """
    deleted = crud.delete_five_g_data_item(db=db, item_id=item_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Item not found"
        )
    return None
