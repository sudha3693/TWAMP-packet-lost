
import io
import openpyxl
import time
from datetime import date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session

from src.database import get_db
from src.crud import packet_loss as crud
from src.services.packet_loss_import import (
    is_exfo_packet_loss_report,
    import_exfo_packet_loss_report,
)
from src.services.dashboard import clear_dashboard_cache


router = APIRouter()


def _log_api_timing(page: str, endpoint: str, started_at: float, db_time: float = 0.0, excel_time: float = 0.0, processing_time: float = 0.0) -> None:
    total_time = time.perf_counter() - started_at
    print(
        f"[PERF][{page}] endpoint={endpoint} api_time={total_time:.4f}s "
        f"db_time={db_time:.4f}s excel_time={excel_time:.4f}s processing_time={processing_time:.4f}s total_time={total_time:.4f}s"
    )


def _serialize_packet_loss_rows(rows):
    serialized_rows = []
    for row in rows:
        serialized_rows.append({
            "id": row.id,
            "report_id": row.report_id,
            "report_date": row.report.report_date.isoformat() if row.report else None,
            "circle": row.report.circle if row.report else None,
            "short_name": row.short_name,
            "pop_name": row.pop_name,
            "connection_type": row.connection_type,
            "packet_loss_05_90_percent_count": row.packet_loss_05_90_percent_count,
            "rt_packet_loss_00_percent": row.rt_packet_loss_00_percent,
            "packet_loss_00_count": row.packet_loss_00_count,
            "rt_packet_loss_01_percent": row.rt_packet_loss_01_percent,
            "packet_loss_01_count": row.packet_loss_01_count,
            "rt_packet_loss_02_percent": row.rt_packet_loss_02_percent,
            "packet_loss_02_count": row.packet_loss_02_count,
            "rt_packet_loss_03_percent": row.rt_packet_loss_03_percent,
            "packet_loss_03_count": row.packet_loss_03_count,
            "rt_packet_loss_04_percent": row.rt_packet_loss_04_percent,
            "packet_loss_04_count": row.packet_loss_04_count,
            "rt_packet_loss_05_percent": row.rt_packet_loss_05_percent,
            "packet_loss_05_count": row.packet_loss_05_count,
            "rt_packet_loss_06_percent": row.rt_packet_loss_06_percent,
            "packet_loss_06_count": row.packet_loss_06_count,
            "rt_packet_loss_07_percent": row.rt_packet_loss_07_percent,
            "packet_loss_07_count": row.packet_loss_07_count,
            "rt_packet_loss_08_percent": row.rt_packet_loss_08_percent,
            "packet_loss_08_count": row.packet_loss_08_count,
            "rt_packet_loss_09_percent": row.rt_packet_loss_09_percent,
            "packet_loss_09_count": row.packet_loss_09_count,
            "rt_packet_loss_10_percent": row.rt_packet_loss_10_percent,
            "packet_loss_10_count": row.packet_loss_10_count,
            "rt_packet_loss_11_percent": row.rt_packet_loss_11_percent,
            "packet_loss_11_count": row.packet_loss_11_count,
            "rt_packet_loss_12_percent": row.rt_packet_loss_12_percent,
            "packet_loss_12_count": row.packet_loss_12_count,
            "rt_packet_loss_13_percent": row.rt_packet_loss_13_percent,
            "packet_loss_13_count": row.packet_loss_13_count,
            "rt_packet_loss_14_percent": row.rt_packet_loss_14_percent,
            "packet_loss_14_count": row.packet_loss_14_count,
            "rt_packet_loss_15_percent": row.rt_packet_loss_15_percent,
            "packet_loss_15_count": row.packet_loss_15_count,
            "rt_packet_loss_16_percent": row.rt_packet_loss_16_percent,
            "packet_loss_16_count": row.packet_loss_16_count,
            "rt_packet_loss_17_percent": row.rt_packet_loss_17_percent,
            "packet_loss_17_count": row.packet_loss_17_count,
            "rt_packet_loss_18_percent": row.rt_packet_loss_18_percent,
            "packet_loss_18_count": row.packet_loss_18_count,
            "rt_packet_loss_19_percent": row.rt_packet_loss_19_percent,
            "packet_loss_19_count": row.packet_loss_19_count,
            "rt_packet_loss_20_percent": row.rt_packet_loss_20_percent,
            "packet_loss_20_count": row.packet_loss_20_count,
            "rt_packet_loss_21_percent": row.rt_packet_loss_21_percent,
            "packet_loss_21_count": row.packet_loss_21_count,
            "rt_packet_loss_22_percent": row.rt_packet_loss_22_percent,
            "packet_loss_22_count": row.packet_loss_22_count,
            "rt_packet_loss_23_percent": row.rt_packet_loss_23_percent,
            "packet_loss_23_count": row.packet_loss_23_count,
            "packet_loss_ageing": row.packet_loss_ageing,
            "no_of_hrs_session_having_pl_05_90_count": row.no_of_hrs_session_having_pl_05_90_count,
            "site_name": row.site_name,
            "site_id": row.site_id,
            "site_type": row.site_type,
            "twamp_technology": row.twamp_technology,
            "created_at": row.created_at.isoformat(),
        })
    return serialized_rows


@router.post(
    "/upload",
    status_code=status.HTTP_201_CREATED,
    response_model=dict
)
async def upload_packet_loss_sheet(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload an Excel file (.xlsx) and parse/import the EXFO 24Hr Packet Loss report.
    """
    if not file.filename.endswith(".xlsx"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file format. Only Excel files (.xlsx) are supported."
        )

    started_at = time.perf_counter()
    excel_time = 0.0
    db_time = 0.0

    try:
        t_excel = time.perf_counter()
        contents = await file.read()
        wb = openpyxl.load_workbook(io.BytesIO(contents), read_only=True, data_only=True)
        sheet = wb.active
        excel_time += time.perf_counter() - t_excel
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to read Excel file: {str(e)}"
        )

    try:
        if not is_exfo_packet_loss_report(sheet):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The uploaded sheet does not match the EXFO packet loss report format (missing 'Short name' header or metadata)."
            )

        with db.begin():
            t_db = time.perf_counter()
            result = import_exfo_packet_loss_report(db=db, sheet=sheet)
            db_time += time.perf_counter() - t_db
            
        t_db = time.perf_counter()
        crud.resolve_vacant_site_ids(db=db)
        db_time += time.perf_counter() - t_db
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc)
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to import EXFO packet loss report: {str(exc)}"
        )
    finally:
        wb.close()

    _log_api_timing('Packet Loss', '/api/v1/packet-loss/upload', started_at, db_time=db_time, excel_time=excel_time)

    # Invalidate the dashboard cache so new data appears immediately
    clear_dashboard_cache()

    return {
        "message": f"Successfully imported EXFO packet loss report for {result['report_date']} ({result['circle']}).",
        "report_id": result["report_id"],
        "row_count": result["row_count"],
    }


@router.get("/circles/summary", response_model=List[dict])
def get_circle_summaries(
    db: Session = Depends(get_db)
):
    """
    Retrieve aggregate summary cards for the supported circles.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    result = crud.get_packet_loss_circle_summaries(db=db)
    db_time = time.perf_counter() - t_db
    _log_api_timing('Reports', '/api/v1/packet-loss/circles/summary', started_at, db_time=db_time)
    return result


@router.get("/history", response_model=dict)
def get_circle_history_data_by_query(
    circle: str,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Retrieve packet loss data across all uploaded reports for a selected circle.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    total = crud.get_packet_loss_data_count_by_circle(
        db=db,
        circle=circle,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=technology,
        pl_count=pl_count,
    )
    rows = crud.get_packet_loss_data_by_circle(
        db=db,
        circle=circle,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=technology,
        pl_count=pl_count,
        skip=skip,
        limit=limit,
    )
    db_time = time.perf_counter() - t_db

    t_processing = time.perf_counter()
    serialized = _serialize_packet_loss_rows(rows)
    processing_time = time.perf_counter() - t_processing

    _log_api_timing('Reports', '/api/v1/packet-loss/history', started_at, db_time=db_time, processing_time=processing_time)

    return {
        "total": total,
        "rows": serialized,
    }


@router.get("/history/{circle}/data", response_model=dict)
def get_circle_history_data(
    circle: str,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Retrieve packet loss data across all uploaded reports for a selected circle.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    total = crud.get_packet_loss_data_count_by_circle(
        db=db,
        circle=circle,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=technology,
        pl_count=pl_count,
    )
    rows = crud.get_packet_loss_data_by_circle(
        db=db,
        circle=circle,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=technology,
        pl_count=pl_count,
        skip=skip,
        limit=limit,
    )
    db_time = time.perf_counter() - t_db

    t_processing = time.perf_counter()
    serialized = _serialize_packet_loss_rows(rows)
    processing_time = time.perf_counter() - t_processing

    _log_api_timing('Reports', '/api/v1/packet-loss/history/{circle}/data', started_at, db_time=db_time, processing_time=processing_time)

    return {
        "total": total,
        "rows": serialized,
    }


@router.get("/history/{circle}/filter-options", response_model=dict)
def get_circle_filter_options(
    circle: str,
    db: Session = Depends(get_db)
):
    """
    Retrieve distinct filter options across all historical uploads for a circle.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    result = crud.get_circle_filter_options(db=db, circle=circle)
    db_time = time.perf_counter() - t_db
    _log_api_timing('Reports', '/api/v1/packet-loss/history/{circle}/filter-options', started_at, db_time=db_time)
    return result


@router.get("/reports", response_model=List[dict])
def get_reports(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Retrieve all uploaded packet loss reports.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    reports = crud.get_packet_loss_reports(db=db, skip=skip, limit=limit)
    result = []
    for r in reports:
        row_count = crud.get_packet_loss_data_count_by_report_id(db=db, report_id=r.id)
        result.append({
            "id": r.id,
            "report_date": r.report_date.isoformat(),
            "circle": r.circle,
            "uploaded_at": r.uploaded_at.isoformat(),
            "row_count": row_count
        })
    db_time = time.perf_counter() - t_db
    _log_api_timing('Packet Loss/Reports', '/api/v1/packet-loss/reports', started_at, db_time=db_time)
    return result


@router.get("/reports/{report_id}/data", response_model=dict)
def get_report_data(
    report_id: int,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Retrieve paginated packet loss data rows for a specific report, with optional search and filters.
    """
    started_at = time.perf_counter()
    print('[packet_loss_router] received query params', {
        'report_id': report_id,
        'search': search,
        'site_id': site_id,
        'pop_name': pop_name,
        'connection_type': connection_type,
        'technology': technology,
        'pl_count': pl_count,
        'skip': skip,
        'limit': limit,
    })

    t_db = time.perf_counter()
    total = crud.get_packet_loss_data_count_by_report_id(
        db=db, report_id=report_id, search=search, site_id=site_id,
        pop_name=pop_name, connection_type=connection_type,
        twamp_technology=technology, pl_count=pl_count
    )
    rows = crud.get_packet_loss_data_by_report_id(
        db=db, report_id=report_id, search=search, site_id=site_id,
        pop_name=pop_name, connection_type=connection_type,
        twamp_technology=technology, pl_count=pl_count, skip=skip, limit=limit
    )
    db_time = time.perf_counter() - t_db
    print('[packet_loss_router] rows returned', len(rows), 'total', total)
    
    # Map row fields for response serialization
    t_processing = time.perf_counter()
    serialized_rows = []
    for row in rows:
        serialized_rows.append({
            "id": row.id,
            "report_id": row.report_id,
            "short_name": row.short_name,
            "pop_name": row.pop_name,
            "connection_type": row.connection_type,
            "packet_loss_05_90_percent_count": row.packet_loss_05_90_percent_count,
            "rt_packet_loss_00_percent": row.rt_packet_loss_00_percent,
            "packet_loss_00_count": row.packet_loss_00_count,
            "rt_packet_loss_01_percent": row.rt_packet_loss_01_percent,
            "packet_loss_01_count": row.packet_loss_01_count,
            "rt_packet_loss_02_percent": row.rt_packet_loss_02_percent,
            "packet_loss_02_count": row.packet_loss_02_count,
            "rt_packet_loss_03_percent": row.rt_packet_loss_03_percent,
            "packet_loss_03_count": row.packet_loss_03_count,
            "rt_packet_loss_04_percent": row.rt_packet_loss_04_percent,
            "packet_loss_04_count": row.packet_loss_04_count,
            "rt_packet_loss_05_percent": row.rt_packet_loss_05_percent,
            "packet_loss_05_count": row.packet_loss_05_count,
            "rt_packet_loss_06_percent": row.rt_packet_loss_06_percent,
            "packet_loss_06_count": row.packet_loss_06_count,
            "rt_packet_loss_07_percent": row.rt_packet_loss_07_percent,
            "packet_loss_07_count": row.packet_loss_07_count,
            "rt_packet_loss_08_percent": row.rt_packet_loss_08_percent,
            "packet_loss_08_count": row.packet_loss_08_count,
            "rt_packet_loss_09_percent": row.rt_packet_loss_09_percent,
            "packet_loss_09_count": row.packet_loss_09_count,
            "rt_packet_loss_10_percent": row.rt_packet_loss_10_percent,
            "packet_loss_10_count": row.packet_loss_10_count,
            "rt_packet_loss_11_percent": row.rt_packet_loss_11_percent,
            "packet_loss_11_count": row.packet_loss_11_count,
            "rt_packet_loss_12_percent": row.rt_packet_loss_12_percent,
            "packet_loss_12_count": row.packet_loss_12_count,
            "rt_packet_loss_13_percent": row.rt_packet_loss_13_percent,
            "packet_loss_13_count": row.packet_loss_13_count,
            "rt_packet_loss_14_percent": row.rt_packet_loss_14_percent,
            "packet_loss_14_count": row.packet_loss_14_count,
            "rt_packet_loss_15_percent": row.rt_packet_loss_15_percent,
            "packet_loss_15_count": row.packet_loss_15_count,
            "rt_packet_loss_16_percent": row.rt_packet_loss_16_percent,
            "packet_loss_16_count": row.packet_loss_16_count,
            "rt_packet_loss_17_percent": row.rt_packet_loss_17_percent,
            "packet_loss_17_count": row.packet_loss_17_count,
            "rt_packet_loss_18_percent": row.rt_packet_loss_18_percent,
            "packet_loss_18_count": row.packet_loss_18_count,
            "rt_packet_loss_19_percent": row.rt_packet_loss_19_percent,
            "packet_loss_19_count": row.packet_loss_19_count,
            "rt_packet_loss_20_percent": row.rt_packet_loss_20_percent,
            "packet_loss_20_count": row.packet_loss_20_count,
            "rt_packet_loss_21_percent": row.rt_packet_loss_21_percent,
            "packet_loss_21_count": row.packet_loss_21_count,
            "rt_packet_loss_22_percent": row.rt_packet_loss_22_percent,
            "packet_loss_22_count": row.packet_loss_22_count,
            "rt_packet_loss_23_percent": row.rt_packet_loss_23_percent,
            "packet_loss_23_count": row.packet_loss_23_count,
            "packet_loss_ageing": row.packet_loss_ageing,
            "no_of_hrs_session_having_pl_05_90_count": row.no_of_hrs_session_having_pl_05_90_count,
            "site_name": row.site_name,
            "site_id": row.site_id,
            "site_type": row.site_type,
            "twamp_technology": row.twamp_technology,
            "created_at": row.created_at.isoformat()
        })
    processing_time = time.perf_counter() - t_processing

    _log_api_timing('Packet Loss', '/api/v1/packet-loss/reports/{report_id}/data', started_at, db_time=db_time, processing_time=processing_time)

    return {
        "total": total,
        "rows": serialized_rows
    }


@router.get("/reports/{report_id}/filter-options", response_model=dict)
def get_report_filter_options(
    report_id: int,
    db: Session = Depends(get_db)
):
    """
    Retrieve distinct filter options (POP Name, Connection Type, Technology, PL Count) for a report.
    """
    started_at = time.perf_counter()
    t_db = time.perf_counter()
    result = crud.get_filter_options(db=db, report_id=report_id)
    db_time = time.perf_counter() - t_db
    _log_api_timing('Packet Loss', '/api/v1/packet-loss/reports/{report_id}/filter-options', started_at, db_time=db_time)
    return result


@router.delete("/reports/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_report(
    report_id: int,
    db: Session = Depends(get_db)
):
    """
    Delete a specific packet loss report.
    """
    deleted = crud.delete_report_by_id(db=db, report_id=report_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    return None


@router.delete("/reports", status_code=status.HTTP_204_NO_CONTENT)
def delete_all_reports(
    db: Session = Depends(get_db)
):
    """
    Delete all packet loss reports.
    """
    crud.delete_all_reports(db=db)
    return None


@router.get("/site-detail", response_model=List[dict])
def get_site_detail(
    site_name: Optional[str] = None,
    site_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Retrieve daily packet loss history for a specific site, showing all 24 hours of RT and Count metrics.
    """
    parsed_start = None
    parsed_end = None
    if start_date:
        try:
            parsed_start = date.fromisoformat(start_date)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD.")
    if end_date:
        try:
            parsed_end = date.fromisoformat(end_date)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD.")

    rows = crud.get_site_daily_detail(
        db=db,
        site_name=site_name,
        site_id=site_id,
        start_date=parsed_start,
        end_date=parsed_end,
        pop_name=pop_name,
        connection_type=connection_type,
        twamp_technology=technology,
        pl_count=pl_count,
        search=search,
    )
    
    result = []
    for row in rows:
        row_dict = {
            "id": row.id,
            "report_date": row.report.report_date.isoformat() if row.report else None,
            "circle": row.report.circle if row.report else None,
            "site_name": row.site_name,
            "site_id": row.site_id,
            "short_name": row.short_name,
            "pop_name": row.pop_name,
            "connection_type": row.connection_type,
            "twamp_technology": row.twamp_technology,
        }
        for hour in range(24):
            h_str = f"{hour:02d}"
            row_dict[f"rt_packet_loss_{h_str}_percent"] = getattr(row, f"rt_packet_loss_{h_str}_percent")
            row_dict[f"packet_loss_{h_str}_count"] = getattr(row, f"packet_loss_{h_str}_count")
        result.append(row_dict)
        
    return result


@router.get("/site-detail/filter-options", response_model=dict)
def get_site_detail_filter_options(
    site_name: Optional[str] = None,
    site_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Retrieve unique values for pop_name, connection_type, twamp_technology, and pl_count for a site.
    """
    return crud.get_site_filter_options(
        db=db,
        site_name=site_name,
        site_id=site_id
    )

