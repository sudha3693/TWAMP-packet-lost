from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from src.database import get_db
from src.schemas import item as item_schema
from src.crud import item as item_crud

router = APIRouter()


@router.post(
    "/", 
    response_model=item_schema.Item, 
    status_code=status.HTTP_201_CREATED
)
def create_item(
    item: item_schema.ItemCreate, 
    db: Session = Depends(get_db)
):
    """
    Create a new item in the database.
    """
    return item_crud.create_item(db=db, item=item)


@router.get("/", response_model=List[item_schema.Item])
def read_items(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db)
):
    """
    Retrieve list of items.
    """
    return item_crud.get_items(db=db, skip=skip, limit=limit)


@router.get("/{item_id}", response_model=item_schema.Item)
def read_item(
    item_id: int, 
    db: Session = Depends(get_db)
):
    """
    Get a specific item by ID.
    """
    db_item = item_crud.get_item(db=db, item_id=item_id)
    if db_item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Item not found"
        )
    return db_item


@router.put("/{item_id}", response_model=item_schema.Item)
def update_item(
    item_id: int, 
    item_update: item_schema.ItemUpdate, 
    db: Session = Depends(get_db)
):
    """
    Update fields of an item.
    """
    db_item = item_crud.get_item(db=db, item_id=item_id)
    if db_item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Item not found"
        )
    return item_crud.update_item(db=db, db_item=db_item, item_update=item_update)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_item(
    item_id: int, 
    db: Session = Depends(get_db)
):
    """
    Delete an item.
    """
    db_item = item_crud.get_item(db=db, item_id=item_id)
    if db_item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Item not found"
        )
    item_crud.delete_item(db=db, db_item=db_item)
    return None
