from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class FiveGDataBase(BaseModel):
    """
    Base properties shared across 5G Site Data schemas.
    """
    site_id: Optional[str] = Field(None, max_length=100, description="The Site ID")
    twamp_unique_site_id: Optional[str] = Field(None, max_length=100, description="The TWAMP Unique Site ID")
    pop: Optional[str] = Field(None, max_length=100, description="The POP")
    fiber_mw_rc: Optional[str] = Field(None, max_length=50, description="Fiber or MW (R/C)")


class FiveGDataCreate(FiveGDataBase):
    """
    Properties required to create 5G Site Data.
    """
    pass


class FiveGData(FiveGDataBase):
    """
    Response model for 5G Site Data, including database-generated ID.
    """
    id: int

    # Configures Pydantic to automatically read from SQLAlchemy ORM models
    model_config = ConfigDict(from_attributes=True)
