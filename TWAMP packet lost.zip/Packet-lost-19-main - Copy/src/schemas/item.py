from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class ItemBase(BaseModel):
    """
    Base properties shared across Item schemas.
    """
    title: str = Field(..., max_length=100, description="The title of the item")
    description: Optional[str] = Field(None, description="The description of the item")


class ItemCreate(ItemBase):
    """
    Properties required to create an Item.
    """
    pass


class ItemUpdate(BaseModel):
    """
    Properties permitted when updating an Item. All fields are optional.
    """
    title: Optional[str] = Field(None, max_length=100, description="The title of the item")
    description: Optional[str] = Field(None, description="The description of the item")


class Item(ItemBase):
    """
    Response model for an Item, including database-generated fields.
    """
    id: int

    # Configures Pydantic to automatically read from SQLAlchemy ORM models
    model_config = ConfigDict(from_attributes=True)
