from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class PacketLossDataBase(BaseModel):
    short_name: Optional[str] = Field(None, description="Short name from the packet loss report")
    pop_name: Optional[str] = Field(None, description="POP Name from the packet loss report")
    connection_type: Optional[str] = Field(None, description="CONNECTION_TYPE from the packet loss report")
    packet_loss_05_90_percent_count: Optional[str] = Field(None, description="Packet Loss >=0.5 & <90 percent Count")

    rt_packet_loss_00_percent: Optional[str] = None
    packet_loss_00_count: Optional[str] = None
    rt_packet_loss_01_percent: Optional[str] = None
    packet_loss_01_count: Optional[str] = None
    rt_packet_loss_02_percent: Optional[str] = None
    packet_loss_02_count: Optional[str] = None
    rt_packet_loss_03_percent: Optional[str] = None
    packet_loss_03_count: Optional[str] = None
    rt_packet_loss_04_percent: Optional[str] = None
    packet_loss_04_count: Optional[str] = None
    rt_packet_loss_05_percent: Optional[str] = None
    packet_loss_05_count: Optional[str] = None
    rt_packet_loss_06_percent: Optional[str] = None
    packet_loss_06_count: Optional[str] = None
    rt_packet_loss_07_percent: Optional[str] = None
    packet_loss_07_count: Optional[str] = None
    rt_packet_loss_08_percent: Optional[str] = None
    packet_loss_08_count: Optional[str] = None
    rt_packet_loss_09_percent: Optional[str] = None
    packet_loss_09_count: Optional[str] = None
    rt_packet_loss_10_percent: Optional[str] = None
    packet_loss_10_count: Optional[str] = None
    rt_packet_loss_11_percent: Optional[str] = None
    packet_loss_11_count: Optional[str] = None
    rt_packet_loss_12_percent: Optional[str] = None
    packet_loss_12_count: Optional[str] = None
    rt_packet_loss_13_percent: Optional[str] = None
    packet_loss_13_count: Optional[str] = None
    rt_packet_loss_14_percent: Optional[str] = None
    packet_loss_14_count: Optional[str] = None
    rt_packet_loss_15_percent: Optional[str] = None
    packet_loss_15_count: Optional[str] = None
    rt_packet_loss_16_percent: Optional[str] = None
    packet_loss_16_count: Optional[str] = None
    rt_packet_loss_17_percent: Optional[str] = None
    packet_loss_17_count: Optional[str] = None
    rt_packet_loss_18_percent: Optional[str] = None
    packet_loss_18_count: Optional[str] = None
    rt_packet_loss_19_percent: Optional[str] = None
    packet_loss_19_count: Optional[str] = None
    rt_packet_loss_20_percent: Optional[str] = None
    packet_loss_20_count: Optional[str] = None
    rt_packet_loss_21_percent: Optional[str] = None
    packet_loss_21_count: Optional[str] = None
    rt_packet_loss_22_percent: Optional[str] = None
    packet_loss_22_count: Optional[str] = None
    rt_packet_loss_23_percent: Optional[str] = None
    packet_loss_23_count: Optional[str] = None

    packet_loss_ageing: Optional[str] = Field(None, description="Packet Loss_Ageing")
    no_of_hrs_session_having_pl_05_90_count: Optional[str] = Field(None, description="No of hrs Session having PL >=0.5 & <90 count")
    site_name: Optional[str] = Field(None, description="SITE_NAME")
    site_id: Optional[str] = Field(None, description="Site ID resolved from 5G data")
    site_type: Optional[str] = Field(None, description="Site Type")
    twamp_technology: Optional[str] = Field(None, description="Twamp Technology")


class PacketLossDataCreate(PacketLossDataBase):
    pass


class PacketLossData(PacketLossDataBase):
    id: int
    report_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PacketLossReport(BaseModel):
    id: int
    report_date: date
    circle: str
    uploaded_at: datetime

    model_config = ConfigDict(from_attributes=True)
