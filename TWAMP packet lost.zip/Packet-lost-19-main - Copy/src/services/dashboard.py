import math
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional
import time
from functools import wraps
import json

from sqlalchemy import Float, and_, cast, func, literal, or_
from sqlalchemy.orm import Session, joinedload

from src.models.packet_loss import PacketLossData, ReportMetadata
from src.services.packet_loss_filters import apply_packet_loss_filters

# Simple in-memory TTL cache
_CACHE = {}
CACHE_TTL = 300  # 5 minutes

def ttl_cache(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Only cache if first argument is a Session (skip it for cache key)
        key_args = args[1:] if args and hasattr(args[0], 'query') else args
        
        # Create a string representation of args and kwargs
        try:
            key_str = f"{func.__name__}:{hash(str(key_args))}:{hash(str(sorted(kwargs.items())))}"
        except Exception:
            return func(*args, **kwargs)
            
        now = time.time()
        if key_str in _CACHE:
            result, timestamp = _CACHE[key_str]
            if now - timestamp < CACHE_TTL:
                return result
                
        result = func(*args, **kwargs)
        _CACHE[key_str] = (result, now)
        return result
    return wrapper

def clear_dashboard_cache():
    """Clear the dashboard in-memory cache to force a refresh on the next request."""
    _CACHE.clear()


def _normalize_text(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _classify_technology(value: Optional[str]) -> str:
    if not value:
        return "Other"
    normalized = str(value).strip().lower()
    # Check voice first to prevent classifying "4G_Voice" as "4G"
    if "voice" in normalized:
        return "Voice"
    if "5g" in normalized:
        return "5G"
    if "4g" in normalized:
        return "4G"
    return "Other"


def _parse_numeric(value: Any) -> float:
    if not value:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(value) else 0.0
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else 0.0
    except ValueError:
        try:
            parsed = float(str(value).replace(",", "").strip())
            return parsed if math.isfinite(parsed) else 0.0
        except (TypeError, ValueError):
            return 0.0
    except TypeError:
        return 0.0


def _parse_iso_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(str(value).strip())
    except (TypeError, ValueError):
        return None


def _normalize_top_site_technology(value: Optional[str]) -> Optional[str]:
    normalized = _normalize_text(value)
    if not normalized:
        return None

    lower_value = normalized.lower()
    if "voice" in lower_value and "4g" in lower_value:
        return "4G_Voice"
    if "5g" in lower_value:
        return "5G_Data"
    if "4g" in lower_value:
        return "4G_Data"
    return normalized


def _numeric_sql_expression(column):
    return func.coalesce(
        cast(func.nullif(func.trim(func.replace(column, ",", "")), ""), Float),
        0.0,
    )


def _packet_loss_minutes_expression():
    total_expression = None
    for hour in range(24):
        column = getattr(PacketLossData, f"rt_packet_loss_{hour:02d}_percent")
        hour_expression = _numeric_sql_expression(column)
        total_expression = hour_expression if total_expression is None else total_expression + hour_expression
    return total_expression if total_expression is not None else literal(0.0)


def _normalize_circle(value: Optional[str]) -> Optional[str]:
    normalized = _normalize_text(value)
    if not normalized:
        return None
    mapping = {
        "all": None,
        "bihar": "BIH",
        "jharkhand": "JHK",
        "bih": "BIH",
        "bhk": "BIH",
        "jhk": "JHK",
        "bihar circle": "BIH",
        "jharkhand circle": "JHK",
    }
    return mapping.get(normalized.lower(), normalized)


def _build_history_query(
    db: Session,
    *,
    circle: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    technology: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
):
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
    )

    normalized_circle = _normalize_circle(circle)
    if normalized_circle:
        if normalized_circle == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == normalized_circle)

    if start_date:
        query = query.filter(ReportMetadata.report_date >= date.fromisoformat(start_date))
    if end_date:
        query = query.filter(ReportMetadata.report_date <= date.fromisoformat(end_date))

    query = apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=technology,
        pl_count=pl_count,
    )

    if technology:
        normalized_technology = _normalize_text(technology)
        if normalized_technology:
            query = query.filter(
                func.lower(func.trim(PacketLossData.twamp_technology)).like(
                    f"%{normalized_technology.lower()}%"
                )
            )

    return query


def _serialize_history_rows(rows: List[PacketLossData]) -> List[Dict[str, Any]]:
    serialized = []
    for row in rows:
        serialized.append(
            {
                "id": row.id,
                "report_id": row.report_id,
                "report_date": row.report.report_date.isoformat() if row.report else None,
                "circle": row.report.circle if row.report else None,
                "site_id": row.site_id,
                "site_name": row.site_name,
                "pop": row.pop_name,
                "technology": row.twamp_technology,
                "connection_type": row.connection_type,
                "pl_count": row.packet_loss_05_90_percent_count,
                "aging": row.packet_loss_ageing,
                "pl_hours": row.no_of_hrs_session_having_pl_05_90_count,
            }
        )
    return serialized


def _calculate_period_stats(
    db: Session,
    start: date,
    end: date,
    circle: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
) -> Dict[str, Any]:
    """Calculate per-period stats.

    The three technology KPIs (voice_count / four_g_count / five_g_count)
    count **qualifying rows** (each record that meets the PL threshold counts
    as one affected-site entry, matching Top Sites row-level counting):
      - 4G Voice  : packet_loss_05_90_percent_count >= 14
      - 4G Data   : packet_loss_05_90_percent_count >= 60
      - 5G Data   : packet_loss_05_90_percent_count >= 60
    Site identity uses site_name (preferred) with site_id fallback.
    """
    db_time = 0.0
    processing_time = 0.0

    # Base query
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.report_date >= start)
        .filter(ReportMetadata.report_date <= end)
    )

    normalized_circle = _normalize_circle(circle)
    if normalized_circle:
        if normalized_circle == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == normalized_circle)

    query = apply_packet_loss_filters(
        query,
        search=search,
        site_id=site_id,
        pop_name=pop_name,
        connection_type=connection_type,
        technology=None,
        pl_count=pl_count,
    )



    total_reports_query = (
        db.query(ReportMetadata)
        .filter(ReportMetadata.report_date >= start)
        .filter(ReportMetadata.report_date <= end)
    )
    if normalized_circle:
        total_reports_query = total_reports_query.filter(ReportMetadata.circle == normalized_circle)
    t_db = time.perf_counter()
    total_reports = total_reports_query.count()
    db_time += time.perf_counter() - t_db

    # Fetch the columns needed for threshold-based counting + hourly avg
    selected_columns = [
        PacketLossData.twamp_technology,
        PacketLossData.packet_loss_05_90_percent_count,
        PacketLossData.site_name,
        PacketLossData.site_id,
    ]
    for hour in range(24):
        selected_columns.append(getattr(PacketLossData, f"rt_packet_loss_{hour:02d}_percent"))

    t_db = time.perf_counter()
    rows = query.with_entities(*selected_columns).all()
    db_time += time.perf_counter() - t_db
    
    total_records = len(rows)

    # Row-level counters — each qualifying record = 1 affected-site entry
    # (matches Top Sites which counts every row, not distinct sites)
    voice_count = 0
    four_g_count = 0
    five_g_count = 0

    # Keep hourly averages for backward-compat fields
    voice_hour_sum = 0.0
    voice_hour_cnt = 0
    four_g_hour_sum = 0.0
    four_g_hour_cnt = 0
    five_g_hour_sum = 0.0
    five_g_hour_cnt = 0

    parse_numeric = _parse_numeric
    classify_technology = _classify_technology

    # Thresholds matching Top Sites logic exactly
    VOICE_THRESHOLD = 14   # 4G Voice: pl_count >= 14
    DATA_THRESHOLD = 60    # 4G Data & 5G Data: pl_count >= 60

    t_processing = time.perf_counter()
    for row in rows:
        tech_raw = row[0]
        pl_value = parse_numeric(row[1])
        s_name = _normalize_text(row[2])
        s_id = _normalize_text(row[3])
        # Site identifier: prefer site_name, fall back to site_id
        site_key = s_name or s_id

        tech_lower = str(tech_raw or '').strip().lower()
        is_voice = 'voice' in tech_lower and '4g' in tech_lower
        is_5g = '5g' in tech_lower
        is_4g_data = '4g' in tech_lower and 'voice' not in tech_lower

        # Count each qualifying row (same logic as Top Sites threshold filter)
        if site_key:
            if is_voice and pl_value >= VOICE_THRESHOLD:
                voice_count += 1
            elif is_5g and pl_value >= DATA_THRESHOLD:
                five_g_count += 1
            elif is_4g_data and pl_value >= DATA_THRESHOLD:
                four_g_count += 1

        # Classify for hourly avg (kept for backward compat)
        tech = classify_technology(tech_raw)
        row_sum = 0.0
        row_cnt = 0
        for hourly_val in row[4:]:  # hourly cols start at index 4
            if hourly_val is None:
                continue
            p_val = parse_numeric(hourly_val)
            if p_val >= 0:
                row_sum += p_val
                row_cnt += 1

        if row_cnt > 0:
            if tech == "Voice":
                voice_hour_sum += row_sum
                voice_hour_cnt += row_cnt
            elif tech == "4G":
                four_g_hour_sum += row_sum
                four_g_hour_cnt += row_cnt
            elif tech == "5G":
                five_g_hour_sum += row_sum
                five_g_hour_cnt += row_cnt

    voice_avg = (voice_hour_sum / voice_hour_cnt) if voice_hour_cnt > 0 else 0.0
    four_g_avg = (four_g_hour_sum / four_g_hour_cnt) if four_g_hour_cnt > 0 else 0.0
    five_g_avg = (five_g_hour_sum / five_g_hour_cnt) if five_g_hour_cnt > 0 else 0.0
    processing_time += time.perf_counter() - t_processing

    return {
        "total_records": total_records,
        "total_reports": total_reports,
        # Affected site counts (row-level, matching Top Sites)
        "voice_count": voice_count,
        "four_g_count": four_g_count,
        "five_g_count": five_g_count,
        # Hourly averages kept for backward compat
        "voice_avg": voice_avg,
        "four_g_avg": four_g_avg,
        "five_g_avg": five_g_avg,
    }


@ttl_cache
def get_dashboard_summary(db: Session, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    started_at = time.perf_counter()
    db_time = 0.0
    filter_values = filters or {}

    period_filter_kwargs = {
        "circle": filter_values.get("circle"),
        "pop_name": filter_values.get("pop_name"),
        "connection_type": filter_values.get("connection_type"),
        "site_id": filter_values.get("site_id"),
        "pl_count": filter_values.get("pl_count"),
        "search": filter_values.get("search"),
    }

    t_db = time.perf_counter()
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    db_time += time.perf_counter() - t_db

    # Always anchor to the latest available data date
    latest_date = latest_report.report_date if latest_report else datetime.utcnow().date()

    end_dt = None
    user_supplied_dates = bool(filter_values.get("end_date") or filter_values.get("start_date"))
    if filter_values.get("end_date"):
        end_dt = date.fromisoformat(filter_values["end_date"])
    else:
        end_dt = latest_date
        
    start_dt = None
    if filter_values.get("start_date"):
        start_dt = date.fromisoformat(filter_values["start_date"])
    else:
        start_dt = end_dt - timedelta(days=6)
        
    num_days = (end_dt - start_dt).days + 1
    prev_start_dt = start_dt - timedelta(days=num_days)
    prev_end_dt = start_dt - timedelta(days=1)

    current_stats = _calculate_period_stats(
        db,
        start_dt,
        end_dt,
        **period_filter_kwargs,
    )

    # If user chose dates that have no data, fall back to the window around the latest report
    if current_stats["total_records"] == 0 and user_supplied_dates:
        end_dt = latest_date
        start_dt = end_dt - timedelta(days=6)
        prev_start_dt = start_dt - timedelta(days=num_days)
        prev_end_dt = start_dt - timedelta(days=1)
        current_stats = _calculate_period_stats(
            db,
            start_dt,
            end_dt,
            **period_filter_kwargs,
        )
    
    prev_stats = _calculate_period_stats(
        db,
        prev_start_dt,
        prev_end_dt,
        **period_filter_kwargs,
    )

    def pct_change(curr, prev):
        if prev == 0:
            return 0.0
        return round(((curr - prev) / prev) * 100, 1)

    result = {
        "latest_upload_date": latest_report.report_date.isoformat() if latest_report else None,
        "data_start_date": start_dt.isoformat(),
        "data_end_date": end_dt.isoformat(),
        "total_reports": current_stats["total_reports"],
        "total_records": current_stats["total_records"],
        
        "voice_count": round(current_stats["voice_count"], 2),
        "voice_count_change": pct_change(current_stats["voice_count"], prev_stats["voice_count"]),
        
        "five_g_count": round(current_stats["five_g_count"], 2),
        "five_g_count_change": pct_change(current_stats["five_g_count"], prev_stats["five_g_count"]),
        
        "four_g_count": round(current_stats["four_g_count"], 2),
        "four_g_count_change": pct_change(current_stats["four_g_count"], prev_stats["four_g_count"]),
        
        "voice_avg_pl": round(current_stats["voice_avg"], 2),
        "voice_avg_pl_change": pct_change(current_stats["voice_avg"], prev_stats["voice_avg"]),
        
        "five_g_avg_pl": round(current_stats["five_g_avg"], 2),
        "five_g_avg_pl_change": pct_change(current_stats["five_g_avg"], prev_stats["five_g_avg"]),
        
        "four_g_avg_pl": round(current_stats["four_g_avg"], 2),
        "four_g_avg_pl_change": pct_change(current_stats["four_g_avg"], prev_stats["four_g_avg"]),
    }

    return result


@ttl_cache
def get_dashboard_trend_7days(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    started_at = time.perf_counter()
    db_time = 0.0

    t_db = time.perf_counter()
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    db_time += time.perf_counter() - t_db
    end_dt = date.fromisoformat(filters["end_date"]) if filters and filters.get("end_date") else (latest_report.report_date if latest_report else datetime.utcnow().date())
    start_dt = date.fromisoformat(filters["start_date"]) if filters and filters.get("start_date") else (end_dt - timedelta(days=6))
    
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.report_date >= start_dt)
        .filter(ReportMetadata.report_date <= end_dt)
    )
    
    normalized_circle = _normalize_circle(filters.get("circle") if filters else None)
    if normalized_circle:
        if normalized_circle == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == normalized_circle)

    query = apply_packet_loss_filters(
        query,
        search=filters.get("search") if filters else None,
        site_id=filters.get("site_id") if filters else None,
        pop_name=filters.get("pop_name") if filters else None,
        connection_type=filters.get("connection_type") if filters else None,
        technology=None,
        pl_count=filters.get("pl_count") if filters else None,
    )
    
    t_db = time.perf_counter()
    rows = query.with_entities(
        ReportMetadata.report_date,
        PacketLossData.twamp_technology,
        PacketLossData.packet_loss_05_90_percent_count
    ).all()
    db_time += time.perf_counter() - t_db
    
    daily_map = {}
    current = start_dt
    while current <= end_dt:
        daily_map[current] = {"4G_Data": 0.0, "5G_Data": 0.0, "4G_Voice": 0.0}
        current += timedelta(days=1)
        
    t_processing = time.perf_counter()
    for r_date, tech, pl_count in rows:
        if r_date in daily_map:
            val = _parse_numeric(pl_count)
            t_lower = str(tech or '').strip().lower()
            is_voice = 'voice' in t_lower and '4g' in t_lower
            is_5g = '5g' in t_lower
            is_4g_data = '4g' in t_lower and 'voice' not in t_lower

            if is_voice and val >= 14:
                daily_map[r_date]['4G_Voice'] += 1
            elif is_5g and val >= 60:
                daily_map[r_date]['5G_Data'] += 1
            elif is_4g_data and val >= 60:
                daily_map[r_date]['4G_Data'] += 1
                
    result = []
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for r_date, counts in sorted(daily_map.items()):
        result.append({
            "date": r_date.isoformat(),
            "day": day_names[r_date.weekday()],
            "four_g_data": round(counts["4G_Data"], 2),
            "five_g_data": round(counts["5G_Data"], 2),
            "four_g_voice": round(counts["4G_Voice"], 2)
        })
    return result


@ttl_cache
def get_dashboard_trend_wow(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    started_at = time.perf_counter()
    db_time = 0.0

    t_db = time.perf_counter()
    latest_report = (
        db.query(ReportMetadata)
        .order_by(ReportMetadata.report_date.desc(), ReportMetadata.uploaded_at.desc())
        .first()
    )
    db_time += time.perf_counter() - t_db
    end_dt = date.fromisoformat(filters["end_date"]) if filters and filters.get("end_date") else (latest_report.report_date if latest_report else datetime.utcnow().date())
    
    start_dt = end_dt - timedelta(weeks=10)
    
    query = (
        db.query(PacketLossData)
        .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
        .filter(ReportMetadata.report_date >= start_dt)
        .filter(ReportMetadata.report_date <= end_dt)
    )
    
    normalized_circle = _normalize_circle(filters.get("circle") if filters else None)
    if normalized_circle:
        if normalized_circle == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif normalized_circle == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == normalized_circle)

    query = apply_packet_loss_filters(
        query,
        search=filters.get("search") if filters else None,
        site_id=filters.get("site_id") if filters else None,
        pop_name=filters.get("pop_name") if filters else None,
        connection_type=filters.get("connection_type") if filters else None,
        technology=None,
        pl_count=filters.get("pl_count") if filters else None,
    )
    
    t_db = time.perf_counter()
    rows = query.with_entities(
        ReportMetadata.report_date,
        PacketLossData.twamp_technology,
        PacketLossData.packet_loss_05_90_percent_count
    ).all()
    db_time += time.perf_counter() - t_db
    
    curr = start_dt
    weekly_map = {}
    while curr <= end_dt:
        week_start = curr - timedelta(days=curr.weekday())
        weekly_map[week_start] = {"4G": 0, "5G": 0}
        curr += timedelta(days=7)
        
    t_processing = time.perf_counter()
    for r_date, tech, pl_count in rows:
        week_start = r_date - timedelta(days=r_date.weekday())
        if week_start in weekly_map:
            val = _parse_numeric(pl_count)
            t_lower = str(tech or '').strip().lower()
            is_voice = 'voice' in t_lower and '4g' in t_lower
            is_5g = '5g' in t_lower
            is_4g_data = '4g' in t_lower and 'voice' not in t_lower

            if is_voice and val >= 14:
                weekly_map[week_start]["4G"] += 1
            elif is_5g and val >= 60:
                weekly_map[week_start]["5G"] += 1
            elif is_4g_data and val >= 60:
                weekly_map[week_start]["4G"] += 1

    result = []
    base_week = 2600
    for idx, (week_start, counts) in enumerate(sorted(weekly_map.items())):
        result.append({
            "week_label": str(base_week + idx * 2),
            "week_start": week_start.isoformat(),
            "four_g": counts["4G"],
            "five_g": counts["5G"]
        })
        
    return result


@ttl_cache
def get_dashboard_backhaul(db: Session, filters: Optional[Dict[str, Any]] = None) -> Dict[str, List[Dict[str, Any]]]:
    started_at = time.perf_counter()
    db_time = 0.0

    query = _build_history_query(
        db,
        circle=filters.get("circle") if filters else None,
        start_date=filters.get("start_date") if filters else None,
        end_date=filters.get("end_date") if filters else None,
        technology=filters.get("technology") if filters else None,
        pop_name=filters.get("pop_name") if filters else None,
        connection_type=filters.get("connection_type") if filters else None,
        site_id=filters.get("site_id") if filters else None,
        pl_count=filters.get("pl_count") if filters else None,
        search=filters.get("search") if filters else None,
    )
    
    t_db = time.perf_counter()
    rows = query.with_entities(
        PacketLossData.twamp_technology,
        PacketLossData.connection_type,
        PacketLossData.packet_loss_05_90_percent_count
    ).all()
    db_time += time.perf_counter() - t_db
    
    five_g_sum = {"MW": 0, "UBR": 0, "FTTH": 0, "Fiber": 0}
    four_g_sum = {"MW": 0, "UBR": 0, "Fiber": 0, "FTTH": 0}
    
    t_processing = time.perf_counter()
    for tech, conn_type, pl_count in rows:
        val = _parse_numeric(pl_count)
        conn = str(conn_type or 'MW').strip()
        t = str(tech).lower()
        
        # Map to known types, fallback to MW
        if conn not in five_g_sum:
            conn = "MW"
            
        is_voice = 'voice' in t and '4g' in t
        is_5g = '5g' in t
        is_4g_data = '4g' in t and 'voice' not in t

        if is_5g and val >= 60:
            five_g_sum[conn] += 1
        elif is_voice and val >= 14:
            four_g_sum[conn] += 1
        elif is_4g_data and val >= 60:
            four_g_sum[conn] += 1
                
    result = {
        "five_g": [{"name": name, "value": val} for name, val in sorted(five_g_sum.items(), key=lambda x: x[1], reverse=True)],
        "four_g": [{"name": name, "value": val} for name, val in sorted(four_g_sum.items(), key=lambda x: x[1], reverse=True)]
    }
    return result


def get_dashboard_technology(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    query = _build_history_query(
        db,
        circle=filters.get("circle") if filters else None,
        start_date=filters.get("start_date") if filters else None,
        end_date=filters.get("end_date") if filters else None,
        technology=filters.get("technology") if filters else None,
        pop_name=filters.get("pop_name") if filters else None,
        connection_type=filters.get("connection_type") if filters else None,
        site_id=filters.get("site_id") if filters else None,
        pl_count=filters.get("pl_count") if filters else None,
        search=filters.get("search") if filters else None,
    )
    rows = query.with_entities(
        PacketLossData.twamp_technology,
        PacketLossData.packet_loss_05_90_percent_count
    ).all()
    
    summary: Dict[str, float] = {}
    for tech, pl_count in rows:
        key = _classify_technology(tech)
        summary[key] = summary.get(key, 0.0) + _parse_numeric(pl_count)
    return [{"name": name, "value": round(value, 2)} for name, value in sorted(summary.items())]


@ttl_cache
def get_dashboard_top_sites(
    db: Session,
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    started_at = time.perf_counter()
    db_time = 0.0
    filter_values = filters or {}

    total_pl_minutes_expr = _packet_loss_minutes_expression()
    pl_count_expr = _numeric_sql_expression(PacketLossData.packet_loss_05_90_percent_count)
    site_id_trimmed = func.nullif(func.trim(PacketLossData.site_id), "")
    site_name_trimmed = func.nullif(func.trim(PacketLossData.site_name), "")
    technology_trimmed = func.nullif(func.trim(PacketLossData.twamp_technology), "")
    backhaul_trimmed = func.nullif(func.trim(PacketLossData.connection_type), "")
    site_id_display_expr = func.coalesce(site_id_trimmed, site_name_trimmed, literal("N/A"))
    site_id_found_expr = and_(PacketLossData.site_id.isnot(None), func.trim(PacketLossData.site_id) != "")
    technology_lower = func.lower(func.trim(PacketLossData.twamp_technology))
    allowed_technology_expr = or_(
        and_(technology_lower.like("%voice%"), technology_lower.like("%4g%")),
        technology_lower.like("%5g%"),
        and_(technology_lower.like("%4g%"), technology_lower.notlike("%voice%")),
    )

    query = db.query(
        PacketLossData.id.label("record_id"),
        ReportMetadata.report_date.label("report_date"),
        PacketLossData.site_id.label("site_id"),
        PacketLossData.site_name.label("site_name"),
        PacketLossData.twamp_technology.label("technology"),
        PacketLossData.connection_type.label("backhaul"),
        PacketLossData.pop_name.label("pop_name"),
        PacketLossData.packet_loss_05_90_percent_count.label("pl_count"),
        total_pl_minutes_expr.label("total_pl_minutes"),
        site_id_display_expr.label("site_id_display"),
        site_id_found_expr.label("site_id_found"),
    ).join(
        ReportMetadata,
        PacketLossData.report_id == ReportMetadata.id,
    )

    circle_value = _normalize_circle(filter_values.get("circle"))
    if circle_value:
        if circle_value == "BIH":
            query = query.filter(ReportMetadata.circle.in_(["BIH", "BHK", "bih", "BIHAR", "bihar"]))
        elif circle_value == "JHK":
            query = query.filter(ReportMetadata.circle.in_(["JHK", "jhk"]))
        else:
            query = query.filter(ReportMetadata.circle == circle_value)

    report_date_value = _parse_iso_date(filter_values.get("report_date"))
    if report_date_value:
        query = query.filter(ReportMetadata.report_date == report_date_value)
    else:
        start_date_value = _parse_iso_date(filter_values.get("start_date"))
        end_date_value = _parse_iso_date(filter_values.get("end_date"))
        if start_date_value:
            query = query.filter(ReportMetadata.report_date >= start_date_value)
        if end_date_value:
            query = query.filter(ReportMetadata.report_date <= end_date_value)

    site_query = _normalize_text(filter_values.get("site_query") or filter_values.get("search"))
    if site_query:
        search_term = f"%{site_query.lower()}%"
        query = query.filter(
            func.lower(func.trim(PacketLossData.site_id)).like(search_term)
            | func.lower(func.trim(PacketLossData.site_name)).like(search_term)
            | func.lower(func.trim(PacketLossData.pop_name)).like(search_term)
        )

    backhaul_value = _normalize_text(filter_values.get("backhaul"))
    if backhaul_value:
        query = query.filter(func.lower(func.trim(PacketLossData.connection_type)).like(f"%{backhaul_value.lower()}%"))

    technology_filter = _normalize_top_site_technology(filter_values.get("technology"))
    if technology_filter == "4G_Voice":
        query = query.filter(technology_lower.like("%voice%"), technology_lower.like("%4g%"))
    elif technology_filter == "5G_Data":
        query = query.filter(technology_lower.like("%5g%"))
    elif technology_filter == "4G_Data":
        query = query.filter(technology_lower.like("%4g%"), technology_lower.notlike("%voice%"))
    elif technology_filter:
        query = query.filter(func.lower(func.trim(PacketLossData.twamp_technology)).like(f"%{technology_filter.lower()}%"))

    site_id_status = _normalize_text(filter_values.get("site_id_status"))
    if site_id_status == "Found":
        query = query.filter(site_id_found_expr)
    elif site_id_status == "Not Found":
        query = query.filter(~site_id_found_expr)

    query = query.filter(allowed_technology_expr)
    query = query.filter(
        or_(
            and_(technology_lower.like("%voice%"), technology_lower.like("%4g%"), pl_count_expr >= 14),
            and_(technology_lower.like("%5g%"), pl_count_expr >= 60),
            and_(technology_lower.like("%4g%"), technology_lower.notlike("%voice%"), pl_count_expr >= 60),
        )
    )

    sort_by = _normalize_text(filter_values.get("sort_by")) or "pl_count"
    sort_dir = (_normalize_text(filter_values.get("sort_dir")) or "desc").lower()
    sort_options = {
        "total_pl_minutes": total_pl_minutes_expr,
        "pl_count": pl_count_expr,
        "site_id": site_id_display_expr,
        "technology": technology_trimmed,
        "report_date": ReportMetadata.report_date,
    }
    sort_expression = sort_options.get(sort_by, pl_count_expr)
    sort_is_desc = sort_dir != "asc"

    t_db = time.perf_counter()
    total_records = query.order_by(None).count()
    db_time += time.perf_counter() - t_db

    page_raw = filter_values.get("page", 1)
    try:
        page = max(int(page_raw), 1)
    except (TypeError, ValueError):
        page = 1

    page_size_raw = filter_values.get("page_size", 25)
    is_all_rows = isinstance(page_size_raw, str) and page_size_raw.strip().lower() == "all"
    if is_all_rows:
        effective_page_size = None
    else:
        try:
            effective_page_size = max(int(page_size_raw), 1)
        except (TypeError, ValueError):
            effective_page_size = 25

    if total_records == 0:
        total_pages = 0
        page = 1
    elif effective_page_size is None:
        total_pages = 1
        page = 1
    else:
        total_pages = math.ceil(total_records / effective_page_size)
        page = min(page, total_pages)

    if sort_is_desc:
        order_by_clause = [sort_expression.desc(), ReportMetadata.report_date.desc(), PacketLossData.id.desc()]
    else:
        order_by_clause = [sort_expression.asc(), ReportMetadata.report_date.asc(), PacketLossData.id.asc()]

    t_db = time.perf_counter()
    paged_query = query.order_by(*order_by_clause)
    if effective_page_size is not None:
        paged_query = paged_query.offset((page - 1) * effective_page_size).limit(effective_page_size)
    rows = paged_query.all()
    db_time += time.perf_counter() - t_db

    t_processing = time.perf_counter()
    result_rows: List[Dict[str, Any]] = []
    page_offset = (page - 1) * effective_page_size if effective_page_size is not None else 0
    for idx, row in enumerate(rows):
        site_name = _normalize_text(row.site_name)
        site_id_raw = _normalize_text(row.site_id)
        site_id_display = _normalize_text(row.site_id_display) or site_name or "N/A"
        technology_value = _normalize_top_site_technology(row.technology) or site_name or "N/A"
        result_rows.append(
            {
                "rank": page_offset + idx + 1,
                "site_id": site_id_display,
                "site_id_raw": site_id_raw,
                "site_name": site_name or "N/A",
                "pop_name": _normalize_text(row.pop_name) or "N/A",
                "technology": technology_value,
                "backhaul": _normalize_text(row.backhaul) or "N/A",
                "total_pl_minutes": round(_parse_numeric(row.total_pl_minutes), 2),
                "pl_count": round(_parse_numeric(row.pl_count), 2),
                "report_date": row.report_date.isoformat() if row.report_date else None,
                "site_id_status": "Found" if row.site_id_found else "Not Found",
            }
        )
    processing_time = time.perf_counter() - t_processing

    _log = {
        "total_records": total_records,
        "page": page,
        "page_size": "All" if effective_page_size is None else effective_page_size,
        "total_pages": total_pages,
        "rows": result_rows,
    }
    return _log


@ttl_cache
def get_dashboard_circle_breakdown(db: Session, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Per-circle stats: total PL events, records, sites affected, breakdown by tech."""
    started_at = time.perf_counter()
    db_time = 0.0
    processing_time = 0.0

    circles = [("BIH", ["BIH", "BHK", "bih", "BIHAR", "bihar"]), ("JHK", ["JHK", "jhk"])]
    result = []
    for label, codes in circles:
        q = (
            db.query(PacketLossData)
            .join(ReportMetadata, PacketLossData.report_id == ReportMetadata.id)
            .filter(ReportMetadata.circle.in_(codes))
        )
        # Apply date filters
        if filters:
            if filters.get("start_date"):
                q = q.filter(ReportMetadata.report_date >= date.fromisoformat(filters["start_date"]))
            if filters.get("end_date"):
                q = q.filter(ReportMetadata.report_date <= date.fromisoformat(filters["end_date"]))

        t_db = time.perf_counter()
        rows = q.with_entities(
            PacketLossData.twamp_technology,
            PacketLossData.packet_loss_05_90_percent_count,
            PacketLossData.no_of_hrs_session_having_pl_05_90_count,
            PacketLossData.site_name,
            PacketLossData.site_id,
        ).all()
        db_time += time.perf_counter() - t_db

        total_pl = 0.0
        total_hrs = 0.0
        # Row-level counters matching _calculate_period_stats logic
        four_g_pl = 0
        five_g_pl = 0
        voice_pl = 0
        sites_affected = set()

        t_processing = time.perf_counter()
        for tech, pl_count_val, pl_hrs, s_name, s_id in rows:
            pl_val = _parse_numeric(pl_count_val)
            hrs_val = _parse_numeric(pl_hrs)
            total_pl += pl_val
            total_hrs += hrs_val

            site_key = _normalize_text(s_name) or _normalize_text(s_id)

            tech_lower = str(tech or '').strip().lower()
            is_voice = 'voice' in tech_lower and '4g' in tech_lower
            is_5g = '5g' in tech_lower
            is_4g_data = '4g' in tech_lower and 'voice' not in tech_lower

            # Count each qualifying row (same as summary + Top Sites)
            if site_key:
                if is_voice and pl_val >= 14:
                    voice_pl += 1
                    sites_affected.add(site_key)
                elif is_5g and pl_val >= 60:
                    five_g_pl += 1
                    sites_affected.add(site_key)
                elif is_4g_data and pl_val >= 60:
                    four_g_pl += 1
                    sites_affected.add(site_key)

        processing_time += time.perf_counter() - t_processing

        circle_label = "Bihar Circle" if label == "BIH" else "Jharkhand Circle"
        result.append({
            "circle": circle_label,
            "circle_code": label,
            "total_pl_count": voice_pl + four_g_pl + five_g_pl,
            "total_pl_hours": round(total_hrs, 2),
            "four_g_pl": four_g_pl,
            "five_g_pl": five_g_pl,
            "voice_pl": voice_pl,
            "sites_affected": len(sites_affected),
        })
    return result


def get_dashboard_history(
    db: Session,
    *,
    circle: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    technology: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    site_id: Optional[str] = None,
    pl_count: Optional[str] = None,
    search: Optional[str] = None,
    skip: int = 0,
    limit: int = 20,
) -> Dict[str, Any]:
    query = _build_history_query(
        db,
        circle=circle,
        start_date=start_date,
        end_date=end_date,
        technology=technology,
        pop_name=pop_name,
        connection_type=connection_type,
        site_id=site_id,
        pl_count=pl_count,
        search=search,
    )
    total = query.count()
    rows = (
        query.options(joinedload(PacketLossData.report))
        .order_by(ReportMetadata.report_date.desc(), PacketLossData.created_at.desc(), PacketLossData.id.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return {
        "total": total,
        "rows": _serialize_history_rows(rows),
    }

