from typing import Optional

from sqlalchemy import func
from sqlalchemy.orm import Query

from src.models.packet_loss import PacketLossData


def normalize_filter_value(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    normalized = str(value).strip()
    return normalized or None


def apply_packet_loss_filters(
    query: Query,
    *,
    search: Optional[str] = None,
    site_id: Optional[str] = None,
    pop_name: Optional[str] = None,
    connection_type: Optional[str] = None,
    technology: Optional[str] = None,
    pl_count: Optional[str] = None,
) -> Query:
    normalized_search = normalize_filter_value(search)
    if normalized_search:
        search_term = f"%{normalized_search.lower()}%"
        query = query.filter(
            func.lower(func.trim(PacketLossData.site_id)).like(search_term) |
            func.lower(func.trim(PacketLossData.site_name)).like(search_term) |
            func.lower(func.trim(PacketLossData.short_name)).like(search_term) |
            func.lower(func.trim(PacketLossData.pop_name)).like(search_term) |
            func.lower(func.trim(PacketLossData.twamp_technology)).like(search_term)
        )

    for column, value, exact in [
        (PacketLossData.site_id, site_id, False),
        (PacketLossData.pop_name, pop_name, True),
        (PacketLossData.connection_type, connection_type, True),
        (PacketLossData.twamp_technology, technology, True),
        (PacketLossData.packet_loss_05_90_percent_count, pl_count, True),
    ]:
        normalized_value = normalize_filter_value(value)
        if normalized_value is None:
            continue
        normalized_column = func.lower(func.trim(column))
        normalized_value_lower = normalized_value.lower()
        if exact:
            query = query.filter(normalized_column == normalized_value_lower)
        else:
            query = query.filter(normalized_column.like(f"%{normalized_value_lower}%"))

    return query
