from typing import List, Optional
from sqlalchemy.orm import Session
from src.models.item import Item
from src.schemas.item import ItemCreate, ItemUpdate


def get_item(db: Session, item_id: int) -> Optional[Item]:
    """
    Retrieve a single Item by its primary key ID.
    """
    return db.query(Item).filter(Item.id == item_id).first()


def get_items(db: Session, skip: int = 0, limit: int = 100) -> List[Item]:
    """
    Retrieve multiple Items with pagination (skip and limit).
    """
    return db.query(Item).offset(skip).limit(limit).all()


def create_item(db: Session, item: ItemCreate) -> Item:
    """
    Create a new Item in the database.
    """
    db_item = Item(
        title=item.title,
        description=item.description
    )
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item


def update_item(db: Session, db_item: Item, item_update: ItemUpdate) -> Item:
    """
    Update an existing Item's fields with the provided new values.
    """
    update_data = item_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_item, key, value)
    
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item


def delete_item(db: Session, db_item: Item) -> None:
    """
    Delete an Item from the database.
    """
    db.delete(db_item)
    db.commit()
