from typing import List, Optional
from sqlalchemy.orm import Session
from src.models.five_g_data import FiveGData
from src.schemas.five_g_data import FiveGDataCreate


def get_five_g_data_list(db: Session, skip: int = 0, limit: Optional[int] = None) -> List[FiveGData]:
    """
    Retrieve all 5G Site Data items. No limit is applied by default so all records are returned.
    """
    query = db.query(FiveGData).offset(skip)
    if limit is not None:
        query = query.limit(limit)
    return query.all()


def create_five_g_data_batch(db: Session, items: List[FiveGDataCreate]) -> List[FiveGData]:
    """
    Optimized bulk save of 5G Site Data items into the database.
    """
    if not items:
        return []

    # 1. Convert schemas to dicts
    mappings = [
        {
            "site_id": item.site_id,
            "twamp_unique_site_id": item.twamp_unique_site_id,
            "pop": item.pop,
            "fiber_mw_rc": item.fiber_mw_rc
        }
        for item in items
    ]

    # 2. Bulk insert mappings
    db.bulk_insert_mappings(FiveGData, mappings)
    db.commit()

    # 3. Recreate objects in memory to avoid N+1 database fetches (db.refresh)
    return [
        FiveGData(
            site_id=m["site_id"],
            twamp_unique_site_id=m["twamp_unique_site_id"],
            pop=m["pop"],
            fiber_mw_rc=m["fiber_mw_rc"]
        )
        for m in mappings
    ]


def delete_all_five_g_data(db: Session) -> None:
    """
    Clear all 5G Site Data from the database.
    """
    db.query(FiveGData).delete()
    db.commit()


def delete_five_g_data_item(db: Session, item_id: int) -> bool:
    """
    Delete a single 5G Site Data item by its ID.
    """
    db_item = db.query(FiveGData).filter(FiveGData.id == item_id).first()
    if db_item:
        db.delete(db_item)
        db.commit()
        return True
    return False
