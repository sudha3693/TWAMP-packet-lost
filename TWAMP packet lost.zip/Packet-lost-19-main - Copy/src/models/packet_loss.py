from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Date, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from src.database import Base


class ReportMetadata(Base):
    __tablename__ = "report_metadata"
    __table_args__ = (
        Index("ix_report_metadata_circle_report_date", "circle", "report_date"),
    )

    id = Column(Integer, primary_key=True, index=True)
    report_date = Column(Date, nullable=False, index=True)
    circle = Column(String(50), nullable=False, index=True)
    uploaded_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    packet_loss_rows = relationship(
        "PacketLossData",
        back_populates="report",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class PacketLossData(Base):
    __tablename__ = "packet_loss_data"
    __table_args__ = (
        Index("ix_packet_loss_site_id", "site_id"),
        Index("ix_packet_loss_pop_name", "pop_name"),
        Index("ix_packet_loss_connection", "connection_type"),
        Index("ix_packet_loss_technology", "twamp_technology"),
    )

    id = Column(Integer, primary_key=True, index=True)
    report_id = Column(Integer, ForeignKey("report_metadata.id", ondelete="CASCADE"), nullable=False, index=True)

    short_name = Column(String(255), nullable=True)
    pop_name = Column(String(255), nullable=True)
    connection_type = Column(String(255), nullable=True)
    packet_loss_05_90_percent_count = Column(String(255), nullable=True)

    rt_packet_loss_00_percent = Column(String(255), nullable=True)
    packet_loss_00_count = Column(String(255), nullable=True)
    rt_packet_loss_01_percent = Column(String(255), nullable=True)
    packet_loss_01_count = Column(String(255), nullable=True)
    rt_packet_loss_02_percent = Column(String(255), nullable=True)
    packet_loss_02_count = Column(String(255), nullable=True)
    rt_packet_loss_03_percent = Column(String(255), nullable=True)
    packet_loss_03_count = Column(String(255), nullable=True)
    rt_packet_loss_04_percent = Column(String(255), nullable=True)
    packet_loss_04_count = Column(String(255), nullable=True)
    rt_packet_loss_05_percent = Column(String(255), nullable=True)
    packet_loss_05_count = Column(String(255), nullable=True)
    rt_packet_loss_06_percent = Column(String(255), nullable=True)
    packet_loss_06_count = Column(String(255), nullable=True)
    rt_packet_loss_07_percent = Column(String(255), nullable=True)
    packet_loss_07_count = Column(String(255), nullable=True)
    rt_packet_loss_08_percent = Column(String(255), nullable=True)
    packet_loss_08_count = Column(String(255), nullable=True)
    rt_packet_loss_09_percent = Column(String(255), nullable=True)
    packet_loss_09_count = Column(String(255), nullable=True)
    rt_packet_loss_10_percent = Column(String(255), nullable=True)
    packet_loss_10_count = Column(String(255), nullable=True)
    rt_packet_loss_11_percent = Column(String(255), nullable=True)
    packet_loss_11_count = Column(String(255), nullable=True)
    rt_packet_loss_12_percent = Column(String(255), nullable=True)
    packet_loss_12_count = Column(String(255), nullable=True)
    rt_packet_loss_13_percent = Column(String(255), nullable=True)
    packet_loss_13_count = Column(String(255), nullable=True)
    rt_packet_loss_14_percent = Column(String(255), nullable=True)
    packet_loss_14_count = Column(String(255), nullable=True)
    rt_packet_loss_15_percent = Column(String(255), nullable=True)
    packet_loss_15_count = Column(String(255), nullable=True)
    rt_packet_loss_16_percent = Column(String(255), nullable=True)
    packet_loss_16_count = Column(String(255), nullable=True)
    rt_packet_loss_17_percent = Column(String(255), nullable=True)
    packet_loss_17_count = Column(String(255), nullable=True)
    rt_packet_loss_18_percent = Column(String(255), nullable=True)
    packet_loss_18_count = Column(String(255), nullable=True)
    rt_packet_loss_19_percent = Column(String(255), nullable=True)
    packet_loss_19_count = Column(String(255), nullable=True)
    rt_packet_loss_20_percent = Column(String(255), nullable=True)
    packet_loss_20_count = Column(String(255), nullable=True)
    rt_packet_loss_21_percent = Column(String(255), nullable=True)
    packet_loss_21_count = Column(String(255), nullable=True)
    rt_packet_loss_22_percent = Column(String(255), nullable=True)
    packet_loss_22_count = Column(String(255), nullable=True)
    rt_packet_loss_23_percent = Column(String(255), nullable=True)
    packet_loss_23_count = Column(String(255), nullable=True)

    packet_loss_ageing = Column(String(255), nullable=True)
    no_of_hrs_session_having_pl_05_90_count = Column(String(255), nullable=True)
    site_name = Column(String(255), nullable=True)
    site_id = Column(String(100), nullable=True)
    site_type = Column(String(255), nullable=True)
    twamp_technology = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    report = relationship("ReportMetadata", back_populates="packet_loss_rows")
