from sqlalchemy import Column, Integer, String, Text
from src.database import Base


class Item(Base):
    """
    SQLAlchemy Database Model for the 'items' table.
    """
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(100), index=True, nullable=False)
    description = Column(Text, nullable=True)
