from sqlalchemy import Column, Integer, String
from src.database import Base


class FiveGData(Base):
    """
    SQLAlchemy database model for storing 5G Site header information.
    """
    __tablename__ = "5g_data"

    id = Column(Integer, primary_key=True, index=True)
    site_id = Column(String(100), nullable=True)
    twamp_unique_site_id = Column(String(100), nullable=True)
    pop = Column(String(100), nullable=True)
    fiber_mw_rc = Column(String(50), nullable=True)
