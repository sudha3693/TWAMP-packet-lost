import os
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "FastAPI SQLite SQLAlchemy Template"
    DATABASE_URL: str = "sqlite:///./sql_app.db"

    # SettingsConfigDict loads variables from a .env file if it exists
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
