import React from 'react';
import html from '../html.js';

export default function PlaceholderPage({ title }) {
  return html`
    <div style=${{
      padding: '40px',
      backgroundColor: '#111622',
      border: '1px solid rgba(255, 255, 255, 0.08)',
      borderRadius: '12px',
      textAlign: 'center',
      marginTop: '20px'
    }}>
      <div style=${{ fontSize: '48px', marginBottom: '16px' }}>⚙️</div>
      <h2 style=${{ fontSize: '22px', fontWeight: '700', color: '#fff', marginBottom: '8px' }}>${title}</h2>
      <p style=${{ color: '#8f9bb3', fontSize: '15px' }}>This page is currently under active development.</p>
    </div>
  `;
}
