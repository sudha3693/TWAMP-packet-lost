import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';


export default function FiveGImport() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const fileInputRef = useRef(null);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const records = await api.getFiveGData();
      setData(records);
    } catch (err) {
      setError('Could not connect to the backend server. Please verify the FastAPI service is running on port 8000.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUploadFile = async (file) => {
    if (!file) return;
    if (!file.name.endsWith('.xlsx')) {
      setError('Only Excel files (.xlsx) are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadFiveGData(formData);
      setMessage(res.message || 'File uploaded successfully.');
      loadData();
    } catch (err) {
      setError(err.message || 'Failed to upload file.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleUploadFile(e.target.files[0]);
    }
  };

  const onButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDeleteItem = async (id) => {
    if (!confirm('Are you sure you want to delete this record?')) return;
    try {
      await api.deleteFiveGDataItem(id);
      setData(data.filter((item) => item.id !== id));
    } catch (err) {
      alert(`Failed to delete record: ${err.message}`);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Are you sure you want to delete all imported records?')) return;
    try {
      await api.deleteAllFiveGData();
      setData([]);
      setMessage('All records cleared successfully.');
      setCurrentPage(1);
    } catch (err) {
      alert(`Failed to clear records: ${err.message}`);
    }
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    setCurrentPage(1); // reset to page 1 on new search
  };

  const handlePageSizeChange = (e) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  const filteredData = data.filter((item) => {
    const s = search.toLowerCase();
    return (
      (item.site_id && item.site_id.toLowerCase().includes(s)) ||
      (item.twamp_unique_site_id && item.twamp_unique_site_id.toLowerCase().includes(s)) ||
      (item.pop && item.pop.toLowerCase().includes(s)) ||
      (item.fiber_mw_rc && item.fiber_mw_rc.toLowerCase().includes(s))
    );
  });

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const pagedData = filteredData.slice((safePage - 1) * pageSize, safePage * pageSize);

  return html`
    <div>
      <div className="glass-panel" style=${{ marginBottom: '30px' }}>
        <h2 className="list-title" style=${{ marginBottom: '16px' }}>5G Site Data Excel Import</h2>
        <p style=${{ color: 'hsl(var(--text-muted))', fontSize: '15px', marginBottom: '24px', lineHeight: '1.6' }}>
          Upload your network Excel sheet here. The importer will automatically identify the headers, parse the file, and map/store only the following specific columns: <strong>site id</strong>, <strong>TWAMP-Unique-SiteID</strong>, <strong>pop</strong>, and <strong>Fiber/MW(R/C)</strong>.
        </p>

        <!-- Drag & Drop Zone -->
        <div 
          className=${`upload-zone ${dragActive ? 'drag-active' : ''}`}
          onDragEnter=${handleDrag}
          onDragOver=${handleDrag}
          onDragLeave=${handleDrag}
          onDrop=${handleDrop}
          onClick=${onButtonClick}
        >
          <input 
            type="file"
            ref=${fileInputRef}
            style=${{ display: 'none' }}
            onChange=${handleFileInputChange}
            accept=".xlsx"
          />
          <div className="upload-icon">
            ${uploading ? html`🔄` : html`📥`}
          </div>
          <div className="upload-text">
            ${uploading ? 'Processing & parsing Excel sheet...' : 'Drag & drop Excel sheet here or click to browse'}
          </div>
          <div className="upload-subtext">
            Supports .xlsx spreadsheets. Only imports required mapping columns.
          </div>
        </div>

        <!-- Success Banner -->
        ${message && html`
          <div style=${{ 
            color: 'hsl(var(--success))', 
            backgroundColor: 'var(--success-glow)', 
            padding: '12px 16px', 
            borderRadius: 'var(--radius-md)', 
            marginTop: '20px',
            fontSize: '14px', 
            border: '1px solid rgba(34, 197, 94, 0.2)' 
          }}>
            ✅ <strong>Success:</strong> ${message}
          </div>
        `}

        <!-- Error Banner -->
        ${error && html`
          <div style=${{ 
            color: 'hsl(var(--danger))', 
            backgroundColor: 'var(--danger-glow)', 
            padding: '12px 16px', 
            borderRadius: 'var(--radius-md)', 
            marginTop: '20px',
            fontSize: '14px', 
            border: '1px solid rgba(244, 63, 94, 0.2)' 
          }}>
            ⚠️ <strong>Error:</strong> ${error}
          </div>
        `}
      </div>

      <!-- Imported Data Inventory -->
      <div className="glass-panel">
        <div className="list-header" style=${{ flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <h2 className="list-title">Imported Site Database</h2>
            <p style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
              Showing <strong>${pagedData.length}</strong> of <strong>${filteredData.length}</strong> records
              ${filteredData.length !== data.length
                ? html` (filtered from <strong>${data.length}</strong> total)`
                : html` total`}
            </p>
          </div>

          <div style=${{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
            <input 
              type="text" 
              className="form-input search-bar" 
              placeholder="🔍 Search site database..." 
              value=${search} 
              onChange=${handleSearchChange}
              style=${{ width: '220px' }}
            />

            <select
              className="form-input"
              value=${pageSize}
              onChange=${handlePageSizeChange}
              style=${{ width: '110px', fontSize: '13px' }}
            >
              <option value=${25}>25 / page</option>
              <option value=${50}>50 / page</option>
              <option value=${100}>100 / page</option>
            </select>

            ${data.length > 0 && html`
              <button 
                type="button" 
                className="btn btn-danger btn-sm"
                onClick=${handleClearAll}
                title="Clear Database"
              >
                Clear All
              </button>
            `}
          </div>
        </div>

        <!-- Loading -->
        ${loading && html`
          <div style=${{ textAlign: 'center', padding: '48px 0', color: '#8f9bb3' }}>
            <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
            <p>Fetching imported records from SQLite database...</p>
          </div>
        `}

        <!-- Empty State -->
        ${!loading && filteredData.length === 0 && html`
          <div className="empty-state" style=${{ padding: '48px 0' }}>
            <div className="empty-icon">📁</div>
            <p>${data.length === 0
              ? 'No site data has been imported yet. Upload an Excel sheet above to get started.'
              : 'No site records match your search queries.'}</p>
          </div>
        `}

        <!-- Table -->
        ${!loading && pagedData.length > 0 && html`
          <div className="custom-table-container">
            <table className="custom-table">
              <thead>
                <tr>
                  <th style=${{ width: '70px' }}>ID</th>
                  <th>Site ID</th>
                  <th>TWAMP Unique Site ID</th>
                  <th>POP</th>
                  <th>Fiber/MW (R/C)</th>
                  <th style=${{ width: '80px', textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                ${pagedData.map((item) => html`
                  <tr key=${item.id}>
                    <td>#${item.id}</td>
                    <td style=${{ color: 'hsl(var(--text-main))', fontWeight: '500' }}>
                      ${item.site_id || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    <td>
                      ${item.twamp_unique_site_id || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    <td>
                      ${item.pop || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                    </td>
                    <td>
                      <span style=${{
                        padding: '3px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        backgroundColor: 'rgba(255,255,255,0.05)',
                        border: '1px solid var(--glass-border)',
                        color: 'hsl(var(--text-main))'
                      }}>
                        ${item.fiber_mw_rc || html`<em style=${{ color: 'hsl(var(--text-muted))' }}>N/A</em>`}
                      </span>
                    </td>
                    <td style=${{ textAlign: 'center' }}>
                      <button 
                        type="button" 
                        className="item-action-btn delete-btn"
                        onClick=${() => handleDeleteItem(item.id)}
                        title="Delete Record"
                        style=${{ padding: '6px' }}
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                `)}
              </tbody>
            </table>
          </div>

          <!-- Pagination Controls -->
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '18px', flexWrap: 'wrap', gap: '12px' }}>
            <div style=${{ color: 'hsl(var(--text-muted))', fontSize: '13px' }}>
              Page <strong>${safePage}</strong> of <strong>${totalPages}</strong> — ${filteredData.length} records
            </div>
            <div style=${{ display: 'flex', gap: '8px' }}>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === 1}
                onClick=${() => setCurrentPage(1)}
              >««</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === 1}
                onClick=${() => setCurrentPage(safePage - 1)}
              >Previous</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === totalPages}
                onClick=${() => setCurrentPage(safePage + 1)}
              >Next</button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                disabled=${safePage === totalPages}
                onClick=${() => setCurrentPage(totalPages)}
              >»»</button>
            </div>
          </div>
        `}
      </div>
    </div>
  `;
}
