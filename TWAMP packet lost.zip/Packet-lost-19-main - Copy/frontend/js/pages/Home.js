import React, { useEffect, useState } from 'react';
import html from '../html.js';
import { api } from '../api.js';

const TOP_SITES_RECENT_SEARCHES_KEY = 'recent_top_sites_site_queries';
const DEFAULT_TOP_SITES_FILTERS = {
  site_query: '',
  technology: 'All',
  backhaul: '',
  report_date: '',
  site_id_status: 'All',
  sort_by: 'pl_count',
  sort_dir: 'desc',
  page: 1,
  page_size: '25'
};

const TOP_SITES_BACKHAUL_OPTIONS = ['MW', 'UBR', 'FTTH', 'Fiber'];

export default function Home({ circle, startDate, endDate, refreshKey, onSiteClick }) {
  const [summary, setSummary] = useState(null);
  const [trend7Days, setTrend7Days] = useState([]);
  const [trendWow, setTrendWow] = useState([]);
  const [backhaul, setBackhaul] = useState({ five_g: [], four_g: [] });
  const [topSites, setTopSites] = useState([]);
  const [topSitesMeta, setTopSitesMeta] = useState({ total_records: 0, page: 1, page_size: '25', total_pages: 0 });
  const [topSitesFilters, setTopSitesFilters] = useState(DEFAULT_TOP_SITES_FILTERS);
  const [topSitesLoading, setTopSitesLoading] = useState(true);
  const [topSitesError, setTopSitesError] = useState('');
  const [recentTopSiteSearches, setRecentTopSiteSearches] = useState([]);
  const [showRecentTopSiteSearches, setShowRecentTopSiteSearches] = useState(false);
  const [circleBreakdown, setCircleBreakdown] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem(TOP_SITES_RECENT_SEARCHES_KEY);
    if (!saved) {
      return;
    }

    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        setRecentTopSiteSearches(parsed.filter(Boolean));
      }
    } catch (_) {
      localStorage.removeItem(TOP_SITES_RECENT_SEARCHES_KEY);
    }
  }, []);

  const loadDashboard = async () => {
    setLoading(true);
    setError('');
    const dateFilters = {};
    if (startDate) dateFilters.start_date = startDate;
    if (endDate) dateFilters.end_date = endDate;
    const filters = { circle, ...dateFilters };
    try {
      const [summaryData, trend7DaysData, trendWowData, backhaulData, circleData] = await Promise.all([
        api.getDashboardSummary(filters),
        api.getDashboardTrend7Days(filters),
        api.getDashboardTrendWow(filters),
        api.getDashboardBackhaul(filters),
        api.getDashboardCircleBreakdown(filters),
      ]);
      setSummary(summaryData);
      setTrend7Days(trend7DaysData || []);
      setTrendWow(trendWowData || []);
      setBackhaul(backhaulData || { five_g: [], four_g: [] });
      setCircleBreakdown(circleData || []);
    } catch (err) {
      setError(err.message || 'Failed to load dashboard analytics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, [circle, startDate, endDate, refreshKey]);

  useEffect(() => {
    let isMounted = true;

    async function loadTopSites() {
      setTopSitesLoading(true);
      setTopSitesError('');
      try {
        const topSitesRequestFilters = { circle, ...topSitesFilters };
        if (startDate) topSitesRequestFilters.start_date = startDate;
        if (endDate) topSitesRequestFilters.end_date = endDate;
        const response = await api.getDashboardTopSites(topSitesRequestFilters);
        if (!isMounted) return;

        const payload = Array.isArray(response)
          ? {
            rows: response,
            total_records: response.length,
            page: topSitesFilters.page,
            page_size: topSitesFilters.page_size,
            total_pages: topSitesFilters.page_size === 'All' ? 1 : Math.max(1, Math.ceil(response.length / Number(topSitesFilters.page_size || 25)))
          }
          : (response || {});

        const rows = payload.rows || [];
        setTopSites(rows);
        setTopSitesMeta({
          total_records: payload.total_records ?? rows.length,
          page: payload.page ?? topSitesFilters.page,
          page_size: payload.page_size ?? topSitesFilters.page_size,
          total_pages: payload.total_pages ?? 0
        });
      } catch (err) {
        if (!isMounted) return;
        setTopSites([]);
        setTopSitesError(err.message || 'Failed to load Top Sites packet loss data.');
        setTopSitesMeta({ total_records: 0, page: 1, page_size: topSitesFilters.page_size, total_pages: 0 });
      } finally {
        if (isMounted) {
          setTopSitesLoading(false);
        }
      }
    }

    loadTopSites();

    return () => {
      isMounted = false;
    };
  }, [circle, startDate, endDate, refreshKey, topSitesFilters]);

  useEffect(() => {
    if (!window.ApexCharts) return;
    if (loading) return;

    const renderTrend7Days = () => {
      const el = document.getElementById('trend-7days-chart');
      if (!el) return;
      el.innerHTML = '';

      const dayNames = trend7Days.map(item => item.day);
      const instance = new window.ApexCharts(el, {
        chart: { type: 'bar', height: 320, toolbar: { show: false }, background: 'transparent' },
        plotOptions: { bar: { horizontal: false, columnWidth: '55%', borderRadius: 2 } },
        colors: ['#ff6b35', '#e040fb', '#0062ff'],
        series: [
          { name: '4G Data Affected Sites (PL ≥ 60)', data: trend7Days.map(item => item.four_g_data) },
          { name: '5G Data Affected Sites (PL ≥ 60)', data: trend7Days.map(item => item.five_g_data) },
          { name: '4G Voice Affected Sites (PL ≥ 14)', data: trend7Days.map(item => item.four_g_voice) }
        ],
        xaxis: { categories: dayNames, labels: { style: { colors: '#8f9bb3' } } },
        yaxis: { labels: { style: { colors: '#8f9bb3' } } },
        grid: { borderColor: 'rgba(255,255,255,0.06)' },
        legend: { position: 'top', horizontalAlign: 'right', labels: { colors: '#fff' } },
        tooltip: { theme: 'dark' }
      });
      instance.render();
    };

    const renderTrendWow = () => {
      const el = document.getElementById('trend-wow-chart');
      if (!el) return;
      el.innerHTML = '';

      const weekLabels = trendWow.map((_, idx) => `Week ${idx + 1}`);
      const instance = new window.ApexCharts(el, {
        chart: { type: 'area', height: 320, toolbar: { show: false }, background: 'transparent' },
        stroke: { curve: 'smooth', width: 3 },
        colors: ['#ff6b35', '#e040fb'],
        fill: {
          type: 'gradient',
          gradient: {
            shadeIntensity: 1,
            opacityFrom: 0.35,
            opacityTo: 0.05,
            stops: [0, 90, 100]
          }
        },
        series: [
          { name: '4G Affected Sites (Voice ≥ 14 min / Data ≥ 60 min)', data: trendWow.map(item => item.four_g) },
          { name: '5G Affected Sites (Data ≥ 60 min)', data: trendWow.map(item => item.five_g) }
        ],
        xaxis: { categories: weekLabels, title: { text: 'Week (---->', style: { color: '#8f9bb3' } }, labels: { style: { colors: '#8f9bb3' } } },
        yaxis: { labels: { style: { colors: '#8f9bb3' } } },
        grid: { borderColor: 'rgba(255,255,255,0.06)' },
        legend: { position: 'top', horizontalAlign: 'right', labels: { colors: '#fff' } },
        tooltip: { theme: 'dark' }
      });
      instance.render();
    };

    const renderBackhaul5G = () => {
      const el = document.getElementById('backhaul-5g-chart');
      if (!el) return;
      el.innerHTML = '';

      const order = ['MW', 'UBR', 'FTTH', 'Fiber'];
      const rawData = backhaul.five_g || [];
      const sortedData = [...rawData].sort((a, b) => order.indexOf(a.name) - order.indexOf(b.name));

      const categories = sortedData.map(item => item.name);
      const values = sortedData.map(item => item.value);

      const instance = new window.ApexCharts(el, {
        chart: { type: 'bar', height: 260, toolbar: { show: false }, background: 'transparent' },
        plotOptions: { bar: { horizontal: true, barHeight: '40%', borderRadius: 4, distributed: true } },
        colors: ['#ffd60a', '#e040fb', '#00e5ff', '#00e676'],
        series: [{ name: '5G TWAMP PL', data: values }],
        xaxis: { categories: categories, labels: { style: { colors: '#8f9bb3' } } },
        yaxis: { labels: { style: { colors: '#8f9bb3' } } },
        grid: { borderColor: 'rgba(255,255,255,0.06)' },
        legend: { show: false },
        tooltip: { theme: 'dark' }
      });
      instance.render();
    };

    const renderBackhaul4G = () => {
      const el = document.getElementById('backhaul-4g-chart');
      if (!el) return;
      el.innerHTML = '';

      const order = ['MW', 'UBR', 'Fiber', 'FTTH'];
      const rawData = backhaul.four_g || [];
      const sortedData = [...rawData].sort((a, b) => order.indexOf(a.name) - order.indexOf(b.name));

      const categories = sortedData.map(item => item.name);
      const values = sortedData.map(item => item.value);

      const instance = new window.ApexCharts(el, {
        chart: { type: 'bar', height: 260, toolbar: { show: false }, background: 'transparent' },
        plotOptions: { bar: { horizontal: true, barHeight: '40%', borderRadius: 4, distributed: true } },
        colors: ['#ffd60a', '#e040fb', '#00e676', '#00e5ff'],
        series: [{ name: '4G TWAMP PL', data: values }],
        xaxis: { categories: categories, labels: { style: { colors: '#8f9bb3' } } },
        yaxis: { labels: { style: { colors: '#8f9bb3' } } },
        grid: { borderColor: 'rgba(255,255,255,0.06)' },
        legend: { show: false },
        tooltip: { theme: 'dark' }
      });
      instance.render();
    };

    renderTrend7Days();
    renderTrendWow();
    renderBackhaul5G();
    renderBackhaul4G();
  }, [trend7Days, trendWow, backhaul, loading]);

  const formatDate = (val) => {
    if (!val) return '—';
    const d = new Date(val);
    if (isNaN(d.getTime())) return val;
    const day = d.getDate().toString().padStart(2, '0');
    const month = d.toLocaleString('en-US', { month: 'short' });
    const year = d.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const formatNumber = (val) => {
    if (val === null || val === undefined || val === '') return '0';
    return Number(val).toLocaleString();
  };

  const techColor = (tech) => {
    if (!tech) return '#8f9bb3';
    const t = tech.toLowerCase();
    if (t.includes('5g')) return '#e040fb';
    if (t.includes('voice')) return '#0062ff';
    return '#ff6b35';
  };

  const updateTopSitesFilters = (updates) => {
    setTopSitesFilters((prev) => ({
      ...prev,
      ...updates,
      page: updates.page !== undefined ? updates.page : 1,
    }));
  };

  const resetTopSitesFilters = () => {
    setTopSitesFilters(DEFAULT_TOP_SITES_FILTERS);
    setShowRecentTopSiteSearches(false);
  };

  const saveRecentTopSiteSearch = (value) => {
    const normalizedValue = (value || '').trim();
    if (!normalizedValue) {
      return;
    }

    setRecentTopSiteSearches((prev) => {
      const next = [normalizedValue, ...prev.filter((item) => item.toLowerCase() !== normalizedValue.toLowerCase())].slice(0, 5);
      localStorage.setItem(TOP_SITES_RECENT_SEARCHES_KEY, JSON.stringify(next));
      return next;
    });
  };

  const topSitesPage = topSitesMeta.page || 1;
  const topSitesTotalPages = topSitesMeta.total_pages || 0;
  const topSitesPageSize = topSitesMeta.page_size || topSitesFilters.page_size;
  const maxPlCount = topSites.reduce((max, row) => Math.max(max, Number(row.pl_count) || 0), 0);

  return html`
    <div style=${{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
      ${error && html`<div className="error-banner">${error}</div>`}

      ${loading ? html`
        <div style=${{ textAlign: 'center', padding: '120px 0', color: '#8f9bb3' }}>
          <div className="spinner" style=${{ margin: '0 auto 16px auto', width: '36px', height: '36px' }}></div>
          <p style=${{ fontSize: '15px' }}>Retrieving daily TWAMP analytics...</p>
        </div>
      ` : html`
        <${React.Fragment}>
          <!-- Top Row KPI Cards -->
          <div style=${{ display: 'flex', gap: '24px', flexWrap: 'wrap' }}>
            ${summary?.data_start_date && summary?.data_end_date && (summary.data_start_date !== startDate || summary.data_end_date !== endDate) ? html`
              <div style=${{ width: '100%', padding: '10px 16px', borderRadius: '8px', backgroundColor: 'rgba(255, 214, 10, 0.08)', border: '1px solid rgba(255,214,10,0.25)', color: '#ffd60a', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span>⚠️</span>
                <span>No data found for the selected date range. Showing data for <strong>${formatDate(summary.data_start_date)}</strong> – <strong>${formatDate(summary.data_end_date)}</strong> instead.</span>
              </div>
            ` : null}
            <!-- Voice KPI Card -->
            <div className="glass-panel" style=${{ flex: 1, minWidth: '280px', padding: '24px', display: 'flex', alignItems: 'center', gap: '20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <div style=${{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'rgba(0, 98, 255, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#0062ff', fontSize: '24px' }}>
                🏢
              </div>
              <div>
                <div style=${{ fontSize: '36px', fontWeight: '800', color: '#0062ff', lineHeight: 1 }}>${formatNumber(summary?.voice_count)}</div>
                <div style=${{ fontSize: '14px', color: '#8f9bb3', fontWeight: '600', marginTop: '6px' }}>4G Voice Affected Sites</div>
                <div style=${{ fontSize: '11px', color: '#0062ff', marginTop: '2px', fontWeight: '500' }}>PL Count ≥ 14 min</div>
                <div style=${{ fontSize: '12px', color: '#00e676', marginTop: '4px', fontWeight: '600' }}>
                  ↗ ${summary?.voice_count_change ?? 0}% <span style=${{ color: '#8f9bb3', fontWeight: 'normal' }}>vs last 7 days</span>
                </div>
              </div>
            </div>

            <!-- 5G KPI Card -->
            <div className="glass-panel" style=${{ flex: 1, minWidth: '280px', padding: '24px', display: 'flex', alignItems: 'center', gap: '20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <div style=${{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'rgba(224, 64, 251, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#e040fb', fontSize: '24px' }}>
                🏢
              </div>
              <div>
                <div style=${{ fontSize: '36px', fontWeight: '800', color: '#e040fb', lineHeight: 1 }}>${formatNumber(summary?.five_g_count)}</div>
                <div style=${{ fontSize: '14px', color: '#8f9bb3', fontWeight: '600', marginTop: '6px' }}>5G Data Affected Sites</div>
                <div style=${{ fontSize: '11px', color: '#e040fb', marginTop: '2px', fontWeight: '500' }}>PL Count ≥ 60 min</div>
                <div style=${{ fontSize: '12px', color: '#00e676', marginTop: '4px', fontWeight: '600' }}>
                  ↗ ${summary?.five_g_count_change ?? 0}% <span style=${{ color: '#8f9bb3', fontWeight: 'normal' }}>vs last 7 days</span>
                </div>
              </div>
            </div>

            <!-- 4G KPI Card -->
            <div className="glass-panel" style=${{ flex: 1, minWidth: '280px', padding: '24px', display: 'flex', alignItems: 'center', gap: '20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <div style=${{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'rgba(255, 107, 53, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ff6b35', fontSize: '24px' }}>
                🏢
              </div>
              <div>
                <div style=${{ fontSize: '36px', fontWeight: '800', color: '#ff6b35', lineHeight: 1 }}>${formatNumber(summary?.four_g_count)}</div>
                <div style=${{ fontSize: '14px', color: '#8f9bb3', fontWeight: '600', marginTop: '6px' }}>4G Data Affected Sites</div>
                <div style=${{ fontSize: '11px', color: '#ff6b35', marginTop: '2px', fontWeight: '500' }}>PL Count ≥ 60 min</div>
                <div style=${{ fontSize: '12px', color: '#00e676', marginTop: '4px', fontWeight: '600' }}>
                  ↗ ${summary?.four_g_count_change ?? 0}% <span style=${{ color: '#8f9bb3', fontWeight: 'normal' }}>vs last 7 days</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Circle Breakdown Section -->
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
            ${circleBreakdown.map(cb => html`
              <div key=${cb.circle_code} className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
                <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div>
                    <h3 style=${{ margin: 0, fontSize: '16px', fontWeight: '700', color: '#fff' }}>${cb.circle}</h3>
                    <p style=${{ margin: '4px 0 0 0', fontSize: '12px', color: '#8f9bb3' }}>Threshold-based Affected Sites</p>
                  </div>
                </div>
                <div style=${{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
                  <div style=${{ background: 'rgba(0,98,255,0.1)', borderRadius: '8px', padding: '12px', textAlign: 'center', border: '1px solid rgba(0,98,255,0.2)' }}>
                    <div style=${{ fontSize: '10px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase', marginBottom: '4px' }}>4G Voice Sites</div>
                    <div style=${{ fontSize: '20px', fontWeight: '800', color: '#0062ff' }}>${formatNumber(cb.voice_pl)}</div>
                    <div style=${{ fontSize: '9px', color: '#0062ff', marginTop: '2px', fontWeight: '500' }}>PL ≥ 14 min</div>
                  </div>
                  <div style=${{ background: 'rgba(255,107,53,0.1)', borderRadius: '8px', padding: '12px', textAlign: 'center', border: '1px solid rgba(255,107,53,0.2)' }}>
                    <div style=${{ fontSize: '10px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase', marginBottom: '4px' }}>4G Data Sites</div>
                    <div style=${{ fontSize: '20px', fontWeight: '800', color: '#ff6b35' }}>${formatNumber(cb.four_g_pl)}</div>
                    <div style=${{ fontSize: '9px', color: '#ff6b35', marginTop: '2px', fontWeight: '500' }}>PL ≥ 60 min</div>
                  </div>
                  <div style=${{ background: 'rgba(224,64,251,0.1)', borderRadius: '8px', padding: '12px', textAlign: 'center', border: '1px solid rgba(224,64,251,0.2)' }}>
                    <div style=${{ fontSize: '10px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase', marginBottom: '4px' }}>5G Data Sites</div>
                    <div style=${{ fontSize: '20px', fontWeight: '800', color: '#e040fb' }}>${formatNumber(cb.five_g_pl)}</div>
                    <div style=${{ fontSize: '9px', color: '#e040fb', marginTop: '2px', fontWeight: '500' }}>PL ≥ 60 min</div>
                  </div>
                </div>
                <div style=${{ marginTop: '16px', display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                  <span style=${{ fontSize: '12px', color: '#8f9bb3' }}>Total Affected Sites</span>
                  <span style=${{ fontSize: '14px', fontWeight: '700', color: '#fff' }}>${formatNumber(cb.total_pl_count)}</span>
                </div>
                <div style=${{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style=${{ fontSize: '12px', color: '#8f9bb3' }}>Total PL Hours</span>
                  <span style=${{ fontSize: '14px', fontWeight: '700', color: '#fff' }}>${formatNumber(cb.total_pl_hours)} hrs</span>
                </div>
              </div>
            `)}
          </div>

          <!-- Charts Row 1: 7-Days Grouped Bar & WoW Area Chart -->
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '24px' }}>
            <div className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <h3 style=${{ fontSize: '15px', fontWeight: '700', marginBottom: '16px', color: '#fff' }}>TWAMP PL - 7 days Trend</h3>
              <div id="trend-7days-chart"></div>
            </div>
            <div className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <h3 style=${{ fontSize: '15px', fontWeight: '700', marginBottom: '16px', color: '#fff' }}>TWAMP PL Trend (W-o-W)</h3>
              <div id="trend-wow-chart"></div>
            </div>
          </div>

          <!-- Charts Row 2: 5G Backhaul & 4G Backhaul -->
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '24px' }}>
            <div className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <h3 style=${{ fontSize: '15px', fontWeight: '700', marginBottom: '16px', color: '#fff' }}>5G TWAMP PL by Backhaul Type</h3>
              <div id="backhaul-5g-chart"></div>
            </div>
            <div className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
              <h3 style=${{ fontSize: '15px', fontWeight: '700', marginBottom: '16px', color: '#fff' }}>4G TWAMP PL by Backhaul Type</h3>
              <div id="backhaul-4g-chart"></div>
            </div>
          </div>

          <!-- Top Sites with Packet Loss Threshold Table -->
          <div className="glass-panel" style=${{ padding: '24px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}>
            <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', gap: '12px', flexWrap: 'wrap' }}>
              <div>
                <h3 style=${{ margin: 0, fontSize: '16px', fontWeight: '700', color: '#fff' }}>Top Sites — Packet Loss</h3>
                <p style=${{ margin: '4px 0 0 0', fontSize: '12px', color: '#8f9bb3' }}>Server-side PL Count threshold filtering, with separate rows per technology and Site ID fallback display.</p>
              </div>
              <div style=${{ padding: '4px 12px', borderRadius: '20px', backgroundColor: 'rgba(255, 214, 10, 0.12)', border: '1px solid rgba(255,214,10,0.3)', color: '#ffd60a', fontSize: '12px', fontWeight: '600' }}>
                Total ${topSitesMeta.total_records || 0}
              </div>
            </div>

            <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', marginBottom: '16px' }}>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Site ID / Site Name</label>
                <div style=${{ position: 'relative' }}>
                  <input
                    type="text"
                    value=${topSitesFilters.site_query}
                    onFocus=${() => setShowRecentTopSiteSearches(true)}
                    onBlur=${() => {
        saveRecentTopSiteSearch(topSitesFilters.site_query);
        setTimeout(() => setShowRecentTopSiteSearches(false), 200);
      }}
                    onKeyDown=${(event) => {
        if (event.key === 'Enter') {
          saveRecentTopSiteSearch(topSitesFilters.site_query);
        }
        if (event.key === 'Escape') {
          setShowRecentTopSiteSearches(false);
        }
      }}
                    onChange=${(e) => updateTopSitesFilters({ site_query: e.target.value })}
                    placeholder="Search site id, name or pop"
                    style=${{ width: '100%', height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}
                  />
                  ${showRecentTopSiteSearches && recentTopSiteSearches.length > 0 && html`
                    <div style=${{ position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 120, backgroundColor: '#1a1f2c', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '8px', marginTop: '4px', maxHeight: '180px', overflowY: 'auto', boxShadow: '0 6px 20px rgba(0,0,0,0.35)' }}>
                      <div style=${{ padding: '6px 10px', fontSize: '10px', color: '#8f9bb3', borderBottom: '1px solid rgba(255,255,255,0.05)', fontWeight: '600' }}>
                        RECENT SEARCHES
                      </div>
                      ${recentTopSiteSearches.map((item) => html`
                        <div
                          key=${item}
                          onMouseDown=${(event) => {
          event.preventDefault();
          updateTopSitesFilters({ site_query: item });
          saveRecentTopSiteSearch(item);
          setShowRecentTopSiteSearches(false);
        }}
                          style=${{ padding: '8px 10px', fontSize: '12px', cursor: 'pointer', color: '#fff' }}
                        >
                          🕒 ${item}
                        </div>
                      `)}
                    </div>
                  `}
                </div>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Technology</label>
                <select value=${topSitesFilters.technology} onChange=${(e) => updateTopSitesFilters({ technology: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="All">All</option>
                  <option value="4G_Data">4G Data</option>
                  <option value="5G_Data">5G Data</option>
                  <option value="4G_Voice">4G Voice</option>
                </select>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Backhaul</label>
                <select value=${topSitesFilters.backhaul || 'All'} onChange=${(e) => updateTopSitesFilters({ backhaul: e.target.value === 'All' ? '' : e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="All">All</option>
                  ${TOP_SITES_BACKHAUL_OPTIONS.map((option) => html`<option key=${option} value=${option}>${option}</option>`)}
                </select>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Report Date</label>
                <input type="date" value=${topSitesFilters.report_date} onChange=${(e) => updateTopSitesFilters({ report_date: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }} />
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Site ID Status</label>
                <select value=${topSitesFilters.site_id_status} onChange=${(e) => updateTopSitesFilters({ site_id_status: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="All">All</option>
                  <option value="Found">Found</option>
                  <option value="Not Found">Not Found</option>
                </select>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Sort By</label>
                <select value=${topSitesFilters.sort_by} onChange=${(e) => updateTopSitesFilters({ sort_by: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="pl_count">PL Count</option>
                  <option value="site_id">Site ID</option>
                  <option value="technology">Technology</option>
                  <option value="report_date">Report Date</option>
                </select>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Sort Direction</label>
                <select value=${topSitesFilters.sort_dir} onChange=${(e) => updateTopSitesFilters({ sort_dir: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="desc">Descending</option>
                  <option value="asc">Ascending</option>
                </select>
              </div>
              <div style=${{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style=${{ fontSize: '12px', color: '#8f9bb3', fontWeight: '600' }}>Rows Per Page</label>
                <select value=${topSitesFilters.page_size} onChange=${(e) => updateTopSitesFilters({ page_size: e.target.value })} style=${{ height: '38px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', outline: 'none' }}>
                  <option value="25">25</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                  <option value="All">All</option>
                </select>
              </div>
            </div>

            <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
              <div style=${{ display: 'flex', gap: '12px', alignItems: 'center', color: '#8f9bb3', fontSize: '12px', flexWrap: 'wrap' }}>
                <span><strong style=${{ color: '#fff' }}>Total Records:</strong> ${topSitesMeta.total_records || 0}</span>
                <span><strong style=${{ color: '#fff' }}>Current Page:</strong> ${topSitesMeta.total_pages === 0 ? 0 : topSitesPage} / ${topSitesTotalPages}</span>
                <span><strong style=${{ color: '#fff' }}>Page Size:</strong> ${topSitesPageSize}</span>
              </div>
              <button type="button" onClick=${resetTopSitesFilters} style=${{ height: '38px', padding: '0 14px', borderRadius: '8px', border: '1px solid rgba(255,214,10,0.28)', backgroundColor: 'rgba(255,214,10,0.1)', color: '#ffd60a', cursor: 'pointer', fontWeight: '600' }}>
                Reset Filters
              </button>
            </div>

            ${topSitesLoading ? html`
              <div style=${{ textAlign: 'center', padding: '40px 0', color: '#8f9bb3' }}>
                <div className="spinner" style=${{ margin: '0 auto 14px auto', width: '32px', height: '32px' }}></div>
                <p>Loading Top Sites packet loss rows...</p>
              </div>
            ` : topSitesError ? html`
              <div className="error-banner">${topSitesError}</div>
            ` : topSites.length === 0 ? html`
              <div style=${{ textAlign: 'center', padding: '40px 0', color: '#8f9bb3' }}>
                <div style=${{ fontSize: '32px', marginBottom: '8px' }}>🎯</div>
                <p>No qualifying packet loss sites found for the selected filters.</p>
              </div>
            ` : html`
              <div className="custom-table-container">
                <table className="custom-table" style=${{ minWidth: '820px' }}>
                  <thead>
                    <tr>
                      <th style=${{ width: '70px', textAlign: 'center' }}>Rank</th>
                      <th style=${{ minWidth: '150px' }}>Site ID</th>
                      <th style=${{ minWidth: '120px' }}>POP Name</th>
                      <th style=${{ minWidth: '100px' }}>Technology</th>
                      <th style=${{ minWidth: '100px' }}>Backhaul</th>
                      <th style=${{ minWidth: '90px', textAlign: 'right' }}>PL Count</th>
                      <th style=${{ minWidth: '120px' }}>Report Date</th>
                      <th style=${{ minWidth: '160px' }}>Severity Bar</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${topSites.map((site, idx) => {
          const plCount = Number(site.pl_count) || 0;
          const severityWidth = maxPlCount > 0 ? Math.round((plCount / maxPlCount) * 100) : 0;
          const rowSiteName = site.site_name || site.site_id || '';
          const rowSiteId = site.site_id_raw || '';
          return html`
                        <tr
                          key=${site.record_id || `${site.site_id}-${site.report_date}-${idx}`}
                          style=${{ cursor: 'pointer' }}
                          onClick=${() => {
              if (onSiteClick && (rowSiteName || rowSiteId)) {
                onSiteClick({ siteName: rowSiteName, siteId: rowSiteId, filters: {}, search: '' });
              }
            }}
                        >
                          <td style=${{ textAlign: 'center', color: idx < 3 ? '#ffd60a' : '#8f9bb3', fontWeight: '700' }}>
                            ${site.rank || idx + 1}
                          </td>
                          <td>
                            <div style=${{ fontWeight: '600', color: 'hsl(var(--primary))' }}>${site.site_id || 'N/A'}</div>
                          </td>
                          <td>
                            <div style=${{ color: '#8f9bb3' }}>${site.pop_name || 'N/A'}</div>
                          </td>
                          <td>
                            <span style=${{
              padding: '2px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: '600',
              backgroundColor: site.technology && site.technology.toLowerCase().includes('5g') ? 'rgba(224,64,251,0.15)' :
                site.technology && site.technology.toLowerCase().includes('voice') ? 'rgba(0,98,255,0.15)' : 'rgba(255,107,53,0.15)',
              color: techColor(site.technology)
            }}>
                              ${site.technology || 'N/A'}
                            </span>
                          </td>
                          <td style=${{ color: '#8f9bb3' }}>${site.backhaul || 'N/A'}</td>
                          <td style=${{ textAlign: 'right', color: '#8f9bb3' }}>${formatNumber(site.pl_count)}</td>
                          <td style=${{ color: '#8f9bb3' }}>${formatDate(site.report_date)}</td>
                          <td>
                            <div style=${{ background: 'rgba(255,255,255,0.06)', borderRadius: '4px', overflow: 'hidden', height: '8px' }}>
                              <div style=${{
              height: '100%',
              borderRadius: '4px',
              width: `${severityWidth}%`,
              background: idx === 0 ? '#ff4444' : idx < 3 ? '#ffd60a' : '#0062ff',
              transition: 'width 0.4s ease'
            }}></div>
                            </div>
                          </td>
                        </tr>
                      `;
        })}
                  </tbody>
                </table>
              </div>
            `}

            <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
              <div style=${{ color: '#8f9bb3', fontSize: '12px' }}>
                Showing ${topSites.length} rows on page ${topSitesMeta.total_pages === 0 ? 0 : topSitesPage}
              </div>
              <div style=${{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                <button type="button" onClick=${() => updateTopSitesFilters({ page: 1 })} disabled=${topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0} style=${{ height: '36px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', cursor: topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0 ? 'not-allowed' : 'pointer', opacity: topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0 ? 0.5 : 1 }}>First</button>
                <button type="button" onClick=${() => updateTopSitesFilters({ page: Math.max(1, topSitesPage - 1) })} disabled=${topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0} style=${{ height: '36px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', cursor: topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0 ? 'not-allowed' : 'pointer', opacity: topSitesMeta.page <= 1 || topSitesMeta.total_pages === 0 ? 0.5 : 1 }}>Previous</button>
                <button type="button" onClick=${() => updateTopSitesFilters({ page: topSitesMeta.total_pages === 0 ? 1 : Math.min(topSitesMeta.total_pages, topSitesPage + 1) })} disabled=${topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages} style=${{ height: '36px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', cursor: topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages ? 'not-allowed' : 'pointer', opacity: topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages ? 0.5 : 1 }}>Next</button>
                <button type="button" onClick=${() => updateTopSitesFilters({ page: topSitesMeta.total_pages || 1 })} disabled=${topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages} style=${{ height: '36px', padding: '0 12px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.12)', backgroundColor: '#1b2234', color: '#fff', cursor: topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages ? 'not-allowed' : 'pointer', opacity: topSitesMeta.total_pages === 0 || topSitesMeta.page >= topSitesMeta.total_pages ? 0.5 : 1 }}>Last</button>
              </div>
            </div>
          </div>

          <!-- Bottom Row 6 KPI Cards -->
          <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '20px' }}>
            <!-- Card 1: Total Reports -->
            <div className="glass-panel" style=${{ padding: '16px 20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style=${{ fontSize: '11px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase' }}>Total Reports</span>
                <span style=${{ fontSize: '16px' }}>📄</span>
              </div>
              <div style=${{ fontSize: '24px', fontWeight: '800', color: '#fff', margin: '4px 0' }}>${formatNumber(summary?.total_reports)}</div>
              <div style=${{ fontSize: '11px', color: '#8f9bb3' }}>All Circles</div>
            </div>

            <!-- Card 2: Latest Report Date -->
            <div className="glass-panel" style=${{ padding: '16px 20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style=${{ fontSize: '11px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase' }}>Latest Report Date</span>
                <span style=${{ fontSize: '16px' }}>📅</span>
              </div>
              <div style=${{ fontSize: '18px', fontWeight: '800', color: '#fff', margin: '8px 0 6px 0', whiteSpace: 'nowrap' }}>${formatDate(summary?.latest_upload_date)}</div>
              <div style=${{ fontSize: '11px', color: '#8f9bb3' }}>All Circles</div>
            </div>

            <!-- Card 3: Total Records -->
            <div className="glass-panel" style=${{ padding: '16px 20px', backgroundColor: '#111622', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style=${{ fontSize: '11px', color: '#8f9bb3', fontWeight: '600', textTransform: 'uppercase' }}>Total Records</span>
                <span style=${{ fontSize: '16px' }}>🗂️</span>
              </div>
              <div style=${{ fontSize: '24px', fontWeight: '800', color: '#fff', margin: '4px 0' }}>${formatNumber(summary?.total_records)}</div>
              <div style=${{ fontSize: '11px', color: '#8f9bb3' }}>All Circles</div>
            </div>
          </div>

        </${React.Fragment}>
      `}
    </div>
  `;
}
