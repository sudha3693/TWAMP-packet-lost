import React, { useEffect, useState } from 'react';
import html from '../html.js';
import DashboardCard from '../components/DashboardCard.js';
import DashboardFilterPanel from '../components/DashboardFilterPanel.js';

export default function DashboardLayout({ activeTab, setActiveTab }) {
  const [summary, setSummary] = useState(null);
  const [filters, setFilters] = useState({
    circle: 'All',
    technology: 'All',
    connectionType: 'All',
    siteId: 'All',
    pop: 'All'
  });
  const menuItems = [
    { key: 'home', label: 'Dashboard' },
    { key: 'packet_loss_reports', label: 'Packet Loss Reports' },
    { key: 'packet_loss_history', label: 'Packet Loss History' },
    { key: 'five_g', label: '5G Import' },
    { key: 'reports', label: 'Reports' },
    { key: 'settings', label: 'Settings' }
  ];

  useEffect(() => {
    let isMounted = true;

    async function loadSummary() {
      try {
        const response = await fetch('/api/dashboard/summary');
        if (!response.ok) {
          throw new Error('Failed to load dashboard summary');
        }
        const data = await response.json();
        if (isMounted) {
          setSummary(data);
        }
      } catch (error) {
        console.error('[Dashboard] Failed to load summary', error);
        if (isMounted) {
          setSummary(null);
        }
      }
    }

    loadSummary();

    return () => {
      isMounted = false;
    };
  }, []);

  const formatNumber = (value) => {
    if (value === null || value === undefined || value === '') {
      return '—';
    }
    return Number(value).toLocaleString(undefined, { maximumFractionDigits: 2 });
  };

  const formatDate = (value) => {
    if (!value) {
      return '—';
    }
    const parsedDate = new Date(value);
    if (Number.isNaN(parsedDate.getTime())) {
      return value;
    }
    return parsedDate.toLocaleDateString();
  };

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleFilterReset = () => {
    setFilters({
      circle: 'All',
      technology: 'All',
      connectionType: 'All',
      siteId: 'All',
      pop: 'All'
    });
  };

  return html`
    <div className="dashboard-shell">
      <aside className="sidebar">
        <div className="sidebar__brand">
          <div className="sidebar__brand-icon">N</div>
          <div>
            <h2>Network Ops</h2>
            <p>Packet Loss Center</p>
          </div>
        </div>

        <nav className="sidebar__nav">
          ${menuItems.map((item) => html`
            <a
              href="javascript:void(0)"
              className=${`sidebar__link ${activeTab === item.key ? 'active' : ''}`}
              onClick=${(e) => { e.preventDefault(); setActiveTab(item.key); }}
            >
              ${item.label}
            </a>
          `)}
        </nav>
      </aside>

      <div className="dashboard-content">
        <header className="topbar">
          <div>
            <p className="eyebrow">Operations</p>
            <h1>${menuItems.find((item) => item.key === activeTab)?.label || 'Dashboard'}</h1>
          </div>
          <div className="topbar__actions">
            <button className="topbar__icon" type="button">🔔</button>
            <div className="topbar__profile">
              <div className="topbar__avatar">SU</div>
              <div>
                <strong>Super User</strong>
                <p>Admin</p>
              </div>
            </div>
          </div>
        </header>

        <section className="layout-grid">
          <${DashboardFilterPanel}
            filters=${filters}
            onFilterChange=${handleFilterChange}
            onApply=${() => {}}
            onReset=${handleFilterReset}
            summaryText="Adjust dashboard data filters without changing the cards."
          />

          <div className="panel-card panel-card--hero">
            <h3>${menuItems.find((item) => item.key === activeTab)?.label || 'Dashboard'}</h3>
            <p>Modern enterprise dashboard layout for packet loss monitoring.</p>
          </div>

          <${DashboardCard} title="Voice Packet Loss" value=${summary ? formatNumber(summary.voice_count) : '—'} subtitle="Live data" icon="📞" tone="primary" />
          <${DashboardCard} title="5G Packet Loss" value=${summary ? formatNumber(summary.five_g_count) : '—'} subtitle="Live data" icon="📡" tone="success" />
          <${DashboardCard} title="4G Packet Loss" value=${summary ? formatNumber(summary.four_g_count) : '—'} subtitle="Live data" icon="🌐" tone="primary" />
          <${DashboardCard} title="Latest Upload" value=${summary ? formatDate(summary.latest_upload_date) : '—'} subtitle="Live data" icon="📅" tone="success" />
          <${DashboardCard} title="Total Reports" value=${summary ? formatNumber(summary.total_reports) : '—'} subtitle="Live data" icon="📁" tone="primary" />
          <${DashboardCard} title="Total Records" value=${summary ? formatNumber(summary.total_records) : '—'} subtitle="Live data" icon="🗂️" tone="danger" />

          <div className="panel-card">
            <h3>Workspace</h3>
            <p>Responsive content area prepared for future analytics widgets.</p>
          </div>
          <div className="panel-card">
            <h3>Activity</h3>
            <p>Structural layout only — no charts, cards, or API calls.</p>
          </div>
          <div className="panel-card">
            <h3>Alerts</h3>
            <p>Empty placeholder section for upcoming dashboard modules.</p>
          </div>
        </section>
      </div>
    </div>
  `;
}
