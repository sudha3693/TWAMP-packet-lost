import React, { useState, useEffect, useRef } from 'react';
import html from '../html.js';
import { api } from '../api.js';
import PacketLossFilterPanel from '../components/PacketLossFilterPanel.js';
import usePacketLossFilters from '../hooks/usePacketLossFilters.js';

export default function PacketLoss({ onSiteClick }) {
  const [reports, setReports] = useState([]);
  const [loadingReports, setLoadingReports] = useState(true);
  const [selectedReport, setSelectedReport] = useState(null);
  const [reportData, setReportData] = useState([]);
  const [totalRows, setTotalRows] = useState(0);
  const [loadingData, setLoadingData] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [expandedRowId, setExpandedRowId] = useState(null);

  const { filters, setFilter, resetFilters, normalizedFilters } = usePacketLossFilters();
  const [filterOptions, setFilterOptions] = useState({
    pop_names: [],
    connection_types: [],
    technologies: [],
    pl_counts: []
  });
  const [recentSiteIds, setRecentSiteIds] = useState([]);
  const [showRecentDropdown, setShowRecentDropdown] = useState(false);
  const [filterResetKey, setFilterResetKey] = useState(0);

  const fileInputRef = useRef(null);
  const pageSize = 10;

  // Load search history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('recent_site_ids');
    if (saved) {
      try {
        setRecentSiteIds(JSON.parse(saved));
      } catch (_) {}
    }
  }, []);

  // Load the list of all reports
  const loadReports = async () => {
    setLoadingReports(true);
    setError('');
    try {
      const list = await api.getPacketLossReports();
      setReports(list);
    } catch (err) {
      setError('Could not connect to the backend server. Please verify the FastAPI service is running.');
    } finally {
      setLoadingReports(false);
    }
  };

  // Load packet loss rows for the selected report
  const loadReportData = async (reportId, page = 1, searchQuery = '', activeFilters = normalizedFilters) => {
    setLoadingData(true);
    setExpandedRowId(null);
    try {
      const res = await api.getPacketLossReportData(reportId, searchQuery, (page - 1) * pageSize, pageSize, activeFilters);
      setReportData(res.rows || []);
      setTotalRows(res.total || 0);
    } catch (err) {
      setError(`Failed to retrieve report details: ${err.message}`);
    } finally {
      setLoadingData(false);
    }
  };

  // Load unique filter options for the selects
  const loadFilterOptions = async (reportId) => {
    try {
      const options = await api.getPacketLossFilterOptions(reportId);
      setFilterOptions(options || { pop_names: [], connection_types: [], technologies: [], pl_counts: [] });
    } catch (err) {
      console.error("Failed to load filter options:", err);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  useEffect(() => {
    if (selectedReport) {
      loadReportData(selectedReport.id, currentPage, search, normalizedFilters);
    }
  }, [selectedReport, currentPage, search, normalizedFilters]);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (selectedReport) {
      setCurrentPage(1);
      loadReportData(selectedReport.id, 1, search, filters);
    }
  };

  const handleClearSearch = () => {
    setSearch('');
    if (selectedReport) {
      setCurrentPage(1);
      loadReportData(selectedReport.id, 1, '', filters);
    }
  };

  const handleFilterSubmit = () => {
    if (selectedReport) {
      const normalizedSiteId = normalizedFilters.siteId;
      if (normalizedSiteId) {
        const updatedRecent = [normalizedSiteId, ...recentSiteIds.filter(x => x.toLowerCase() !== normalizedSiteId.toLowerCase())].slice(0, 5);
        setRecentSiteIds(updatedRecent);
        localStorage.setItem('recent_site_ids', JSON.stringify(updatedRecent));
      }
      setCurrentPage(1);
      loadReportData(selectedReport.id, 1, search, normalizedFilters);
    }
  };

  const handleResetFilters = () => {
    resetFilters();
    setSearch('');
    setCurrentPage(1);
    setShowRecentDropdown(false);
    setFilterResetKey((value) => value + 1);
    if (selectedReport) {
      loadReportData(selectedReport.id, 1, '', {
        siteId: '',
        popName: '',
        connectionType: '',
        technology: '',
        plCount: ''
      });
    }
  };

  const handleUploadFile = async (file) => {
    if (!file) return;
    if (!file.name.endsWith('.xlsx')) {
      setError('Only Excel files (.xlsx) are supported.');
      setMessage('');
      return;
    }

    setUploading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.uploadPacketLossData(formData);
      setMessage(res.message || 'Packet loss report uploaded successfully.');
      loadReports();
    } catch (err) {
      setError(err.message || 'Failed to upload packet loss report.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files[0]);
    }
  };

  const onButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDeleteReport = async (id, e) => {
    e.stopPropagation(); // Prevent opening report
    if (!confirm('Are you sure you want to delete this packet loss report? This will delete all its rows.')) return;
    try {
      await api.deletePacketLossReport(id);
      setReports(reports.filter((r) => r.id !== id));
      if (selectedReport && selectedReport.id === id) {
        setSelectedReport(null);
        setReportData([]);
      }
      setMessage('Report deleted successfully.');
    } catch (err) {
      alert(`Failed to delete report: ${err.message}`);
    }
  };

  const handleClearAllReports = async () => {
    if (!confirm('Are you sure you want to delete ALL packet loss reports? This will wipe out all packet loss tables.')) return;
    try {
      await api.deleteAllPacketLossReports();
      setReports([]);
      setSelectedReport(null);
      setReportData([]);
      setMessage('All packet loss reports deleted.');
    } catch (err) {
      alert(`Failed to clear reports: ${err.message}`);
    }
  };

  const handleViewReport = (report) => {
    setSelectedReport(report);
    setCurrentPage(1);
    setSearch('');
    resetFilters();
    setFilterResetKey((value) => value + 1);
    loadFilterOptions(report.id);
  };

  const handleBackToList = () => {
    setSelectedReport(null);
    setReportData([]);
    setTotalRows(0);
    setSearch('');
    resetFilters();
    setFilterResetKey((value) => value + 1);
  };

  const toggleRowExpansion = (rowId) => {
    setExpandedRowId(expandedRowId === rowId ? null : rowId);
  };

  // Helper to parse double percentages/numbers cleanly
  const formatVal = (val) => {
    if (val === null || val === undefined || val === '') return '0';
    const num = parseFloat(val);
    if (!isNaN(num)) {
      return num % 1 === 0 ? num.toString() : num.toFixed(4);
    }
    return val;
  };

  const isSignificantLoss = (pct, cnt) => {
    const p = parseFloat(pct);
    const c = parseInt(cnt);
    return (p > 0) || (c > 0);
  };

  const renderHourlyTimeline = (row) => {
    const hourlyData = Array.from({ length: 24 }, (_, h) => {
      const hStr = h.toString().padStart(2, '0');
      const pctKey = 'rt_packet_loss_' + hStr + '_percent';
      const cntKey = 'packet_loss_' + hStr + '_count';
      const pct = row[pctKey];
      const count = row[cntKey];
      const hasLoss = isSignificantLoss(pct, count);
      const label = hStr + ':00 - ' + (h + 1).toString().padStart(2, '0') + ':00';
      return { h, hStr, pct, count, hasLoss, label };
    });

    return html`
      <div style=${{
        padding: '20px',
        backgroundColor: 'rgba(0, 0, 0, 0.25)',
        borderRadius: 'var(--radius-md)',
        border: '1px solid var(--glass-border)',
        marginTop: '10px',
        marginBottom: '10px'
      }}>
        <h4 style=${{ fontSize: '14px', marginBottom: '12px', fontWeight: '600', color: 'hsl(var(--primary))' }}>
          24-Hour Packet Loss Timeline (Percent and Packet Count)
        </h4>
        <div style=${{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))',
          gap: '10px'
        }}>
          ${hourlyData.map((item) => html`
            <div key=${item.h} style=${{
              padding: '10px',
              borderRadius: '6px',
              border: '1px solid ' + (item.hasLoss ? 'rgba(239, 68, 68, 0.4)' : 'var(--glass-border)'),
              backgroundColor: item.hasLoss ? 'rgba(239, 68, 68, 0.08)' : 'rgba(255, 255, 255, 0.02)',
              textAlign: 'center',
              transition: 'var(--transition-smooth)'
            }}>
              <div style=${{ fontSize: '11px', fontWeight: '600', color: item.hasLoss ? 'hsl(var(--danger))' : 'hsl(var(--text-muted))', marginBottom: '4px' }}>
                ${item.label}
              </div>
              <div style=${{ fontSize: '13px', fontWeight: '500', color: item.hasLoss ? '#ff4d6d' : 'hsl(var(--text-main))' }}>
                Loss: ${formatVal(item.pct)}%
              </div>
              <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', marginTop: '2px' }}>
                Count: ${formatVal(item.count)}
              </div>
            </div>
          `)}
        </div>
      </div>
    `;
  };

  const totalPages = Math.ceil(totalRows / pageSize);

  return html`
    <div>
      <!-- Page Header & Uploader if not viewing details -->
      ${!selectedReport && html`
        <div className="glass-panel" style=${{ marginBottom: '30px' }}>
          <h2 className="list-title" style=${{ marginBottom: '16px' }}>Packet Loss Report Manager</h2>
          <p style=${{ color: 'hsl(var(--text-muted))', fontSize: '15px', marginBottom: '24px', lineHeight: '1.6' }}>
            Upload EXFO 24-Hour Packet Loss reports in Excel (.xlsx) format. The dashboard will register the report by day and circle, and parse all hourly metrics to provide fine-grained analytics.
          </p>

          <!-- Drag & Drop Zone -->
          <div 
            className=${`upload-zone ${dragActive ? 'drag-active' : ''}`}
            onDragEnter=${handleDrag}
            onDragOver=${handleDrag}
            onDragLeave=${handleDrag}
            onDrop=${handleDrop}
            onClick=${onButtonClick}
          >
            <input 
              type="file"
              ref=${fileInputRef}
              style=${{ display: 'none' }}
              onChange=${(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleUploadFile(e.target.files[0]);
                }
              }}
              accept=".xlsx"
            />
            <div className="upload-icon">
              ${uploading ? html`🔄` : html`📥`}
            </div>
            <div className="upload-text">
              ${uploading ? 'Processing & importing EXFO packet loss report...' : 'Drag & drop Excel report here or click to browse'}
            </div>
            <div className="upload-subtext">
              Supports .xlsx EXFO sheets containing Short Name, Circle metadata in cell A1, and 24Hr logs.
            </div>
          </div>

          <!-- Success Banner -->
          ${message && html`
            <div style=${{ 
              color: 'hsl(var(--success))', 
              backgroundColor: 'var(--success-glow)', 
              padding: '12px 16px', 
              borderRadius: 'var(--radius-md)', 
              marginTop: '20px', 
              fontSize: '14px', 
              border: '1px solid rgba(34, 197, 94, 0.2)' 
            }}>
              ✅ <strong>Success:</strong> ${message}
            </div>
          `}

          <!-- Error Banner -->
          ${error && html`
            <div style=${{ 
              color: 'hsl(var(--danger))', 
              backgroundColor: 'var(--danger-glow)', 
              padding: '12px 16px', 
              borderRadius: 'var(--radius-md)', 
              marginTop: '20px', 
              fontSize: '14px', 
              border: '1px solid rgba(244, 63, 94, 0.2)' 
            }}>
              ⚠️ <strong>Error:</strong> ${error}
            </div>
          `}
        </div>

        <!-- Reports Index -->
        <div className="glass-panel">
          <div className="list-header">
            <div>
              <h2 className="list-title">Imported Reports</h2>
              <p style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
                Found <strong>${reports.length}</strong> reports in database.
              </p>
            </div>
            
            ${reports.length > 0 && html`
              <button 
                type="button" 
                className="btn btn-danger btn-sm"
                onClick=${handleClearAllReports}
              >
                Clear All Reports
              </button>
            `}
          </div>

          ${loadingReports ? html`
            <div style=${{ textAlign: 'center', padding: '48px 0', color: '#8f9bb3' }}>
              <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
              <p>Fetching imported reports...</p>
            </div>
          ` : reports.length === 0 ? html`
            <div className="empty-state">
              <div className="empty-icon">📊</div>
              <p>No packet loss reports have been uploaded yet.</p>
            </div>
          ` : html`
            <div className="custom-table-container">
              <table className="custom-table">
                <thead>
                  <tr>
                    <th>Report ID</th>
                    <th>Report Date</th>
                    <th>Circle</th>
                    <th>Total Rows</th>
                    <th>Uploaded At</th>
                    <th style=${{ textAlign: 'center', width: '150px' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${reports.map((report) => html`
                    <tr 
                      key=${report.id} 
                      onClick=${() => handleViewReport(report)}
                      style=${{ cursor: 'pointer', transition: 'var(--transition-smooth)' }}
                      className="report-row-hover"
                    >
                      <td>#${report.id}</td>
                      <td style=${{ fontWeight: '600', color: 'hsl(var(--primary))' }}>
                        📅 ${report.report_date}
                      </td>
                      <td>
                        <span style=${{
                          padding: '3px 8px',
                          borderRadius: '4px',
                          fontSize: '12px',
                          backgroundColor: 'rgba(124, 77, 255, 0.1)',
                          border: '1px solid rgba(124, 77, 255, 0.2)',
                          color: 'hsl(var(--primary))'
                        }}>
                          ${report.circle}
                        </span>
                      </td>
                      <td style=${{ fontWeight: '500' }}>
                        ${report.row_count} rows
                      </td>
                      <td style=${{ color: 'hsl(var(--text-muted))', fontSize: '13px' }}>
                        ${new Date(report.uploaded_at).toLocaleString()}
                      </td>
                      <td style=${{ textAlign: 'center' }} onClick=${(e) => e.stopPropagation()}>
                        <div style=${{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                          <button 
                            type="button" 
                            className="btn btn-secondary btn-sm"
                            onClick=${() => handleViewReport(report)}
                            style=${{ padding: '5px 10px', fontSize: '12px' }}
                          >
                            👁️ View Data
                          </button>
                          <button 
                            type="button" 
                            className="item-action-btn delete-btn"
                            onClick=${(e) => handleDeleteReport(report.id, e)}
                            style=${{ padding: '6px' }}
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  `)}
                </tbody>
              </table>
            </div>
          `}
        </div>
      `}

      <!-- Detailed Report Data View -->
      ${selectedReport && html`
        <div className="glass-panel" style=${{ marginBottom: '30px' }}>
          <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px', marginBottom: '20px' }}>
            <div>
              <button 
                type="button" 
                className="btn btn-secondary btn-sm" 
                onClick=${handleBackToList}
                style=${{ marginBottom: '10px' }}
              >
                ⬅️ Back to Reports List
              </button>
              <h2 className="list-title" style=${{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span>Report: ${selectedReport.report_date}</span>
                <span style=${{
                  padding: '4px 10px',
                  borderRadius: '4px',
                  fontSize: '13px',
                  backgroundColor: 'rgba(124, 77, 255, 0.1)',
                  border: '1px solid rgba(124, 77, 255, 0.2)',
                  color: 'hsl(var(--primary))',
                  fontWeight: '500'
                }}>
                  ${selectedReport.circle}
                </span>
              </h2>
              <p style=${{ fontSize: '14px', color: 'hsl(var(--text-muted))', marginTop: '4px' }}>
                Showing packet loss metrics for <strong>${totalRows}</strong> network nodes.
              </p>
            </div>

            <!-- Search Form -->
            <form onSubmit=${handleSearchSubmit} style=${{ display: 'flex', gap: '8px' }}>
              <input 
                type="text" 
                className="form-input" 
                placeholder="Search by Node/Site/POP..." 
                value=${search} 
                onChange=${handleSearchChange}
                style=${{ width: '250px' }}
              />
              <button type="submit" className="btn btn-primary btn-sm">Search</button>
              ${search && html`
                <button type="button" className="btn btn-secondary btn-sm" onClick=${handleClearSearch}>Clear</button>
              `}
            </form>
          </div>

          <${PacketLossFilterPanel}
            filters=${filters}
            setFilter=${setFilter}
            onApply=${handleFilterSubmit}
            onReset=${handleResetFilters}
            filterOptions=${filterOptions}
            searchText=${search}
            onSearchChange=${(value) => setSearch(value)}
            onClearSearch=${() => {
              setSearch('');
              setCurrentPage(1);
              if (selectedReport) {
                loadReportData(selectedReport.id, 1, '', normalizedFilters);
              }
            }}
            resetKey=${filterResetKey}
            recentSiteIds=${recentSiteIds}
            onRecentSiteSelect=${(item) => {
              setFilter('siteId', item);
              setCurrentPage(1);
              if (selectedReport) {
                loadReportData(selectedReport.id, 1, search, { ...normalizedFilters, siteId: item });
              }
            }}
            showRecentDropdown=${showRecentDropdown}
            setShowRecentDropdown=${setShowRecentDropdown}
          />

          ${loadingData ? html`
            <div style=${{ textAlign: 'center', padding: '60px 0', color: '#8f9bb3' }}>
              <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
              <p>Fetching report lines from database...</p>
            </div>
          ` : reportData.length === 0 ? html`
            <div className="empty-state">
              <div className="empty-icon">🔍</div>
              <p>No matching packet loss records found for "${search}".</p>
            </div>
          ` : html`
            <div className="custom-table-container">
              <table className="custom-table" style=${{ minWidth: '900px' }}>
                <thead>
                  <tr>
                    <th style=${{ width: '36px', textAlign: 'center' }}></th>
                    <th style=${{ minWidth: '200px' }}>Site Name</th>
                    <th style=${{ minWidth: '150px' }}>Site ID</th>
                    <th style=${{ minWidth: '100px' }}>Site Type</th>
                    <th style=${{ minWidth: '90px' }}>POP Name</th>
                    <th style=${{ minWidth: '80px' }}>Conn. Type</th>
                    <th style=${{ minWidth: '80px' }}>Technology</th>
                    <th style=${{ minWidth: '100px', textAlign: 'center' }}>PL ≥0.5 Count</th>
                    <th style=${{ minWidth: '60px', textAlign: 'center' }}>Ageing</th>
                    <th style=${{ minWidth: '80px', textAlign: 'center' }}>PL Hours</th>
                  </tr>
                </thead>
                <tbody>
                  ${reportData.map((row) => {
                    const isExpanded = expandedRowId === row.id;
                    const hasLoss = parseInt(row.no_of_hrs_session_having_pl_05_90_count) > 0;
                    return html`
                      <${React.Fragment} key=${row.id}>
                        <tr 
                          onClick=${() => toggleRowExpansion(row.id)}
                          style=${{ cursor: 'pointer' }}
                        >
                          <td style=${{ textAlign: 'center', width: '36px' }}>
                            <span style=${{ 
                              display: 'inline-block', 
                              transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
                              transition: 'transform 0.2s',
                              color: 'hsl(var(--primary))',
                              fontWeight: 'bold'
                            }}>
                              ▶
                            </span>
                          </td>
                          <td>
                            <div style=${{ fontWeight: '600', color: 'hsl(var(--text-main))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '280px' }} title=${row.site_name || row.short_name || 'N/A'}>
                              ${row.site_name ? html`
                                <a 
                                  href="#"
                                  onClick=${(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (onSiteClick) {
                                      onSiteClick({ 
                                        siteName: row.site_name, 
                                        siteId: row.site_id,
                                        filters: normalizedFilters,
                                        search: search
                                      });
                                    }
                                  }}
                                  style=${{
                                    color: 'hsl(var(--text-main))',
                                    textDecoration: 'underline',
                                    cursor: 'pointer'
                                  }}
                                >
                                  ${row.site_name}
                                </a>
                              ` : (row.short_name || html`<em>N/A</em>`)}
                            </div>
                            <div style=${{ fontSize: '11px', color: 'hsl(var(--text-muted))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '280px' }} title=${row.short_name || 'N/A'}>
                              Short: ${row.short_name || 'N/A'}
                            </div>
                          </td>
                          <td>
                            <div style=${{ fontWeight: '600', color: 'hsl(var(--primary))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '140px' }} title=${row.site_id || 'N/A'}>
                              ${row.site_id ? html`
                                <a 
                                  href="#"
                                  onClick=${(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if (onSiteClick) {
                                      onSiteClick({ 
                                        siteName: row.site_name || row.short_name, 
                                        siteId: row.site_id,
                                        filters: normalizedFilters,
                                        search: search
                                      });
                                    }
                                  }}
                                  style=${{
                                    fontWeight: '600',
                                    color: 'hsl(var(--primary))',
                                    textDecoration: 'underline',
                                    cursor: 'pointer'
                                  }}
                                >
                                  ${row.site_id}
                                </a>
                              ` : html`<span style=${{ color: 'hsl(var(--text-muted))', fontStyle: 'italic' }}>N/A</span>`}
                            </div>
                          </td>
                          <td style=${{ whiteSpace: 'nowrap' }}>
                            ${row.site_type || 'N/A'}
                          </td>
                          <td style=${{ whiteSpace: 'nowrap' }}>
                            ${row.pop_name || html`<em>N/A</em>`}
                          </td>
                          <td style=${{ whiteSpace: 'nowrap' }}>
                            ${row.connection_type || 'N/A'}
                          </td>
                          <td>
                            <span style=${{
                              padding: '2px 6px',
                              borderRadius: '4px',
                              fontSize: '11px',
                              backgroundColor: 'rgba(255, 255, 255, 0.05)',
                              border: '1px solid var(--glass-border)',
                              color: 'hsl(var(--text-muted))',
                              whiteSpace: 'nowrap'
                            }}>
                              ${row.twamp_technology || 'N/A'}
                            </span>
                          </td>
                          <td style=${{ textAlign: 'center', fontWeight: '500', whiteSpace: 'nowrap' }}>
                            ${row.packet_loss_05_90_percent_count || '0'}
                          </td>
                          <td style=${{ textAlign: 'center', fontSize: '13px', whiteSpace: 'nowrap' }}>
                            ${row.packet_loss_ageing || 'N/A'}
                          </td>
                          <td style=${{ textAlign: 'center' }}>
                            <span style=${{
                              padding: '3px 8px',
                              borderRadius: '12px',
                              fontSize: '12px',
                              fontWeight: '600',
                              whiteSpace: 'nowrap',
                              backgroundColor: hasLoss ? 'var(--danger-glow)' : 'rgba(255,255,255,0.02)',
                              border: '1px solid ' + (hasLoss ? 'rgba(244,63,94,0.3)' : 'var(--glass-border)'),
                              color: hasLoss ? 'hsl(var(--danger))' : 'hsl(var(--text-muted))'
                            }}>
                              ${row.no_of_hrs_session_having_pl_05_90_count || '0'} hrs
                            </span>
                          </td>
                        </tr>
                        ${isExpanded && html`
                          <tr>
                            <td colSpan=${10} style=${{ padding: '0', backgroundColor: 'rgba(0,0,0,0.1)' }}>
                              ${renderHourlyTimeline(row)}
                            </td>
                          </tr>
                        `}
                      </${React.Fragment}>
                    `;
                  })}
                </tbody>
              </table>
            </div>

            <!-- Pagination Row -->
            ${totalPages > 1 && html`
              <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '20px' }}>
                <div style=${{ fontSize: '13px', color: 'hsl(var(--text-muted))' }}>
                  Page <strong>${currentPage}</strong> of <strong>${totalPages}</strong> (Total <strong>${totalRows}</strong> records)
                </div>
                <div style=${{ display: 'flex', gap: '8px' }}>
                  <button 
                    type="button" 
                    className="btn btn-secondary btn-sm" 
                    disabled=${currentPage === 1}
                    onClick=${() => setCurrentPage(currentPage - 1)}
                  >
                    Previous
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-secondary btn-sm" 
                    disabled=${currentPage === totalPages}
                    onClick=${() => setCurrentPage(currentPage + 1)}
                  >
                    Next
                  </button>
                </div>
              </div>
            `}
          `}
        </div>
      `}
    </div>
  `;
}
