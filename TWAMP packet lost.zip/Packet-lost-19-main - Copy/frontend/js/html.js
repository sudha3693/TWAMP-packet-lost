import React from 'react';
import htm from 'htm';

/**
 * html tagged template literal pre-bound to React.
 * Allows writing JSX-like markup in standard JS files:
 * e.g. html`<div>Hello, ${name}</div>`
 */
const html = htm.bind(React.createElement);

export default html;
