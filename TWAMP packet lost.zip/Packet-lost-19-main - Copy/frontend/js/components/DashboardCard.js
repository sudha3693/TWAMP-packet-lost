import React from 'react';
import html from '../html.js';

export default function DashboardCard({ title, value, icon, subtitle, tone = 'primary' }) {
  const toneClass = tone === 'danger' ? 'card-danger' : tone === 'success' ? 'card-success' : 'card-primary';
  return html`
    <div className=${`metric-card ${toneClass}`}>
      <div className="metric-card__icon">${icon}</div>
      <div className="metric-card__body">
        <div className="metric-card__title">${title}</div>
        <div className="metric-card__value">${value}</div>
        ${subtitle ? html`<div className="metric-card__subtitle">${subtitle}</div>` : null}
      </div>
    </div>
  `;
}
