import React from 'react';
import html from '../html.js';

export default function SearchBox({ value, onChange, placeholder = 'Search' }) {
  return html`
    <label className="search-box">
      <span>🔎</span>
      <input
        type="text"
        value=${value}
        onChange=${(e) => onChange(e.target.value)}
        placeholder=${placeholder}
      />
    </label>
  `;
}
