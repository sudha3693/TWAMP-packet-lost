import React from 'react';
import html from '../html.js';

export default function EmptyState({ title, message }) {
  return html`
    <div className="empty-state-card">
      <div className="empty-state-card__icon">◌</div>
      <h3>${title}</h3>
      <p>${message}</p>
    </div>
  `;
}
