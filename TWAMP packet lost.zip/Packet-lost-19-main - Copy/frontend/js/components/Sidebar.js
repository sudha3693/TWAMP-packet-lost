import React from 'react';
import html from '../html.js';

export default function Sidebar() {
  return html`
    <aside className="sidebar">
      <div className="sidebar__brand">
        <div className="sidebar__brand-icon">N</div>
        <div>
          <h2>Network Ops</h2>
          <p>Packet loss control center</p>
        </div>
      </div>
      <nav className="sidebar__nav">
        <a href="#" className="sidebar__link active">Dashboard</a>
        <a href="#" className="sidebar__link">Packet Loss Reports</a>
        <a href="#" className="sidebar__link">Packet Loss History</a>
        <a href="#" className="sidebar__link">5G Import</a>
        <a href="#" className="sidebar__link">Upload History</a>
        <a href="#" className="sidebar__link">Reports</a>
        <a href="#" className="sidebar__link">Settings</a>
      </nav>
    </aside>
  `;
}
