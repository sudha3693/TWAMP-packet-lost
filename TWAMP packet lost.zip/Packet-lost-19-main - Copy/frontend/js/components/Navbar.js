import React from 'react';
import html from '../html.js';

const navItems = [
  { key: 'home', label: 'Dashboard' },
  { key: 'packet_loss_reports', label: 'Packet Loss Reports' },
  { key: 'packet_loss_history', label: 'Packet Loss History' },
  { key: 'five_g', label: '5G Import' },
  { key: 'reports', label: 'Reports' },
  { key: 'settings', label: 'Settings' }
];

export default function Navbar({ projectName, activeTab, setActiveTab }) {
  return html`
    <header>
      <div class="container navbar">
        <div class="brand">
          <div class="brand-icon">F</div>
          <span>${projectName}</span>
        </div>

        <nav>
          <ul class="nav-links">
            ${navItems.map((item) => html`
              <li>
                <a
                  href="javascript:void(0)"
                  onClick=${(e) => { e.preventDefault(); setActiveTab(item.key); }}
                  className=${`nav-link ${activeTab === item.key ? 'active' : ''}`}
                >
                  ${item.label}
                </a>
              </li>
            `)}
          </ul>
        </nav>
      </div>
    </header>
  `;
}
