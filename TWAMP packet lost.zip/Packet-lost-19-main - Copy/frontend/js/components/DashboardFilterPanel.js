import React from 'react';
import html from '../html.js';
import SearchableDropdown from './SearchableDropdown.js';

export default function DashboardFilterPanel({
  filters,
  onFilterChange,
  onApply,
  onReset,
  summaryText
}) {
  const circleOptions = ['All', 'Bihar Circle', 'Jharkhand Circle'];
  const technologyOptions = ['All', 'Voice', '4G', '5G'];
  const connectionTypeOptions = ['All', 'Fiber', 'Microwave', 'Satellite'];
  const siteIdOptions = ['ALL', 'SITE-101', 'SITE-202', 'SITE-303'];
  const popOptions = ['All', 'POP-A', 'POP-B', 'POP-C'];

  return html`
    <div className="dashboard-filter-panel">
      <div className="dashboard-filter-panel__header">
        <div>
          <h3>Dashboard Filters</h3>
          <p>${summaryText}</p>
        </div>
        <div className="dashboard-filter-panel__actions">
          <button type="button" className="btn btn-secondary btn-sm" onClick=${onReset}>Reset</button>
          <button type="button" className="btn btn-primary btn-sm" onClick=${onApply}>Apply</button>
        </div>
      </div>

      <div className="dashboard-filter-panel__grid">
        <${SearchableDropdown}
          label="Circle"
          value=${filters.circle}
          options=${circleOptions}
          placeholder="Select circle"
          onChange=${(value) => onFilterChange('circle', value)}
          emptyLabel="No circles available"
        />

        <${SearchableDropdown}
          label="Technology"
          value=${filters.technology}
          options=${technologyOptions}
          placeholder="Select technology"
          onChange=${(value) => onFilterChange('technology', value)}
          emptyLabel="No technologies available"
        />

        <${SearchableDropdown}
          label="Connection Type"
          value=${filters.connectionType}
          options=${connectionTypeOptions}
          placeholder="Select connection type"
          onChange=${(value) => onFilterChange('connectionType', value)}
          emptyLabel="No connection types available"
        />

        <${SearchableDropdown}
          label="Site ID"
          value=${filters.siteId}
          options=${siteIdOptions}
          placeholder="Type or select site ID"
          onChange=${(value) => onFilterChange('siteId', value)}
          emptyLabel="No site IDs available"
        />

        <${SearchableDropdown}
          label="POP"
          value=${filters.pop}
          options=${popOptions}
          placeholder="Type or select POP"
          onChange=${(value) => onFilterChange('pop', value)}
          emptyLabel="No POPs available"
        />
      </div>
    </div>
  `;
}
