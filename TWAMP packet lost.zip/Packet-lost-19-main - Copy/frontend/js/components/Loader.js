import React from 'react';
import html from '../html.js';

export default function Loader({ message = 'Loading dashboard metrics...' }) {
  return html`
    <div className="loader-shell">
      <div className="spinner"></div>
      <p className="loader-text">${message}</p>
    </div>
  `;
}
