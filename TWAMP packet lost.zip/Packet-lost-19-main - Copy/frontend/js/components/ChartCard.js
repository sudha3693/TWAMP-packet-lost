import React from 'react';
import html from '../html.js';

export default function ChartCard({ title, children }) {
  return html`
    <div className="panel-card chart-card">
      <div className="panel-card__header">
        <h3>${title}</h3>
      </div>
      <div className="panel-card__body">${children}</div>
    </div>
  `;
}
