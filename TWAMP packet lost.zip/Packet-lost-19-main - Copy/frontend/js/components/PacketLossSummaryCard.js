import React from 'react';
import html from '../html.js';

export default function PacketLossSummaryCard({ title, latestUploadDate, reportCount, totalRecords, onOpen }) {
  return html`
    <div className="glass-panel" style=${{
      padding: '20px',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--glass-border)',
      background: 'rgba(255,255,255,0.03)',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      minHeight: '200px'
    }}>
      <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style=${{ fontSize: '18px', fontWeight: '600', color: 'hsl(var(--primary))' }}>${title}</h3>
        <span style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))' }}>Historical</span>
      </div>

      <div style=${{ display: 'grid', gap: '8px' }}>
        <div>
          <div style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px' }}>Latest Upload Date</div>
          <div style=${{ fontSize: '15px', fontWeight: '600', color: 'hsl(var(--text-main))' }}>${latestUploadDate || 'No uploads yet'}</div>
        </div>
        <div>
          <div style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px' }}>Total Reports</div>
          <div style=${{ fontSize: '15px', fontWeight: '600', color: 'hsl(var(--text-main))' }}>${reportCount ?? 0}</div>
        </div>
        <div>
          <div style=${{ fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px' }}>Total Records</div>
          <div style=${{ fontSize: '15px', fontWeight: '600', color: 'hsl(var(--text-main))' }}>${totalRecords ?? 0}</div>
        </div>
      </div>

      <button className="btn btn-primary" onClick=${onOpen} style=${{ marginTop: 'auto' }}>
        Open
      </button>
    </div>
  `;
}
