import React, { useState } from 'react';
import html from '../html.js';


export default function ItemList({ items, onEdit, onDelete, loading }) {
  const [search, setSearch] = useState('');

  // Filter items in real time
  const filteredItems = items.filter(item => 
    item.title.toLowerCase().includes(search.toLowerCase()) ||
    (item.description && item.description.toLowerCase().includes(search.toLowerCase()))
  );

  return html`
    <div className="glass-panel">
      <!-- Search and Header Section -->
      <div className="list-header">
        <h2 className="list-title">Items Inventory</h2>
        <input 
          type="text" 
          className="form-input search-bar" 
          placeholder="🔍 Search items..." 
          value=${search} 
          onChange=${(e) => setSearch(e.target.value)}
        />
      </div>

      <!-- Loading State -->
      ${loading && html`
        <div style=${{ textAlign: 'center', padding: '32px 0', color: '#8f9bb3' }}>
          <div className="spinner" style=${{ margin: '0 auto 12px auto', width: '30px', height: '30px' }}></div>
          <p>Fetching records from SQLite database...</p>
        </div>
      `}

      <!-- Empty State -->
      ${!loading && filteredItems.length === 0 && html`
        <div className="empty-state">
          <div className="empty-icon">📂</div>
          <p>${items.length === 0 ? 'SQLite database is currently empty.' : 'No items match your search queries.'}</p>
        </div>
      `}

      <!-- Filtered Items Grid -->
      ${!loading && filteredItems.length > 0 && html`
        <div className="items-grid">
          ${filteredItems.map(item => html`
            <div className="item-card" key=${item.id}>
              <!-- Header info + Action Buttons -->
              <div className="item-card-header">
                <span className="item-title">${item.title}</span>
                <div className="item-actions">
                  <button 
                    type="button"
                    className="item-action-btn edit-btn" 
                    onClick=${() => onEdit(item)}
                    title="Edit Item"
                  >
                    ✏️
                  </button>
                  <button 
                    type="button"
                    className="item-action-btn delete-btn" 
                    onClick=${() => onDelete(item.id)}
                    title="Delete Item"
                  >
                    🗑️
                  </button>
                </div>
              </div>
              
              <!-- Description Text -->
              <p className="item-desc">
                ${item.description || html`<em style=${{ color: '#5b657a' }}>No description provided.</em>`}
              </p>
            </div>
          `)}
        </div>
      `}
    </div>
  `;
}
