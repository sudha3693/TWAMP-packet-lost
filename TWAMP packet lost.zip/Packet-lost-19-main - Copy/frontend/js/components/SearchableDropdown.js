import React, { useEffect, useMemo, useRef, useState } from 'react';
import html from '../html.js';

export default function SearchableDropdown({
  label,
  value,
  options = [],
  placeholder = 'Type or select...',
  onChange,
  resetKey = 0,
  emptyLabel = 'All values'
}) {
  const [inputValue, setInputValue] = useState(value || '');
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef(null);

  useEffect(() => {
    setInputValue(value || '');
  }, [value, resetKey]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredOptions = useMemo(() => {
    const normalizedQuery = (inputValue || '').toString().trim().toLowerCase();
    if (!normalizedQuery) {
      return options;
    }

    return options.filter((option) => String(option).toLowerCase().includes(normalizedQuery));
  }, [inputValue, options]);

  const handleSelect = (option) => {
    const selected = String(option);
    setInputValue(selected);
    setIsOpen(false);
    onChange(selected);
  };

  const handleInputChange = (event) => {
    const nextValue = event.target.value;
    setInputValue(nextValue);
    setIsOpen(true);
    if (!nextValue) {
      onChange('');
    }
  };

  const handleClear = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setInputValue('');
    setIsOpen(false);
    onChange('');
  };

  return html`
    <div ref=${wrapperRef} style=${{ position: 'relative' }}>
      <label style=${{ display: 'block', fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px', fontWeight: '500' }}>
        ${label}
      </label>


      <div
        style=${{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          width: '100%',
          height: '40px',
          padding: '0 12px',
          cursor: 'text',
          backgroundColor: '#1b2234',
          border: '1px solid rgba(255,255,255,0.12)',
          borderRadius: '6px',
          color: '#fff',
          transition: 'border-color 0.2s'
        }}
      >
        <input
          type="text"
          value=${inputValue}
          placeholder=${placeholder}
          onFocus=${() => setIsOpen(true)}
          onChange=${handleInputChange}
          onKeyDown=${(event) => {
            if (event.key === 'Enter' && filteredOptions[0]) {
              event.preventDefault();
              handleSelect(filteredOptions[0]);
            }
            if (event.key === 'Escape') {
              setIsOpen(false);
            }
          }}
          style=${{
            flex: 1,
            border: 'none',
            outline: 'none',
            background: 'transparent',
            color: '#fff',
            fontSize: '14px'
          }}
        />
        ${value ? html`
          <button
            type="button"
            onClick=${handleClear}
            style=${{ border: 'none', background: 'transparent', color: 'hsl(var(--text-muted))', cursor: 'pointer', fontSize: '16px' }}
          >
            ×
          </button>
        ` : null}
      </div>
      ${isOpen && filteredOptions.length > 0 && html`
        <div style=${{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          zIndex: 120,
          backgroundColor: '#1a1f2c',
          border: '1px solid var(--glass-border)',
          borderRadius: '6px',
          marginTop: '4px',
          maxHeight: '180px',
          overflowY: 'auto',
          boxShadow: '0 6px 20px rgba(0,0,0,0.35)'
        }}>
          ${filteredOptions.map((option) => html`
            <div
              key=${option}
              onMouseDown=${(event) => {
                event.preventDefault();
                handleSelect(option);
              }}
              style=${{
                padding: '8px 10px',
                cursor: 'pointer',
                fontSize: '12px',
                color: 'hsl(var(--text-main))',
                backgroundColor: 'transparent'
              }}
            >
              ${option}
            </div>
          `)}
        </div>
      `}
      ${isOpen && filteredOptions.length === 0 && html`
        <div style=${{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          zIndex: 120,
          backgroundColor: '#1a1f2c',
          border: '1px solid var(--glass-border)',
          borderRadius: '6px',
          marginTop: '4px',
          padding: '8px 10px',
          fontSize: '12px',
          color: 'hsl(var(--text-muted))'
        }}>
          ${emptyLabel}
        </div>
      `}
    </div>
  `;
}
