import React from 'react';
import html from '../html.js';

export default function DataTable({ rows, loading, error }) {
  if (loading) {
    return html`<div className="table-empty">Loading history...</div>`;
  }
  if (error) {
    return html`<div className="table-empty">${error}</div>`;
  }
  if (!rows || rows.length === 0) {
    return html`<div className="table-empty">No packet loss history available for the current filters.</div>`;
  }

  return html`
    <div className="table-shell">
      <table className="custom-table">
        <thead>
          <tr>
            <th>Report Date</th>
            <th>Circle</th>
            <th>Site ID</th>
            <th>Site Name</th>
            <th>POP</th>
            <th>Technology</th>
            <th>Connection Type</th>
            <th>PL ≥0.5 Count</th>
            <th>Ageing</th>
            <th>PL Hours</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((row) => html`
            <tr key=${row.id}>
              <td>${row.report_date || '—'}</td>
              <td>${row.circle || '—'}</td>
              <td>${row.site_id || '—'}</td>
              <td>${row.site_name || '—'}</td>
              <td>${row.pop || '—'}</td>
              <td>${row.technology || '—'}</td>
              <td>${row.connection_type || '—'}</td>
              <td>${row.pl_count || '—'}</td>
              <td>${row.aging || '—'}</td>
              <td>${row.pl_hours || '—'}</td>
            </tr>
          `)}
        </tbody>
      </table>
    </div>
  `;
}
