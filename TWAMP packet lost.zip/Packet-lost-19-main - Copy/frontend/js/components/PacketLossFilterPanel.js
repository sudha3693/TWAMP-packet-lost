import React, { useMemo, useState } from 'react';
import html from '../html.js';
import SearchableDropdown from './SearchableDropdown.js';

export default function PacketLossFilterPanel({
  filters,
  setFilter,
  onApply,
  onReset,
  filterOptions,
  searchText,
  onSearchChange,
  onClearSearch,
  resetKey = 0,
  recentSiteIds = [],
  onRecentSiteSelect,
  showRecentDropdown,
  setShowRecentDropdown
}) {
  const [siteInput, setSiteInput] = useState(filters.siteId || '');

  const normalizedRecentSiteIds = useMemo(() => {
    return recentSiteIds.filter(Boolean);
  }, [recentSiteIds]);

  const handleSiteChange = (value) => {
    setSiteInput(value);
    setFilter('siteId', value);
  };

  return html`
    <div className="glass-panel" style=${{
      padding: '16px 20px',
      marginBottom: '24px',
      backgroundColor: 'rgba(255, 255, 255, 0.02)',
      border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-md)'
    }}>
      <h3 style=${{ fontSize: '14px', fontWeight: '600', marginBottom: '12px', color: 'hsl(var(--primary))', display: 'flex', alignItems: 'center', gap: '6px' }}>
        🔍 Search Filters
      </h3>
      <form onSubmit=${(event) => { event.preventDefault(); onApply(); }}>
        <div style=${{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', marginBottom: '16px' }}>
          <div style=${{ position: 'relative' }}>
            <label style=${{ display: 'block', fontSize: '12px', color: 'hsl(var(--text-muted))', marginBottom: '4px', fontWeight: '500' }}>Site ID</label>
            <input
              type="text"
              placeholder="Type Site ID..."
              value=${siteInput}
              onFocus=${() => setShowRecentDropdown(true)}
              onBlur=${() => setTimeout(() => setShowRecentDropdown(false), 200)}
              onChange=${(event) => handleSiteChange(event.target.value)}
              style=${{
                width: '100%',
                height: '40px',
                padding: '0 12px',
                backgroundColor: '#1b2234',
                border: '1px solid rgba(255,255,255,0.12)',
                borderRadius: '6px',
                color: '#fff',
                fontSize: '14px',
                outline: 'none'
              }}
            />
            ${showRecentDropdown && normalizedRecentSiteIds.length > 0 && html`
              <div style=${{
                position: 'absolute',
                top: '100%',
                left: 0,
                right: 0,
                zIndex: 100,
                backgroundColor: '#1a1f2c',
                border: '1px solid var(--glass-border)',
                borderRadius: '4px',
                marginTop: '4px',
                maxHeight: '160px',
                overflowY: 'auto',
                boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
              }}>
                <div style=${{ padding: '6px 10px', fontSize: '10px', color: 'hsl(var(--text-muted))', borderBottom: '1px solid rgba(255,255,255,0.05)', fontWeight: '600' }}>
                  RECENT SEARCHES
                </div>
                ${normalizedRecentSiteIds.map((item) => html`
                  <div
                    key=${item}
                    onMouseDown=${(event) => {
                      event.preventDefault();
                      handleSiteChange(item);
                      onRecentSiteSelect(item);
                    }}
                    style=${{ padding: '8px 10px', fontSize: '12px', cursor: 'pointer', color: 'hsl(var(--text-main))' }}
                  >
                    🕒 ${item}
                  </div>
                `)}
              </div>
            `}
          </div>

          <${SearchableDropdown}
            label="POP Name"
            value=${filters.popName}
            options=${filterOptions.pop_names || []}
            placeholder="Search POP..."
            onChange=${(value) => setFilter('popName', value)}
            resetKey=${resetKey}
          />

          <${SearchableDropdown}
            label="Connection Type"
            value=${filters.connectionType}
            options=${filterOptions.connection_types || []}
            placeholder="Search connection type..."
            onChange=${(value) => setFilter('connectionType', value)}
            resetKey=${resetKey}
          />

          <${SearchableDropdown}
            label="Technology"
            value=${filters.technology}
            options=${filterOptions.technologies || []}
            placeholder="Search technology..."
            onChange=${(value) => setFilter('technology', value)}
            resetKey=${resetKey}
          />

          <${SearchableDropdown}
            label="PL ≥0.5 Count"
            value=${filters.plCount}
            options=${filterOptions.pl_counts || []}
            placeholder="Search PL count..."
            onChange=${(value) => setFilter('plCount', value)}
            resetKey=${resetKey}
          />
        </div>

        <div style=${{ display: 'flex', gap: '8px', justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div style=${{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <input
              type="text"
              placeholder="Search by Node/Site/POP..."
              value=${searchText}
              onChange=${(event) => onSearchChange(event.target.value)}
              style=${{
                width: '260px',
                height: '40px',
                padding: '0 12px',
                backgroundColor: '#1b2234',
                border: '1px solid rgba(255,255,255,0.12)',
                borderRadius: '6px',
                color: '#fff',
                fontSize: '14px',
                outline: 'none'
              }}
            />
            ${searchText ? html`<button type="button" className="btn btn-secondary btn-sm" onClick=${onClearSearch}>Clear Search</button>` : null}
          </div>
          <div style=${{ display: 'flex', gap: '8px' }}>
            <button type="button" className="btn btn-secondary btn-sm" onClick=${onReset}>Reset</button>
            <button type="submit" className="btn btn-primary btn-sm">Apply Filters</button>
          </div>
        </div>
      </form>
    </div>
  `;
}
