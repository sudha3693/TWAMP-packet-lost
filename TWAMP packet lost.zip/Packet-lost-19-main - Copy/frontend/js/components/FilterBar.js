import React from 'react';
import html from '../html.js';

export default function FilterBar({ filters, onChange, onApply, onReset }) {
  return html`
    <div className="filter-panel">
      <div className="filter-grid">
        <label className="filter-field">
          <span>Circle</span>
          <select value=${filters.circle || ''} onChange=${(e) => onChange('circle', e.target.value)}>
            <option value="">All</option>
            <option value="BIH">BIH</option>
            <option value="JHK">JHK</option>
          </select>
        </label>
        <label className="filter-field">
          <span>Date Range</span>
          <div className="range-fields">
            <input type="date" value=${filters.startDate || ''} onChange=${(e) => onChange('startDate', e.target.value)} />
            <input type="date" value=${filters.endDate || ''} onChange=${(e) => onChange('endDate', e.target.value)} />
          </div>
        </label>
        <label className="filter-field">
          <span>Technology</span>
          <select value=${filters.technology || ''} onChange=${(e) => onChange('technology', e.target.value)}>
            <option value="">All</option>
            <option value="4G">4G</option>
            <option value="5G">5G</option>
            <option value="Voice">Voice</option>
          </select>
        </label>
        <label className="filter-field">
          <span>Connection Type</span>
          <select value=${filters.connectionType || ''} onChange=${(e) => onChange('connectionType', e.target.value)}>
            <option value="">All</option>
            <option value="MW">MW</option>
            <option value="UBR">UBR</option>
            <option value="FTTH">FTTH</option>
            <option value="Fiber">Fiber</option>
          </select>
        </label>
        <label className="filter-field">
          <span>Site ID</span>
          <input type="text" value=${filters.siteId || ''} onChange=${(e) => onChange('siteId', e.target.value)} placeholder="Search site ID" />
        </label>
        <label className="filter-field">
          <span>POP</span>
          <input type="text" value=${filters.popName || ''} onChange=${(e) => onChange('popName', e.target.value)} placeholder="Search POP" />
        </label>
      </div>
      <div className="filter-actions">
        <button className="btn btn-primary" onClick=${onApply}>Apply</button>
        <button className="btn btn-secondary" onClick=${onReset}>Reset</button>
      </div>
    </div>
  `;
}
