import React, { useState, useEffect } from 'react';
import html from '../html.js';
import { api } from '../api.js';


export default function ItemForm({ currentItem, onSuccess, onCancel }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Sync state with current editing item changes
  useEffect(() => {
    if (currentItem) {
      setTitle(currentItem.title);
      setDescription(currentItem.description || '');
    } else {
      setTitle('');
      setDescription('');
    }
    setError('');
  }, [currentItem]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title is required');
      return;
    }

    setLoading(true);
    setError('');

    try {
      if (currentItem) {
        // Edit Action
        const updated = await api.updateItem(currentItem.id, { 
          title: title.trim(), 
          description: description.trim() 
        });
        onSuccess(updated, 'updated');
      } else {
        // Create Action
        const created = await api.createItem({ 
          title: title.trim(), 
          description: description.trim() 
        });
        onSuccess(created, 'created');
      }
      // Reset form fields
      setTitle('');
      setDescription('');
    } catch (err) {
      setError(err.message || 'An error occurred while saving.');
    } finally {
      setLoading(false);
    }
  };

  return html`
    <div className="glass-panel">
      <div className="form-title">
        <h2>${currentItem ? '✏️ Edit Item' : '➕ Create New Item'}</h2>
        ${currentItem && html`
          <button 
            type="button" 
            className="btn btn-secondary btn-sm" 
            onClick=${onCancel}
          >
            Cancel
          </button>
        `}
      </div>
      
      <form onSubmit=${handleSubmit}>
        <!-- Error Alerts -->
        ${error && html`
          <div style=${{ 
            color: '#ff4d6d', 
            backgroundColor: 'rgba(255, 77, 109, 0.1)', 
            padding: '12px', 
            borderRadius: '6px', 
            marginBottom: '16px', 
            fontSize: '14px', 
            fontWeight: '500' 
          }}>
            ⚠️ ${error}
          </div>
        `}
        
        <!-- Title Input -->
        <div className="form-group">
          <label className="form-label">Title</label>
          <input 
            type="text" 
            className="form-input" 
            placeholder="e.g. Set up SQLite db" 
            value=${title} 
            onChange=${(e) => setTitle(e.target.value)}
            disabled=${loading}
            maxLength=${100}
            required
          />
        </div>

        <!-- Description Input -->
        <div className="form-group">
          <label className="form-label">Description</label>
          <textarea 
            className="form-input" 
            placeholder="Describe the tasks or notes..." 
            value=${description} 
            onChange=${(e) => setDescription(e.target.value)}
            disabled=${loading}
          ></textarea>
        </div>

        <!-- Submit Buttons -->
        <div className="btn-group">
          <button 
            type="submit" 
            className="btn btn-primary" 
            disabled=${loading}
          >
            ${loading ? 'Saving...' : currentItem ? 'Save Changes' : 'Create Item'}
          </button>
          
          ${!currentItem && (title || description) && html`
            <button 
              type="button" 
              className="btn btn-secondary" 
              onClick=${() => { setTitle(''); setDescription(''); }} 
              disabled=${loading}
            >
              Clear
            </button>
          `}
        </div>
      </form>
    </div>
  `;
}
