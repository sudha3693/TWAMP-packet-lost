/**
 * Loads configuration variables from the root `.env` file dynamically at runtime.
 */
const DEFAULT_CONFIG = {
  API_URL: '/api/v1',
  PROJECT_NAME: 'CRM Dashboard'
};

const CONFIG_FETCH_TIMEOUT_MS = 2000;
let cachedConfig = null;

export async function loadConfig() {
  if (cachedConfig) {
    return cachedConfig;
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), CONFIG_FETCH_TIMEOUT_MS);

  try {
    const response = await fetch('/.env', { signal: controller.signal });
    if (!response.ok) {
      throw new Error(`Failed to load .env: ${response.statusText}`);
    }
    const text = await response.text();
    const config = {};
    
    // Parse key-value pairs
    text.split(/\r?\n/).forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) {
        return;
      }
      
      const equalIndex = trimmed.indexOf('=');
      if (equalIndex > 0) {
        const key = trimmed.substring(0, equalIndex).trim();
        let value = trimmed.substring(equalIndex + 1).trim();
        
        // Strip wrapping quotes if present
        if ((value.startsWith('"') && value.endsWith('"')) || 
            (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        
        config[key] = value;
      }
    });
    
    cachedConfig = {
      API_URL: config.API_URL || '/api/v1',
      PROJECT_NAME: config.PROJECT_NAME || 'CRM Dashboard'
    };

    return cachedConfig;
  } catch (e) {
    console.warn("Could not fetch .env file, using default configuration.", e);
    cachedConfig = DEFAULT_CONFIG;
    return cachedConfig;
  } finally {
    clearTimeout(timeoutId);
  }
}
