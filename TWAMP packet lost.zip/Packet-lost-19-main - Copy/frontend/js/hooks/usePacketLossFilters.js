import { useCallback, useMemo, useState } from 'react';

export default function usePacketLossFilters(initialFilters = {}) {
  const [filters, setFilters] = useState({
    siteId: '',
    popName: '',
    connectionType: '',
    technology: '',
    plCount: '',
    ...initialFilters
  });

  const setFilter = useCallback((field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value || ''
    }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({
      siteId: '',
      popName: '',
      connectionType: '',
      technology: '',
      plCount: ''
    });
  }, []);

  const normalizedFilters = useMemo(() => ({
    siteId: (filters.siteId || '').toString().trim(),
    popName: (filters.popName || '').toString().trim(),
    connectionType: (filters.connectionType || '').toString().trim(),
    technology: (filters.technology || '').toString().trim(),
    plCount: (filters.plCount || '').toString().trim()
  }), [filters]);

  return {
    filters,
    setFilter,
    resetFilters,
    normalizedFilters
  };
}
